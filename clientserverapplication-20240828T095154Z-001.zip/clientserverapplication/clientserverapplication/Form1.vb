﻿Imports System.Net
Imports System.Net.Sockets
Imports System.IO
Imports MySql.Data.MySqlClient
Imports System.Windows.Forms

Public Class Form1

    Private connectionString As String = "server=localhost;database=clientserver;uid=root;pwd=;"
    Private client As TcpClient
    Public STR As StreamReader
    Public STW As StreamWriter
    Public receive As String
    Public TextToSend As String
    Public Name As String ' Variable to store the sender's name

    Public Sub New()
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Dim localIP As IPAddress() = Dns.GetHostAddresses(Dns.GetHostName())

        For Each address As IPAddress In localIP
            If address.AddressFamily = AddressFamily.InterNetwork Then
                ServerIPtextBox.Text = address.ToString()
            End If
        Next

        ChatBoxScreen.FlowDirection = FlowDirection.TopDown
        ChatBoxScreen.WrapContents = False
        ChatBoxScreen.AutoScroll = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim listener As New TcpListener(IPAddress.Any, 5000)
        listener.Start()
        client = listener.AcceptTcpClient()
        STR = New StreamReader(client.GetStream())
        STW = New StreamWriter(client.GetStream())
        STW.AutoFlush = True

        BackgroundWorker1.RunWorkerAsync()
        BackgroundWorker2.WorkerSupportsCancellation = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        client = New TcpClient()
        Dim IPEnd As New IPEndPoint(IPAddress.Parse(ClientIPtextBox.Text), 5000)
        Try
            client.Connect(IPEnd)
            If client.Connected Then
                AddMessageToFlowLayoutPanel("Connected to server")
                STW = New StreamWriter(client.GetStream())
                STR = New StreamReader(client.GetStream())
                STW.AutoFlush = True

                BackgroundWorker1.RunWorkerAsync()
                BackgroundWorker2.WorkerSupportsCancellation = True
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString())
        End Try
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        While client.Connected
            Try
                receive = STR.ReadLine()
                If receive.StartsWith("<File>") Then
                    ' Received a file from the server
                    Dim filePath As String = receive.Substring("<File>".Length)
                    Me.ChatBoxScreen.Invoke(New MethodInvoker(Sub()
                                                                  AddFileToFlowLayoutPanel(filePath)
                                                                  AddMessageToFlowLayoutPanel("Received file:")
                                                              End Sub))
                ElseIf receive.StartsWith("<Image>") Then
                    ' Received an image from the server
                    Dim imageData As String = receive.Substring("<Image>".Length)
                    Dim imageBytes As Byte() = Convert.FromBase64String(imageData)
                    Dim image As Image = Image.FromStream(New MemoryStream(imageBytes))
                    Me.ChatBoxScreen.Invoke(New MethodInvoker(Sub()
                                                                  AddImageToFlowLayoutPanel(image)
                                                                  AddMessageToFlowLayoutPanel("Received image:")
                                                              End Sub))
                Else
                    ' Received a regular message
                    Me.ChatBoxScreen.Invoke(New MethodInvoker(Sub()
                                                                  AddMessageToFlowLayoutPanel(receive)
                                                              End Sub))
                End If
                receive = ""
            Catch ex As Exception
                MessageBox.Show(ex.Message.ToString())
            End Try
        End While
    End Sub
    Private Sub AddFileToFlowLayoutPanel(filePath As String)
        Dim linkLabel As New LinkLabel()
        linkLabel.AutoSize = True
        linkLabel.Text = Path.GetFileName(filePath)
        AddHandler linkLabel.LinkClicked, Sub(sender As Object, e As LinkLabelLinkClickedEventArgs)
                                              System.Diagnostics.Process.Start(filePath)
                                          End Sub

        ChatBoxScreen.Controls.Add(linkLabel)
        ChatBoxScreen.ScrollControlIntoView(linkLabel)
    End Sub

    Private Sub BackgroundWorker2_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker2.DoWork
        If client.Connected Then
            STW.WriteLine(Name + ": " + TextToSend)
            Me.ChatBoxScreen.Invoke(New MethodInvoker(Sub()
                                                          AddMessageToFlowLayoutPanel(Name + ": " + TextToSend)
                                                          StoreMessageInDatabase(Name + ": " + TextToSend, "")
                                                      End Sub))
        Else
            MessageBox.Show("Sending Failed")
        End If

        BackgroundWorker2.CancelAsync()
    End Sub

    Private Sub SendImage(imageFilePath As String)
        ' Read the image file as byte array
        Dim imageBytes As Byte() = File.ReadAllBytes(imageFilePath)
        ' Convert the byte array to Base64 string
        Dim imageData As String = Convert.ToBase64String(imageBytes)
        ' Prepend "<Image>" tag to identify it as an image message
        Dim messageToSend As String = "<Image>" + imageData
        ' Send the image message to the server
        STW.WriteLine(messageToSend)

        ' Store the image message in the database
        StoreMessageInDatabase(Name + ": " + messageToSend, imageFilePath)
    End Sub

    Private Sub SendFile(filePath As String)
        ' Read the file as byte array
        Dim fileBytes As Byte() = File.ReadAllBytes(filePath)
        ' Convert the byte array to Base64 string
        Dim fileData As String = Convert.ToBase64String(fileBytes)
        ' Prepend "<File>" tag to identify it as a file message
        Dim messageToSend As String = "<File>" + filePath
        ' Send the file message to the server
        STW.WriteLine(messageToSend)

        ' Store the file message in the database
        StoreMessageInDatabase(Name + ": " + messageToSend, filePath)
    End Sub

    Private Sub Sendbutton_Click(sender As Object, e As EventArgs) Handles Sendbutton.Click
        If MessagetextBox.Text <> "" Then
            TextToSend = MessagetextBox.Text
            BackgroundWorker2.RunWorkerAsync()
        End If
        MessagetextBox.Text = ""
    End Sub

    Private Sub NameTextBox_TextChanged(sender As Object, e As EventArgs) Handles NameTextBox.TextChanged
        Name = NameTextBox.Text
    End Sub

    Private Sub StoreMessageInDatabase(message As String, filePath As String)
        Using connection As New MySqlConnection(connectionString)
            connection.Open()

            Dim query As String = "INSERT INTO tbl_message (sender, message, file_path, timestamp) VALUES (@sender, @message, @file_path, @timestamp)"
            Using command As New MySqlCommand(query, connection)
                command.Parameters.AddWithValue("@sender", Name)
                command.Parameters.AddWithValue("@message", message)

                ' Set the file path parameter
                If Not String.IsNullOrEmpty(filePath) Then
                    command.Parameters.AddWithValue("@file_path", filePath)
                Else
                    ' No file, store null
                    command.Parameters.AddWithValue("@file_path", DBNull.Value)
                End If

                command.Parameters.AddWithValue("@timestamp", DateTime.Now)
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Private Sub AddMessageToFlowLayoutPanel(message As String)
        If message.StartsWith("<File>") Then
            ' Received a file message
            Dim filePath As String = message.Substring("<File>".Length)

            Dim fileLabel As New Label()
            fileLabel.AutoSize = True
            fileLabel.Text = "File: " + Path.GetFileName(filePath)
            fileLabel.ForeColor = Color.Blue
            fileLabel.Cursor = Cursors.Hand
            AddHandler fileLabel.Click, Sub(sender As Object, e As EventArgs)
                                            ' Open the file when clicked
                                            Process.Start(filePath)
                                        End Sub

            ChatBoxScreen.Controls.Add(fileLabel)
            ChatBoxScreen.ScrollControlIntoView(fileLabel)
        Else
            ' Regular text message
            Dim label As New Label()
            label.AutoSize = True
            label.Text = message

            ChatBoxScreen.Controls.Add(label)
            ChatBoxScreen.ScrollControlIntoView(label)
        End If
    End Sub
    Private Sub AddImageToFlowLayoutPanel(image As Image)
        Dim pictureBox As New PictureBox()
        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage
        pictureBox.Width = 100 ' Adjust the width and height as needed
        pictureBox.Height = 100
        pictureBox.Image = image

        ChatBoxScreen.Controls.Add(pictureBox)
        ChatBoxScreen.ScrollControlIntoView(pictureBox)
    End Sub

    Private Sub sendimg_Click(sender As Object, e As EventArgs) Handles sendimg.Click
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif"
        If openFileDialog.ShowDialog() = DialogResult.OK Then
            Dim imageFilePath As String = openFileDialog.FileName

            ' Load the image from file
            Dim image As Image = Image.FromFile(imageFilePath)

            ' Add the image to the FlowLayoutPanel
            AddImageToFlowLayoutPanel(image)

            ' Send the image to the server
            SendImage(imageFilePath)
        End If
    End Sub

    Private Sub Sendfilebtn_Click(sender As Object, e As EventArgs) Handles sendfilebtn.Click
        Dim openFileDialog As New OpenFileDialog()
        openFileDialog.Filter = "All Files|*.*"

        If openFileDialog.ShowDialog() = DialogResult.OK Then
            Dim filePath As String = openFileDialog.FileName

            ' Read the file content as a byte array
            Dim fileContent As Byte() = File.ReadAllBytes(filePath)

            ' Convert the byte array to Base64 string
            Dim fileData As String = Convert.ToBase64String(fileContent)

            ' Send the file data as a message with a <File> tag
            Dim messageToSend As String = "<File>" + fileData
            STW.WriteLine(messageToSend)

            ' Display the file name in the message box
            Dim fileName As String = Path.GetFileName(filePath)
            AddMessageToFlowLayoutPanel("File: " + fileName)
            StoreMessageInDatabase(Name + ": " + messageToSend, filePath)
            SendFile(filePath)
        End If
    End Sub

End Class