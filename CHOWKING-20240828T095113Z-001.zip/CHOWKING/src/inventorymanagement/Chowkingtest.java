package inventorymanagement;

import java.awt.Image;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

public class Chowkingtest extends javax.swing.JFrame {
DecimalFormat df = new DecimalFormat("#.00");
     double total= 0.00; 
     int x = 0;
     double price;
    double cash = 0.00;
     double change = cash-total;
    public Chowkingtest() {
        initComponents();
       init();
       
    }
   
    public void init()
    {
    setImage();
    setTime();
  
    }
   
    public void setImage()
    {
    ImageIcon icon = new ImageIcon(getClass().getResource("/images/Holiday Chow Feast A Promo.png"));
    ImageIcon icon1 = new ImageIcon(getClass().getResource("/images/Holiday Chow Feast B Promo.png"));
    ImageIcon icon2 = new ImageIcon(getClass().getResource("/images/Holiday Chow Feast D Promo.png"));
    ImageIcon icon3 = new ImageIcon(getClass().getResource("/images/siopao+milksha bundle.png"));
    ImageIcon icon4 = new ImageIcon(getClass().getResource("/images/4 pc Steamed Pork SIomai + Milksha Bundle.png"));
     ImageIcon icon5 = new ImageIcon(getClass().getResource("/images/Pancit canton + milksha.png"));
     ImageIcon icon6 = new ImageIcon(getClass().getResource("/images/Siomai Chao Fan Family Platter.png"));
     ImageIcon icon8 = new ImageIcon(getClass().getResource("/images/Dimsum Chao Fan.png"));
      ImageIcon icon9 = new ImageIcon(getClass().getResource("/images/Chinese-Style Fried Chicken Lauriat.png"));
       ImageIcon icon10 = new ImageIcon(getClass().getResource("/images/8Pc. Chinese-Style Fried Chicken.png"));
        ImageIcon icon11 = new ImageIcon(getClass().getResource("/images/Family Lauriat Set A (Good for 3).png"));
     ImageIcon icon12 = new ImageIcon(getClass().getResource("/images/Family Lauriat Set B (Good for 4).png"));
     ImageIcon icon13 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Pork-Chao Fan Family Bundle.png"));
      ImageIcon icon14 = new ImageIcon(getClass().getResource("/images/Pork Chao Fan.png"));
       ImageIcon icon16 = new ImageIcon(getClass().getResource("/images/Dimsum Beef Chao Fan.png"));
        ImageIcon icon17 = new ImageIcon(getClass().getResource("/images/Beef Chao Fan.png"));
        ImageIcon icon18 = new ImageIcon(getClass().getResource("/images/6Pc. Chinese-Style Fried Chicken.png"));
        ImageIcon icon19 = new ImageIcon(getClass().getResource("/images/Fried Chicken-Pancit Family Platter.png"));
         ImageIcon icon20 = new ImageIcon(getClass().getResource("/images/2pc.Chinese-Style Fried Chicken.png"));
           ImageIcon icon21 = new ImageIcon(getClass().getResource("/images/Beef Chao Fan wFried Chicken.png"));
            ImageIcon icon22 = new ImageIcon(getClass().getResource("/images/Chick n Sauce.png"));
            ImageIcon icon23 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Chicken.png"));
            ImageIcon icon24 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Pork.png"));
             ImageIcon icon25 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Fish.png"));
    ImageIcon icon26 = new ImageIcon(getClass().getResource("/images/Chick 'n Sauce Lauriat.png"));
     ImageIcon icon27 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Pork Lauriat.png"));
    ImageIcon icon28 = new ImageIcon(getClass().getResource("/images/Sweet & Sour Fish Lauriat.png"));
    ImageIcon icon29 = new ImageIcon(getClass().getResource("/images/Beef Mami.png"));
    ImageIcon icon30 = new ImageIcon(getClass().getResource("/images/Beef Wonton Mami.png"));
    ImageIcon icon31 = new ImageIcon(getClass().getResource("/images/Pancit Canton.png"));
    ImageIcon icon32 = new ImageIcon(getClass().getResource("/images/Chunky Asado Siopao.png"));
    ImageIcon icon33 = new ImageIcon(getClass().getResource("/images/3pc. Siopao Box.png"));
    ImageIcon icon34 = new ImageIcon(getClass().getResource("/images/2pc. Siomai.png"));
    ImageIcon icon35 = new ImageIcon(getClass().getResource("/images/Beef Tapa.png"));
    ImageIcon icon36 = new ImageIcon(getClass().getResource("/images/Chinese Pork Longganisa.png"));
    ImageIcon icon37 = new ImageIcon(getClass().getResource("/images/King's Special.png"));
    ImageIcon icon38 = new ImageIcon(getClass().getResource("/images/Chicharap.png"));
    ImageIcon icon39 = new ImageIcon(getClass().getResource("/images/Buchi.png"));
    ImageIcon icon40 = new ImageIcon(getClass().getResource("/images/Extra Plain Rice.png"));
    ImageIcon icon41 = new ImageIcon(getClass().getResource("/images/Extra Egg Fried Rice.png"));
    ImageIcon icon42 = new ImageIcon(getClass().getResource("/images/supersangkap halo-halo.png"));
    ImageIcon icon43 = new ImageIcon(getClass().getResource("/images/Iced Tea.png"));
    ImageIcon icon44 = new ImageIcon(getClass().getResource("/images/Coke Zero.png"));
    ImageIcon icon45 = new ImageIcon(getClass().getResource("/images/Sprite.png"));
    
    Image img = icon.getImage().getScaledInstance(jLabelimage.getWidth(), jLabelimage.getHeight(), Image.SCALE_SMOOTH);
    Image img1 = icon1.getImage().getScaledInstance(jLabelimage1.getWidth(), jLabelimage1.getHeight(), Image.SCALE_SMOOTH);
    Image img2 = icon2.getImage().getScaledInstance(jLabelimage2.getWidth(), jLabelimage2.getHeight(), Image.SCALE_SMOOTH);
    Image img3 = icon3.getImage().getScaledInstance(jLabelimage3.getWidth(), jLabelimage3.getHeight(), Image.SCALE_SMOOTH);
    Image img4 = icon4.getImage().getScaledInstance(jLabelimage4.getWidth(), jLabelimage4.getHeight(), Image.SCALE_SMOOTH);
    Image img5 = icon5.getImage().getScaledInstance(jLabelimage5.getWidth(), jLabelimage5.getHeight(), Image.SCALE_SMOOTH);
     Image img6 = icon6.getImage().getScaledInstance(jLabelimage6.getWidth(), jLabelimage6.getHeight(), Image.SCALE_SMOOTH);
     Image img8 = icon8.getImage().getScaledInstance(jLabelimage8.getWidth(), jLabelimage8.getHeight(), Image.SCALE_SMOOTH);
     Image img9 = icon9.getImage().getScaledInstance(jLabelimage9.getWidth(), jLabelimage9.getHeight(), Image.SCALE_SMOOTH);
      Image img10 = icon10.getImage().getScaledInstance(jLabelimage10.getWidth(), jLabelimage10.getHeight(), Image.SCALE_SMOOTH);
      Image img11 = icon11.getImage().getScaledInstance(jLabelimage11.getWidth(), jLabelimage11.getHeight(), Image.SCALE_SMOOTH);
       Image img12 = icon12.getImage().getScaledInstance(jLabelimage12.getWidth(), jLabelimage12.getHeight(), Image.SCALE_SMOOTH);
        Image img13 = icon13.getImage().getScaledInstance(jLabelimage13.getWidth(), jLabelimage13.getHeight(), Image.SCALE_SMOOTH);
        Image img14 = icon14.getImage().getScaledInstance(jLabelimage14.getWidth(), jLabelimage14.getHeight(), Image.SCALE_SMOOTH);
         Image img16 = icon16.getImage().getScaledInstance(jLabelimage16.getWidth(), jLabelimage16.getHeight(), Image.SCALE_SMOOTH);
         Image img17 = icon17.getImage().getScaledInstance(jLabelimage17.getWidth(), jLabelimage17.getHeight(), Image.SCALE_SMOOTH);
         Image img18 = icon18.getImage().getScaledInstance(jLabelimage18.getWidth(), jLabelimage18.getHeight(), Image.SCALE_SMOOTH);
          Image img19 = icon19.getImage().getScaledInstance(jLabelimage19.getWidth(), jLabelimage19.getHeight(), Image.SCALE_SMOOTH);
          Image img20 = icon20.getImage().getScaledInstance(jLabelimage20.getWidth(), jLabelimage20.getHeight(), Image.SCALE_SMOOTH);
           Image img21 = icon21.getImage().getScaledInstance(jLabelimage21.getWidth(), jLabelimage21.getHeight(), Image.SCALE_SMOOTH);
            Image img22 = icon22.getImage().getScaledInstance(jLabelimage22.getWidth(), jLabelimage22.getHeight(), Image.SCALE_SMOOTH);
        Image img23 = icon23.getImage().getScaledInstance(jLabelimage23.getWidth(), jLabelimage23.getHeight(), Image.SCALE_SMOOTH);
        Image img24 = icon24.getImage().getScaledInstance(jLabelimage24.getWidth(), jLabelimage24.getHeight(), Image.SCALE_SMOOTH);
        Image img25 = icon25.getImage().getScaledInstance(jLabelimage25.getWidth(), jLabelimage25.getHeight(), Image.SCALE_SMOOTH);
         Image img26 = icon26.getImage().getScaledInstance(jLabelimage26.getWidth(), jLabelimage26.getHeight(), Image.SCALE_SMOOTH);
        Image img27 = icon27.getImage().getScaledInstance(jLabelimage27.getWidth(), jLabelimage27.getHeight(), Image.SCALE_SMOOTH);
        Image img28 = icon28.getImage().getScaledInstance(jLabelimage28.getWidth(), jLabelimage28.getHeight(), Image.SCALE_SMOOTH);
        Image img29 = icon29.getImage().getScaledInstance(jLabelimage29.getWidth(), jLabelimage29.getHeight(), Image.SCALE_SMOOTH);
          Image img30 = icon30.getImage().getScaledInstance(jLabelimage30.getWidth(), jLabelimage30.getHeight(), Image.SCALE_SMOOTH);
          Image img31 = icon31.getImage().getScaledInstance(jLabelimage31.getWidth(), jLabelimage31.getHeight(), Image.SCALE_SMOOTH);
                Image img32 = icon32.getImage().getScaledInstance(jLabelimage32.getWidth(), jLabelimage32.getHeight(), Image.SCALE_SMOOTH);
                 Image img33 = icon33.getImage().getScaledInstance(jLabelimage33.getWidth(), jLabelimage33.getHeight(), Image.SCALE_SMOOTH);
                  Image img34 = icon34.getImage().getScaledInstance(jLabelimage34.getWidth(), jLabelimage34.getHeight(), Image.SCALE_SMOOTH);
                  Image img35 = icon35.getImage().getScaledInstance(jLabelimage35.getWidth(), jLabelimage35.getHeight(), Image.SCALE_SMOOTH);
        Image img36 = icon36.getImage().getScaledInstance(jLabelimage36.getWidth(), jLabelimage36.getHeight(), Image.SCALE_SMOOTH);
        Image img37 = icon37.getImage().getScaledInstance(jLabelimage37.getWidth(), jLabelimage37.getHeight(), Image.SCALE_SMOOTH);
         Image img38 = icon38.getImage().getScaledInstance(jLabelimage38.getWidth(), jLabelimage38.getHeight(), Image.SCALE_SMOOTH);
          Image img39 = icon39.getImage().getScaledInstance(jLabelimage39.getWidth(), jLabelimage39.getHeight(), Image.SCALE_SMOOTH);
           Image img40 = icon40.getImage().getScaledInstance(jLabelimage40.getWidth(), jLabelimage40.getHeight(), Image.SCALE_SMOOTH);
            Image img41 = icon41.getImage().getScaledInstance(jLabelimage41.getWidth(), jLabelimage41.getHeight(), Image.SCALE_SMOOTH);
            Image img42 = icon42.getImage().getScaledInstance(jLabelimage42.getWidth(), jLabelimage42.getHeight(), Image.SCALE_SMOOTH);
            Image img43 = icon43.getImage().getScaledInstance(jLabelimage43.getWidth(), jLabelimage43.getHeight(), Image.SCALE_SMOOTH);
            Image img44 = icon44.getImage().getScaledInstance(jLabelimage44.getWidth(), jLabelimage44.getHeight(), Image.SCALE_SMOOTH);
            Image img45 = icon45.getImage().getScaledInstance(jLabelimage45.getWidth(), jLabelimage45.getHeight(), Image.SCALE_SMOOTH);
        
    jLabelimage.setIcon(new ImageIcon(img));
    jLabelimage1.setIcon(new ImageIcon(img1));
    jLabelimage2.setIcon(new ImageIcon(img2));
    jLabelimage3.setIcon(new ImageIcon(img3));
   jLabelimage4.setIcon(new ImageIcon(img4));
   jLabelimage5.setIcon(new ImageIcon(img5));
    jLabelimage6.setIcon(new ImageIcon(img6));
    jLabelimage8.setIcon(new ImageIcon(img8));
    jLabelimage9.setIcon(new ImageIcon(img9));
     jLabelimage10.setIcon(new ImageIcon(img10));
      jLabelimage11.setIcon(new ImageIcon(img11));
      jLabelimage12.setIcon(new ImageIcon(img12));
      jLabelimage13.setIcon(new ImageIcon(img13));
      jLabelimage14.setIcon(new ImageIcon(img14));
      jLabelimage16.setIcon(new ImageIcon(img16));
      jLabelimage17.setIcon(new ImageIcon(img17));
      jLabelimage18.setIcon(new ImageIcon(img18));
      jLabelimage19.setIcon(new ImageIcon(img19));
       jLabelimage20.setIcon(new ImageIcon(img20));
       jLabelimage21.setIcon(new ImageIcon(img21));
       jLabelimage22.setIcon(new ImageIcon(img22));
        jLabelimage23.setIcon(new ImageIcon(img23));
           jLabelimage24.setIcon(new ImageIcon(img24));
            jLabelimage25.setIcon(new ImageIcon(img25));
            jLabelimage26.setIcon(new ImageIcon(img26));
      jLabelimage27.setIcon(new ImageIcon(img27)); 
       jLabelimage28.setIcon(new ImageIcon(img28)); 
        jLabelimage29.setIcon(new ImageIcon(img29)); 
        jLabelimage30.setIcon(new ImageIcon(img30));
        jLabelimage31.setIcon(new ImageIcon(img31));
        jLabelimage32.setIcon(new ImageIcon(img32));
        jLabelimage33.setIcon(new ImageIcon(img33));
        jLabelimage34.setIcon(new ImageIcon(img34));
          jLabelimage35.setIcon(new ImageIcon(img35));
       jLabelimage36.setIcon(new ImageIcon(img36));   
       jLabelimage37.setIcon(new ImageIcon(img37)); 
       jLabelimage38.setIcon(new ImageIcon(img38)); 
       jLabelimage39.setIcon(new ImageIcon(img39)); 
       jLabelimage40.setIcon(new ImageIcon(img40)); 
       jLabelimage41.setIcon(new ImageIcon(img41)); 
       jLabelimage42.setIcon(new ImageIcon(img42));
       jLabelimage43.setIcon(new ImageIcon(img43));
       jLabelimage44.setIcon(new ImageIcon(img44));
       jLabelimage45.setIcon(new ImageIcon(img45));
    }
public boolean qtyIsZero(int qty)
{
if (qty == 0){
        JOptionPane.showMessageDialog(this, "Please increase the item quantity");
        return false;
        }
return true;
}
   public void reset ()
   {
       total = 0.0;
       x = 0;
       cash = 0.0;
       change = 0.0;
       btntotal.setEnabled(true);
   jSpinner1.setValue(0);
   jSpinner2.setValue(0);
   jSpinner3.setValue(0);
    jSpinner4.setValue(0);
     jSpinner5.setValue(0);
     jSpinner6.setValue(0);
     jSpinner7.setValue(0);
     jSpinner9.setValue(0); 
     jSpinner10.setValue(0); 
      jSpinner11.setValue(0);
       jSpinner12.setValue(0);
        jSpinner13.setValue(0);
        jSpinner14.setValue(0);
        jSpinner15.setValue(0);
        jSpinner17.setValue(0);
         jSpinner18.setValue(0);
         jSpinner19.setValue(0);
         jSpinner20.setValue(0);
         jSpinner21.setValue(0);
          jSpinner22.setValue(0);
          jSpinner23.setValue(0);
           jSpinner24.setValue(0);
               jSpinner25.setValue(0);
           jSpinner26.setValue(0);     
               jSpinner27.setValue(0); 
        jSpinner28.setValue(0);
        jSpinner29.setValue(0);
       jSpinner30.setValue(0);
         jSpinner31.setValue(0); 
      jSpinner32.setValue(0);    
     jSpinner33.setValue(0); 
jSpinner34.setValue(0);
jSpinner35.setValue(0); 
jSpinner36.setValue(0);
jSpinner37.setValue(0);
jSpinner38.setValue(0);
jSpinner39.setValue(0);
jSpinner40.setValue(0);
jSpinner41.setValue(0);
jSpinner42.setValue(0);
jSpinner43.setValue(0);
jSpinner44.setValue(0);
jSpinner45.setValue(0);
jSpinner46.setValue(0);
         
   jTextFielcash.setText("0.00");
   jTextFieldchange.setText("0.00");
    jTextFieldtotal1.setText("0.00");
  
   jCheckBox1.setSelected(false);
   jCheckBox2.setSelected(false);
   jCheckBox3.setSelected(false);
   jCheckBox4.setSelected(false);
   jCheckBox5.setSelected(false);
   jCheckBox6.setSelected(false);
   jCheckBox7.setSelected(false);
    jCheckBox9.setSelected(false);
     jCheckBox10.setSelected(false);
     jCheckBox11.setSelected(false);
     jCheckBox12.setSelected(false);
      jCheckBox13.setSelected(false);
      jCheckBox14.setSelected(false);
      jCheckBox15.setSelected(false);
      jCheckBox17.setSelected(false);
   jCheckBox18.setSelected(false);
    jCheckBox19.setSelected(false);
     jCheckBox20.setSelected(false);
      jCheckBox21.setSelected(false);
       jCheckBox22.setSelected(false);
        jCheckBox23.setSelected(false);
        jCheckBox24.setSelected(false);
        jCheckBox25.setSelected(false);
        jCheckBox26.setSelected(false);
        jCheckBox27.setSelected(false);
         jCheckBox28.setSelected(false);
         jCheckBox29.setSelected(false);
         jCheckBox30.setSelected(false);
         jCheckBox31.setSelected(false);
         jCheckBox32.setSelected(false);
         jCheckBox33.setSelected(false);
         jCheckBox34.setSelected(false);
          jCheckBox35.setSelected(false);
          jCheckBox36.setSelected(false);
          jCheckBox37.setSelected(false);
          jCheckBox38.setSelected(false);
           jCheckBox39.setSelected(false);
            jCheckBox40.setSelected(false);
             jCheckBox41.setSelected(false);
              jCheckBox42.setSelected(false);
              jCheckBox43.setSelected(false);
              jCheckBox44.setSelected(false);
              jCheckBox45.setSelected(false);
              jCheckBox46.setSelected(false);
              
             DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
             model.setRowCount(0);
             jTextArea1.setText("");
   }
    
  public void ItemCost() 
  {
  double sum = 0;
  
  for (int i=0; i< jTable1.getRowCount(); i++)
  {
  sum = sum + Double.parseDouble(jTable1.getValueAt(i,3).toString());
  
  }
  jTextFieldtotal1.setText(Double.toString(sum));
  double cTotal = Double.parseDouble(jTextFieldtotal1.getText());
  String iTotal = String.format("%.2f", cTotal);
        jTextFieldtotal1.setText(iTotal);
  }
   
   
   

   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jSpinner1 = new javax.swing.JSpinner();
        jCheckBox1 = new javax.swing.JCheckBox();
        jLabelimage = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jSpinner2 = new javax.swing.JSpinner();
        jCheckBox2 = new javax.swing.JCheckBox();
        jLabelimage1 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jSpinner3 = new javax.swing.JSpinner();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabelimage2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSpinner4 = new javax.swing.JSpinner();
        jCheckBox4 = new javax.swing.JCheckBox();
        jLabelimage3 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jSpinner5 = new javax.swing.JSpinner();
        jCheckBox5 = new javax.swing.JCheckBox();
        jLabelimage4 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jSpinner6 = new javax.swing.JSpinner();
        jCheckBox6 = new javax.swing.JCheckBox();
        jLabelimage5 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jSpinner7 = new javax.swing.JSpinner();
        jCheckBox7 = new javax.swing.JCheckBox();
        jLabelimage6 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jSpinner9 = new javax.swing.JSpinner();
        jCheckBox9 = new javax.swing.JCheckBox();
        jLabelimage8 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jSpinner10 = new javax.swing.JSpinner();
        jCheckBox10 = new javax.swing.JCheckBox();
        jLabelimage9 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jSpinner11 = new javax.swing.JSpinner();
        jCheckBox11 = new javax.swing.JCheckBox();
        jLabelimage10 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        jSpinner12 = new javax.swing.JSpinner();
        jCheckBox12 = new javax.swing.JCheckBox();
        jLabelimage11 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jSpinner14 = new javax.swing.JSpinner();
        jCheckBox14 = new javax.swing.JCheckBox();
        jLabelimage13 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jSpinner13 = new javax.swing.JSpinner();
        jCheckBox13 = new javax.swing.JCheckBox();
        jLabelimage12 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jSpinner15 = new javax.swing.JSpinner();
        jCheckBox15 = new javax.swing.JCheckBox();
        jLabelimage14 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jSpinner17 = new javax.swing.JSpinner();
        jCheckBox17 = new javax.swing.JCheckBox();
        jLabelimage16 = new javax.swing.JLabel();
        jLabel88 = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jSpinner18 = new javax.swing.JSpinner();
        jCheckBox18 = new javax.swing.JCheckBox();
        jLabelimage17 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jSpinner19 = new javax.swing.JSpinner();
        jCheckBox19 = new javax.swing.JCheckBox();
        jLabelimage18 = new javax.swing.JLabel();
        jLabel98 = new javax.swing.JLabel();
        jPanel36 = new javax.swing.JPanel();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jSpinner20 = new javax.swing.JSpinner();
        jCheckBox20 = new javax.swing.JCheckBox();
        jLabelimage19 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jPanel37 = new javax.swing.JPanel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jSpinner21 = new javax.swing.JSpinner();
        jCheckBox21 = new javax.swing.JCheckBox();
        jLabelimage20 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        jPanel38 = new javax.swing.JPanel();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jSpinner22 = new javax.swing.JSpinner();
        jCheckBox22 = new javax.swing.JCheckBox();
        jLabelimage21 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jLabel114 = new javax.swing.JLabel();
        jLabel115 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jSpinner23 = new javax.swing.JSpinner();
        jCheckBox23 = new javax.swing.JCheckBox();
        jLabelimage22 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jPanel40 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jSpinner24 = new javax.swing.JSpinner();
        jCheckBox24 = new javax.swing.JCheckBox();
        jLabelimage23 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        jLabel124 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jSpinner25 = new javax.swing.JSpinner();
        jCheckBox25 = new javax.swing.JCheckBox();
        jLabelimage24 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jLabel129 = new javax.swing.JLabel();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jLabel132 = new javax.swing.JLabel();
        jSpinner26 = new javax.swing.JSpinner();
        jCheckBox26 = new javax.swing.JCheckBox();
        jLabelimage25 = new javax.swing.JLabel();
        jLabel133 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jLabel134 = new javax.swing.JLabel();
        jLabel135 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        jLabel137 = new javax.swing.JLabel();
        jSpinner27 = new javax.swing.JSpinner();
        jCheckBox27 = new javax.swing.JCheckBox();
        jLabelimage26 = new javax.swing.JLabel();
        jLabel138 = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        jLabel139 = new javax.swing.JLabel();
        jLabel140 = new javax.swing.JLabel();
        jLabel141 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        jSpinner28 = new javax.swing.JSpinner();
        jCheckBox28 = new javax.swing.JCheckBox();
        jLabelimage27 = new javax.swing.JLabel();
        jLabel143 = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        jLabel144 = new javax.swing.JLabel();
        jLabel145 = new javax.swing.JLabel();
        jLabel146 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jSpinner29 = new javax.swing.JSpinner();
        jCheckBox29 = new javax.swing.JCheckBox();
        jLabelimage28 = new javax.swing.JLabel();
        jLabel148 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jLabel149 = new javax.swing.JLabel();
        jLabel150 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel152 = new javax.swing.JLabel();
        jSpinner30 = new javax.swing.JSpinner();
        jCheckBox30 = new javax.swing.JCheckBox();
        jLabelimage29 = new javax.swing.JLabel();
        jLabel153 = new javax.swing.JLabel();
        jPanel47 = new javax.swing.JPanel();
        jLabel154 = new javax.swing.JLabel();
        jLabel155 = new javax.swing.JLabel();
        jLabel156 = new javax.swing.JLabel();
        jLabel157 = new javax.swing.JLabel();
        jSpinner31 = new javax.swing.JSpinner();
        jCheckBox31 = new javax.swing.JCheckBox();
        jLabelimage30 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jPanel48 = new javax.swing.JPanel();
        jLabel159 = new javax.swing.JLabel();
        jLabel160 = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        jLabel162 = new javax.swing.JLabel();
        jSpinner32 = new javax.swing.JSpinner();
        jCheckBox32 = new javax.swing.JCheckBox();
        jLabelimage31 = new javax.swing.JLabel();
        jLabel163 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel49 = new javax.swing.JPanel();
        jLabel164 = new javax.swing.JLabel();
        jLabel165 = new javax.swing.JLabel();
        jLabel166 = new javax.swing.JLabel();
        jLabel167 = new javax.swing.JLabel();
        jSpinner33 = new javax.swing.JSpinner();
        jCheckBox33 = new javax.swing.JCheckBox();
        jLabelimage32 = new javax.swing.JLabel();
        jLabel168 = new javax.swing.JLabel();
        jPanel50 = new javax.swing.JPanel();
        jLabel169 = new javax.swing.JLabel();
        jLabel170 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        jLabel172 = new javax.swing.JLabel();
        jSpinner34 = new javax.swing.JSpinner();
        jCheckBox34 = new javax.swing.JCheckBox();
        jLabelimage33 = new javax.swing.JLabel();
        jLabel173 = new javax.swing.JLabel();
        jPanel51 = new javax.swing.JPanel();
        jLabel174 = new javax.swing.JLabel();
        jLabel175 = new javax.swing.JLabel();
        jLabel176 = new javax.swing.JLabel();
        jLabel177 = new javax.swing.JLabel();
        jSpinner35 = new javax.swing.JSpinner();
        jCheckBox35 = new javax.swing.JCheckBox();
        jLabelimage34 = new javax.swing.JLabel();
        jLabel178 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jLabel179 = new javax.swing.JLabel();
        jLabel180 = new javax.swing.JLabel();
        jLabel181 = new javax.swing.JLabel();
        jLabel182 = new javax.swing.JLabel();
        jSpinner36 = new javax.swing.JSpinner();
        jCheckBox36 = new javax.swing.JCheckBox();
        jLabelimage35 = new javax.swing.JLabel();
        jLabel183 = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        jLabel184 = new javax.swing.JLabel();
        jLabel185 = new javax.swing.JLabel();
        jLabel186 = new javax.swing.JLabel();
        jLabel187 = new javax.swing.JLabel();
        jSpinner37 = new javax.swing.JSpinner();
        jCheckBox37 = new javax.swing.JCheckBox();
        jLabelimage36 = new javax.swing.JLabel();
        jLabel188 = new javax.swing.JLabel();
        jPanel54 = new javax.swing.JPanel();
        jLabel189 = new javax.swing.JLabel();
        jLabel190 = new javax.swing.JLabel();
        jLabel191 = new javax.swing.JLabel();
        jLabel192 = new javax.swing.JLabel();
        jSpinner38 = new javax.swing.JSpinner();
        jCheckBox38 = new javax.swing.JCheckBox();
        jLabelimage37 = new javax.swing.JLabel();
        jLabel193 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel55 = new javax.swing.JPanel();
        jLabel194 = new javax.swing.JLabel();
        jLabel195 = new javax.swing.JLabel();
        jLabel196 = new javax.swing.JLabel();
        jLabel197 = new javax.swing.JLabel();
        jSpinner39 = new javax.swing.JSpinner();
        jCheckBox39 = new javax.swing.JCheckBox();
        jLabelimage38 = new javax.swing.JLabel();
        jLabel198 = new javax.swing.JLabel();
        jPanel56 = new javax.swing.JPanel();
        jLabel199 = new javax.swing.JLabel();
        jLabel200 = new javax.swing.JLabel();
        jLabel201 = new javax.swing.JLabel();
        jLabel202 = new javax.swing.JLabel();
        jSpinner40 = new javax.swing.JSpinner();
        jCheckBox40 = new javax.swing.JCheckBox();
        jLabelimage39 = new javax.swing.JLabel();
        jLabel203 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        jLabel204 = new javax.swing.JLabel();
        jLabel205 = new javax.swing.JLabel();
        jLabel206 = new javax.swing.JLabel();
        jLabel207 = new javax.swing.JLabel();
        jSpinner41 = new javax.swing.JSpinner();
        jCheckBox41 = new javax.swing.JCheckBox();
        jLabelimage40 = new javax.swing.JLabel();
        jLabel208 = new javax.swing.JLabel();
        jPanel58 = new javax.swing.JPanel();
        jLabel209 = new javax.swing.JLabel();
        jLabel210 = new javax.swing.JLabel();
        jLabel211 = new javax.swing.JLabel();
        jLabel212 = new javax.swing.JLabel();
        jSpinner42 = new javax.swing.JSpinner();
        jCheckBox42 = new javax.swing.JCheckBox();
        jLabelimage41 = new javax.swing.JLabel();
        jLabel213 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jPanel59 = new javax.swing.JPanel();
        jLabel214 = new javax.swing.JLabel();
        jLabel215 = new javax.swing.JLabel();
        jLabel216 = new javax.swing.JLabel();
        jLabel217 = new javax.swing.JLabel();
        jSpinner43 = new javax.swing.JSpinner();
        jCheckBox43 = new javax.swing.JCheckBox();
        jLabelimage42 = new javax.swing.JLabel();
        jLabel218 = new javax.swing.JLabel();
        jPanel60 = new javax.swing.JPanel();
        jLabel219 = new javax.swing.JLabel();
        jLabel220 = new javax.swing.JLabel();
        jLabel221 = new javax.swing.JLabel();
        jLabel222 = new javax.swing.JLabel();
        jSpinner44 = new javax.swing.JSpinner();
        jCheckBox44 = new javax.swing.JCheckBox();
        jLabelimage43 = new javax.swing.JLabel();
        jLabel223 = new javax.swing.JLabel();
        jPanel61 = new javax.swing.JPanel();
        jLabel224 = new javax.swing.JLabel();
        jLabel225 = new javax.swing.JLabel();
        jLabel226 = new javax.swing.JLabel();
        jLabel227 = new javax.swing.JLabel();
        jSpinner45 = new javax.swing.JSpinner();
        jCheckBox45 = new javax.swing.JCheckBox();
        jLabelimage44 = new javax.swing.JLabel();
        jLabel228 = new javax.swing.JLabel();
        jPanel62 = new javax.swing.JPanel();
        jLabel229 = new javax.swing.JLabel();
        jLabel230 = new javax.swing.JLabel();
        jLabel231 = new javax.swing.JLabel();
        jLabel232 = new javax.swing.JLabel();
        jSpinner46 = new javax.swing.JSpinner();
        jCheckBox46 = new javax.swing.JCheckBox();
        jLabelimage45 = new javax.swing.JLabel();
        jLabel233 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextTime = new javax.swing.JLabel();
        jTextDate = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jTextFielcash = new javax.swing.JTextField();
        jTextFieldchange = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabelcash = new javax.swing.JLabel();
        jTextFieldtotal1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel14 = new javax.swing.JPanel();
        btntotal = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnexit = new javax.swing.JButton();
        btnReset1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Holiday Chow Feast A ");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Price:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Quantity:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Purchase:");

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("₱306.00");

        jSpinner1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner1.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox1))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(22, 22, 22))
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabelimage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(jCheckBox1)))
        );

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Holiday Chow Feast B");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setText("Price:");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel11.setText("Quantity:");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel12.setText("Purchase:");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel13.setText("₱867.00");

        jSpinner2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner2.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelimage1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jCheckBox2))
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel13)
                                .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel9))
                .addGap(18, 18, 18))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addComponent(jLabel9)
                .addGap(20, 20, 20)
                .addComponent(jLabelimage1, javax.swing.GroupLayout.DEFAULT_SIZE, 99, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12)
                    .addComponent(jCheckBox2)))
        );

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Holiday Chow Feast D");

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel15.setText("Price:");

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel16.setText("Quantity:");

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel17.setText("Purchase:");

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel18.setText("₱741.00");

        jSpinner3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner3.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                            .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel19Layout.createSequentialGroup()
                                    .addComponent(jLabel17)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jCheckBox3))
                                .addGroup(jPanel19Layout.createSequentialGroup()
                                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel18)
                                        .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGap(18, 18, 18))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                            .addComponent(jLabelimage2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap()))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(21, 21, 21))))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel14)
                .addGap(20, 20, 20)
                .addComponent(jLabelimage2, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel17)
                    .addComponent(jCheckBox3)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(575, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Promo Offers", jPanel1);

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel20.setText("Price:");

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel21.setText("Quantity:");

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel22.setText("Purchase:");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("₱154.00");

        jSpinner4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner4.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel23.setText("Siopao + Milksha Bundle  ");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jSpinner4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox4))
                .addGap(21, 21, 21))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelimage3, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23))
                .addGap(30, 30, 30))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelimage3, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addComponent(jLabel22)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox4)
                        .addGap(222, 222, 222))))
        );

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel24.setText("Price:");

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel25.setText("Quantity:");

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel26.setText("Purchase:");

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel27.setText("₱170.00");

        jSpinner5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner5.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel28.setText("4pc Steamed Pork Siomai+Milksha Bundle ");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSpinner5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox5)
                    .addComponent(jLabel27))
                .addGap(43, 43, 43))
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelimage4, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel26)
                            .addComponent(jLabel25)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addComponent(jLabel28)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelimage4, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jSpinner5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox5))
                    .addGroup(jPanel21Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel24)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel26)))
                .addGap(30, 30, 30))
        );

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel29.setText("Price:");

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel30.setText("Quantity:");

        jLabel31.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel31.setText("Purchase:");

        jLabel32.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel32.setText("₱186.00");

        jSpinner6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner6.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel33.setText("Pancit Canton + Milksha Bundle ");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addContainerGap(29, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel30)
                        .addGap(49, 49, 49)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSpinner6, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox6)
                            .addComponent(jLabel32))
                        .addGap(43, 43, 43))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelimage5, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31))
                .addGap(152, 152, 152))
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelimage5, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                .addGap(21, 21, 21)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addGap(44, 44, 44))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(jSpinner6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)))
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel31)
                    .addComponent(jCheckBox6))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(152, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(119, 119, 119)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(259, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("New! Milksha", jPanel2);

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel34.setText("Price:");

        jLabel35.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel35.setText("Quantity:");

        jLabel36.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel36.setText("Purchase:");

        jLabel37.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel37.setText("₱302.00");

        jSpinner7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner7.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel38.setText("Siomai Chao Fan Family Platter ");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36)
                            .addComponent(jLabel35)
                            .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel37))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelimage6, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jCheckBox7)
                                .addComponent(jSpinner7, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(33, 33, 33))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel23Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel38)
                .addGap(30, 30, 30))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel38)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage6, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel34)
                    .addComponent(jLabel37))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addComponent(jLabel36)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox7)
                        .addGap(222, 222, 222))))
        );

        jLabel44.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel44.setText("Price:");

        jLabel45.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel45.setText("Quantity:");

        jLabel46.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel46.setText("Purchase:");

        jLabel47.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel47.setText("₱101.00");

        jSpinner9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner9.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox9ActionPerformed(evt);
            }
        });

        jLabel48.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel48.setText("Dimsum Chao Fan ");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel46)
                    .addComponent(jLabel45)
                    .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel47)
                    .addComponent(jSpinner9, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox9))
                .addGap(21, 21, 21))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                .addContainerGap(49, Short.MAX_VALUE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelimage8, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel48)
                        .addGap(19, 19, 19)))
                .addGap(30, 30, 30))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel48)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelimage8, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel44)
                    .addComponent(jLabel47))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel46)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox9)
                        .addGap(222, 222, 222))))
        );

        jLabel49.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel49.setText("Price:");

        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel50.setText("Quantity:");

        jLabel51.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel51.setText("Purchase:");

        jLabel52.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel52.setText("₱201.00");

        jSpinner10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner10.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox10ActionPerformed(evt);
            }
        });

        jLabel53.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel53.setText("Chinese-Style Fried Chicken Lauriat");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel53)
                .addGap(30, 30, 30))
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addComponent(jLabelimage9, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel51)
                            .addComponent(jLabel50)
                            .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel52)
                            .addComponent(jSpinner10, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox10))
                        .addGap(21, 21, 21))))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel53)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage9, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel49)
                    .addComponent(jLabel52))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addComponent(jLabel51)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel26Layout.createSequentialGroup()
                        .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel50))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox10)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(176, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(122, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(235, 235, 235))
        );

        jTabbedPane1.addTab("Bestsellers", jPanel3);

        jLabel54.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel54.setText("Price:");

        jLabel55.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel55.setText("Quantity:");

        jLabel56.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel56.setText("Purchase:");

        jLabel57.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel57.setText("₱620.00");

        jSpinner11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner11.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox11ActionPerformed(evt);
            }
        });

        jLabel58.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel58.setText("8pc. Chinese-Style Fried Chicken ");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabelimage10, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(45, Short.MAX_VALUE))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel56)
                            .addComponent(jLabel55)
                            .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel57)
                            .addComponent(jSpinner11, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox11))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel58)
                .addGap(21, 21, 21))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel58)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage10, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel54)
                    .addComponent(jLabel57))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jLabel56)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel55))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox11)
                        .addGap(222, 222, 222))))
        );

        jLabel59.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel59.setText("Price:");

        jLabel60.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel60.setText("Quantity:");

        jLabel61.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel61.setText("Purchase:");

        jLabel62.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel62.setText("₱625.00");

        jSpinner12.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner12.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });

        jLabel63.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel63.setText("Family Lauriat Set A (Good for 3)");

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jLabelimage11, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(290, Short.MAX_VALUE))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel61)
                            .addComponent(jLabel60)
                            .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel62)
                            .addComponent(jSpinner12, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox12))
                        .addGap(268, 268, 268))))
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(jLabel63)
                .addGap(268, 268, 268))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel63)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage11, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel59)
                    .addComponent(jLabel62))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addComponent(jLabel61)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel60))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox12)
                        .addGap(222, 222, 222))))
        );

        jLabel69.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel69.setText("Price:");

        jLabel70.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel70.setText("Quantity:");

        jLabel71.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel71.setText("Purchase:");

        jLabel72.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel72.setText("₱535.00");

        jSpinner14.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner14.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox14ActionPerformed(evt);
            }
        });

        jLabel73.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel73.setText("Sweet & Sour Pork-Chao Fan Family Bundle");

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel73)
                .addGap(30, 30, 30))
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addComponent(jLabel71)
                        .addGap(74, 74, 74)
                        .addComponent(jCheckBox14))
                    .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel30Layout.createSequentialGroup()
                            .addComponent(jLabel70)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSpinner14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel30Layout.createSequentialGroup()
                            .addComponent(jLabel69, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel72))
                        .addComponent(jLabelimage13, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel73)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage13, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel72, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel69))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addComponent(jLabel71)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel70)
                            .addComponent(jSpinner14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox14)
                        .addGap(229, 229, 229))))
        );

        jLabel64.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel64.setText("Price:");

        jLabel65.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel65.setText("Quantity:");

        jLabel66.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel66.setText("Purchase:");

        jLabel67.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel67.setText("₱943.00");

        jSpinner13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner13.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox13ActionPerformed(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel68.setText("Family Lauriat Set B (Good for 4)");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addComponent(jLabelimage12, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(43, Short.MAX_VALUE))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel66)
                            .addComponent(jLabel65)
                            .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel67)
                            .addComponent(jSpinner13, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox13))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel68)
                .addGap(21, 21, 21))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel68)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage12, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel64)
                    .addComponent(jLabel67))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addComponent(jLabel66)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel65))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox13)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel28, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(243, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Good for Sharing", jPanel4);

        jLabel74.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel74.setText("Price:");

        jLabel75.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel75.setText("Quantity:");

        jLabel76.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel76.setText("Purchase:");

        jLabel77.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel77.setText("₱52.00");

        jSpinner15.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner15.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox15ActionPerformed(evt);
            }
        });

        jLabel78.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel78.setText("Pork Chao Fan");

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabelimage14, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel76)
                            .addComponent(jLabel75)
                            .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel77)
                            .addComponent(jSpinner15, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox15))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel31Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel78)
                .addGap(62, 62, 62))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel78)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage14, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel74)
                    .addComponent(jLabel77))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addComponent(jLabel76)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel31Layout.createSequentialGroup()
                        .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel75))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox15)
                        .addGap(222, 222, 222))))
        );

        jLabel84.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel84.setText("Price:");

        jLabel85.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel85.setText("Quantity:");

        jLabel86.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel86.setText("Purchase:");

        jLabel87.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel87.setText("₱138.00");

        jSpinner17.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner17.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox17ActionPerformed(evt);
            }
        });

        jLabel88.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel88.setText("Dimsum Beef Chao Fan");

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel86)
                            .addComponent(jLabel85)
                            .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel87)
                            .addComponent(jSpinner17, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox17))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel88)
                            .addComponent(jLabelimage16, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(43, Short.MAX_VALUE))))
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel33Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel88)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage16, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel84)
                    .addComponent(jLabel87))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addComponent(jLabel86)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel33Layout.createSequentialGroup()
                        .addGroup(jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel85))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox17)
                        .addGap(222, 222, 222))))
        );

        jPanel34.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                jPanel34HierarchyChanged(evt);
            }
        });

        jLabel89.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel89.setText("Price:");

        jLabel90.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel90.setText("Quantity:");

        jLabel91.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel91.setText("Purchase:");

        jLabel92.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel92.setText("₱94.00");

        jSpinner18.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner18.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox18ActionPerformed(evt);
            }
        });

        jLabel93.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel93.setText("Beef Chao Fan");

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addComponent(jLabelimage17, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel91)
                            .addComponent(jLabel90)
                            .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel92)
                            .addComponent(jSpinner18, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox18))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel93)
                .addGap(63, 63, 63))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel93)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage17, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel89)
                    .addComponent(jLabel92))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addComponent(jLabel91)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel90))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox18)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(160, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel31, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel33, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(305, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Chao Fan", jPanel5);

        jLabel94.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel94.setText("Price:");

        jLabel95.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel95.setText("Quantity:");

        jLabel96.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel96.setText("Purchase:");

        jLabel97.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel97.setText("₱488.00");

        jSpinner19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner19.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox19ActionPerformed(evt);
            }
        });

        jLabel98.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel98.setText("6pc. Chinese-Style Fried Chicken");

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel98)
                .addGap(30, 30, 30))
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addComponent(jLabel96)
                        .addGap(74, 74, 74)
                        .addComponent(jCheckBox19))
                    .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel35Layout.createSequentialGroup()
                            .addComponent(jLabel95)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSpinner19, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel35Layout.createSequentialGroup()
                            .addComponent(jLabel94, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel97))
                        .addComponent(jLabelimage18, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel98)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage18, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel97, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel94))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addComponent(jLabel96)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel95)
                            .addComponent(jSpinner19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jCheckBox19)
                        .addGap(229, 229, 229))))
        );

        jLabel99.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel99.setText("Price:");

        jLabel100.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel100.setText("Quantity:");

        jLabel101.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel101.setText("Purchase:");

        jLabel102.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel102.setText("₱726.00");

        jSpinner20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner20.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox20ActionPerformed(evt);
            }
        });

        jLabel103.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel103.setText("Fried Chicken-Pancit Family Platter");

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel36Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel103)
                .addGap(30, 30, 30))
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(jLabelimage19, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel101)
                            .addComponent(jLabel100)
                            .addComponent(jLabel99, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel102)
                            .addComponent(jSpinner20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox20))
                        .addGap(21, 21, 21))))
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel103)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage19, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel99)
                    .addComponent(jLabel102))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(jLabel101)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel100))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox20)
                        .addGap(222, 222, 222))))
        );

        jLabel104.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel104.setText("Price:");

        jLabel105.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel105.setText("Quantity:");

        jLabel106.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel106.setText("Purchase:");

        jLabel107.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel107.setText("₱180.00");

        jSpinner21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner21.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox21ActionPerformed(evt);
            }
        });

        jLabel108.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel108.setText("2pc. Chinese-Style Fried Chicken ");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel37Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel108)
                .addGap(30, 30, 30))
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addComponent(jLabelimage20, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel106)
                            .addComponent(jLabel105)
                            .addComponent(jLabel104, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel107)
                            .addComponent(jSpinner21, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox21))
                        .addGap(21, 21, 21))))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel108)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage20, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel104)
                    .addComponent(jLabel107))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addComponent(jLabel106)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel37Layout.createSequentialGroup()
                        .addGroup(jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel105))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox21)
                        .addGap(222, 222, 222))))
        );

        jLabel109.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel109.setText("Price:");

        jLabel110.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel110.setText("Quantity:");

        jLabel111.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel111.setText("Purchase:");

        jLabel112.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel112.setText("₱186.00");

        jSpinner22.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner22.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox22ActionPerformed(evt);
            }
        });

        jLabel113.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel113.setText("Beef Chao Fan w/ Fried Chicken");

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel38Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel113)
                .addGap(30, 30, 30))
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addComponent(jLabelimage21, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel111)
                            .addComponent(jLabel110)
                            .addComponent(jLabel109, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel112)
                            .addComponent(jSpinner22, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox22))
                        .addGap(21, 21, 21))))
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel113)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage21, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel109)
                    .addComponent(jLabel112))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addComponent(jLabel111)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel38Layout.createSequentialGroup()
                        .addGroup(jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel110))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox22)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(171, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(294, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Chinese-Style Fried Chicken", jPanel6);

        jLabel114.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel114.setText("Price:");

        jLabel115.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel115.setText("Quantity:");

        jLabel116.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel116.setText("Purchase:");

        jLabel117.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel117.setText("₱154.00");

        jSpinner23.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner23.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox23ActionPerformed(evt);
            }
        });

        jLabel118.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel118.setText("Chick 'n Sauce");

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addComponent(jLabelimage22, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel116)
                            .addComponent(jLabel115)
                            .addComponent(jLabel114, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel117)
                            .addComponent(jSpinner23, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox23))
                        .addGap(21, 21, 21))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel39Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel118)
                .addGap(64, 64, 64))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel118)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage22, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel114)
                    .addComponent(jLabel117))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addComponent(jLabel116)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel39Layout.createSequentialGroup()
                        .addGroup(jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel115))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox23)
                        .addGap(222, 222, 222))))
        );

        jLabel119.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel119.setText("Price:");

        jLabel120.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel120.setText("Quantity:");

        jLabel121.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel121.setText("Purchase:");

        jLabel122.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel122.setText("₱154.00");

        jSpinner24.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner24.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox24ActionPerformed(evt);
            }
        });

        jLabel123.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel123.setText("Sweet & Sour Chicken");

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel40Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel123)
                .addGap(30, 30, 30))
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addComponent(jLabelimage23, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel121)
                            .addComponent(jLabel120)
                            .addComponent(jLabel119, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel122)
                            .addComponent(jSpinner24, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox24))
                        .addGap(21, 21, 21))))
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel123)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage23, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel119)
                    .addComponent(jLabel122))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addComponent(jLabel121)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel40Layout.createSequentialGroup()
                        .addGroup(jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel120))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox24)
                        .addGap(222, 222, 222))))
        );

        jLabel124.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel124.setText("Price:");

        jLabel125.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel125.setText("Quantity:");

        jLabel126.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel126.setText("Purchase:");

        jLabel127.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel127.setText("₱154.00");

        jSpinner25.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner25.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox25ActionPerformed(evt);
            }
        });

        jLabel128.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel128.setText("Sweet & Sour Pork");

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel126)
                            .addComponent(jLabel125)
                            .addComponent(jLabel124, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel127)
                            .addComponent(jSpinner25, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox25))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage24, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel41Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabel128)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel41Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel128)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage24, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel124)
                    .addComponent(jLabel127))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addComponent(jLabel126)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel41Layout.createSequentialGroup()
                        .addGroup(jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel125))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox25)
                        .addGap(222, 222, 222))))
        );

        jLabel129.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel129.setText("Price:");

        jLabel130.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel130.setText("Quantity:");

        jLabel131.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel131.setText("Purchase:");

        jLabel132.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel132.setText("₱159.00");

        jSpinner26.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner26.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox26ActionPerformed(evt);
            }
        });

        jLabel133.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel133.setText("Sweet & Sour Fish");

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel42Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel131)
                            .addComponent(jLabel130)
                            .addComponent(jLabel129, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel132)
                            .addComponent(jSpinner26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox26))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage25, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel42Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel133)))
                        .addContainerGap(24, Short.MAX_VALUE))))
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel42Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel133)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage25, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel129)
                    .addComponent(jLabel132))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addComponent(jLabel131)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel42Layout.createSequentialGroup()
                        .addGroup(jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel130))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox26)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(186, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel41, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel40, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel42, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(280, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Chinese Rice Meals", jPanel7);

        jLabel134.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel134.setText("Price:");

        jLabel135.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel135.setText("Quantity:");

        jLabel136.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel136.setText("Purchase:");

        jLabel137.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel137.setText("₱217.00");

        jSpinner27.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner27.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox27ActionPerformed(evt);
            }
        });

        jLabel138.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel138.setText("Chick 'n Sauce Lauriat");

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel136)
                            .addComponent(jLabel135)
                            .addComponent(jLabel134, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel137)
                            .addComponent(jSpinner27, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox27))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage26, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel43Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jLabel138)))
                        .addContainerGap(24, Short.MAX_VALUE))))
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel43Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel138)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage26, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel134)
                    .addComponent(jLabel137))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addComponent(jLabel136)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel43Layout.createSequentialGroup()
                        .addGroup(jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel135))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox27)
                        .addGap(222, 222, 222))))
        );

        jLabel139.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel139.setText("Price:");

        jLabel140.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel140.setText("Quantity:");

        jLabel141.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel141.setText("Purchase:");

        jLabel142.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel142.setText("₱217.00");

        jSpinner28.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner28.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox28ActionPerformed(evt);
            }
        });

        jLabel143.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel143.setText("Sweet & Sour Pork Lauriat");

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel44Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel44Layout.createSequentialGroup()
                        .addComponent(jLabel143)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel44Layout.createSequentialGroup()
                        .addComponent(jLabelimage27, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel44Layout.createSequentialGroup()
                        .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel44Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel44Layout.createSequentialGroup()
                                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel141)
                                    .addComponent(jLabel140)
                                    .addComponent(jLabel139, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(45, 45, 45)
                                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox28)
                                    .addComponent(jLabel142))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))))
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel44Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel143)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage27, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel142, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel139))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel44Layout.createSequentialGroup()
                        .addComponent(jLabel141)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel44Layout.createSequentialGroup()
                        .addGroup(jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel140))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox28)
                        .addGap(231, 231, 231))))
        );

        jLabel144.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel144.setText("Price:");

        jLabel145.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel145.setText("Quantity:");

        jLabel146.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel146.setText("Purchase:");

        jLabel147.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel147.setText("₱223.00");

        jSpinner29.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner29.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox29ActionPerformed(evt);
            }
        });

        jLabel148.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel148.setText("Sweet & Sour Fish Lauriat");

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel146)
                            .addComponent(jLabel145)
                            .addComponent(jLabel144, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel147)
                            .addComponent(jSpinner29, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox29))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel148)
                            .addComponent(jLabelimage28, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(43, Short.MAX_VALUE))))
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel45Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel148)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage28, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel144)
                    .addComponent(jLabel147))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addComponent(jLabel146)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel45Layout.createSequentialGroup()
                        .addGroup(jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel145))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox29)
                        .addGap(222, 222, 222))))
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(146, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel43, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel45, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel44, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(335, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Lauriat", jPanel8);

        jLabel149.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel149.setText("Price:");

        jLabel150.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel150.setText("Quantity:");

        jLabel151.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel151.setText("Purchase:");

        jLabel152.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel152.setText("₱180.00");

        jSpinner30.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner30.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox30ActionPerformed(evt);
            }
        });

        jLabel153.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel153.setText("Beef Mami");

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel46Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel151)
                            .addComponent(jLabel150)
                            .addComponent(jLabel149, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel152)
                            .addComponent(jSpinner30, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCheckBox30))
                        .addGap(21, 21, 21))
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage29, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel46Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel153)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel46Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel153)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage29, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel149)
                    .addComponent(jLabel152))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addComponent(jLabel151)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel150))
                        .addGap(12, 12, 12)
                        .addComponent(jCheckBox30)
                        .addGap(222, 222, 222))))
        );

        jLabel154.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel154.setText("Price:");

        jLabel155.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel155.setText("Quantity:");

        jLabel156.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel156.setText("Purchase:");

        jLabel157.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel157.setText("₱217.00");

        jSpinner31.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner31.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox31ActionPerformed(evt);
            }
        });

        jLabel158.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel158.setText("Beef Wonton Mami");

        javax.swing.GroupLayout jPanel47Layout = new javax.swing.GroupLayout(jPanel47);
        jPanel47.setLayout(jPanel47Layout);
        jPanel47Layout.setHorizontalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel47Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel47Layout.createSequentialGroup()
                        .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel47Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner31, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel47Layout.createSequentialGroup()
                                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel156)
                                    .addComponent(jLabel155)
                                    .addComponent(jLabel154, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(45, 45, 45)
                                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox31)
                                    .addComponent(jLabel157))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel47Layout.createSequentialGroup()
                        .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage30, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel47Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jLabel158)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel47Layout.setVerticalGroup(
            jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel47Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel158)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage30, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel157, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel154))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel47Layout.createSequentialGroup()
                        .addComponent(jLabel156)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel47Layout.createSequentialGroup()
                        .addGroup(jPanel47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel155))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox31)
                        .addGap(231, 231, 231))))
        );

        jLabel159.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel159.setText("Price:");

        jLabel160.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel160.setText("Quantity:");

        jLabel161.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel161.setText("Purchase:");

        jLabel162.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel162.setText("₱80.00");

        jSpinner32.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner32.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox32ActionPerformed(evt);
            }
        });

        jLabel163.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel163.setText("Pancit Canton");

        javax.swing.GroupLayout jPanel48Layout = new javax.swing.GroupLayout(jPanel48);
        jPanel48.setLayout(jPanel48Layout);
        jPanel48Layout.setHorizontalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel48Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel48Layout.createSequentialGroup()
                        .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel48Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner32, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel48Layout.createSequentialGroup()
                                .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel161)
                                    .addComponent(jLabel160)
                                    .addComponent(jLabel159, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(45, 45, 45)
                                .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jCheckBox32)
                                    .addComponent(jLabel162))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel48Layout.createSequentialGroup()
                        .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage31, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel48Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel163)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel48Layout.setVerticalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel48Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel163)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage31, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel162, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel159))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel48Layout.createSequentialGroup()
                        .addComponent(jLabel161)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel48Layout.createSequentialGroup()
                        .addGroup(jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel160))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox32)
                        .addGap(231, 231, 231))))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel48, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(319, 319, 319))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel46, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel48, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel47, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(335, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Noodles", jPanel9);

        jLabel164.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel164.setText("Price:");

        jLabel165.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel165.setText("Quantity:");

        jLabel166.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel166.setText("Purchase:");

        jLabel167.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel167.setText("₱48.00");

        jSpinner33.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner33.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox33ActionPerformed(evt);
            }
        });

        jLabel168.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel168.setText("Chunky Asado Siopao");

        javax.swing.GroupLayout jPanel49Layout = new javax.swing.GroupLayout(jPanel49);
        jPanel49.setLayout(jPanel49Layout);
        jPanel49Layout.setHorizontalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel49Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel49Layout.createSequentialGroup()
                        .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel49Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner33, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel49Layout.createSequentialGroup()
                                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel166)
                                    .addComponent(jLabel165)
                                    .addComponent(jLabel164, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel167)
                                    .addComponent(jCheckBox33))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelimage32, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel49Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jLabel168)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel49Layout.setVerticalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel49Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel168)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage32, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel167, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel164))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addComponent(jLabel166)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel49Layout.createSequentialGroup()
                        .addGroup(jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner33, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel165))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox33)
                        .addGap(231, 231, 231))))
        );

        jLabel169.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel169.setText("Price:");

        jLabel170.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel170.setText("Quantity:");

        jLabel171.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel171.setText("Purchase:");

        jLabel172.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel172.setText("₱143.00");

        jSpinner34.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner34.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox34ActionPerformed(evt);
            }
        });

        jLabel173.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel173.setText("3pc. Siopao Box");

        javax.swing.GroupLayout jPanel50Layout = new javax.swing.GroupLayout(jPanel50);
        jPanel50.setLayout(jPanel50Layout);
        jPanel50Layout.setHorizontalGroup(
            jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel50Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel50Layout.createSequentialGroup()
                        .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel50Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner34, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel50Layout.createSequentialGroup()
                                .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel171)
                                    .addComponent(jLabel170)
                                    .addComponent(jLabel169, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel172)
                                    .addComponent(jCheckBox34))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel50Layout.createSequentialGroup()
                        .addComponent(jLabelimage33, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel50Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel173)
                .addGap(61, 61, 61))
        );
        jPanel50Layout.setVerticalGroup(
            jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel50Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel173)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage33, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel172, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel169))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel50Layout.createSequentialGroup()
                        .addComponent(jLabel171)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel50Layout.createSequentialGroup()
                        .addGroup(jPanel50Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel170))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox34)
                        .addGap(231, 231, 231))))
        );

        jLabel174.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel174.setText("Price:");

        jLabel175.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel175.setText("Quantity:");

        jLabel176.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel176.setText("Purchase:");

        jLabel177.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel177.setText("₱42.00");

        jSpinner35.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner35.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox35ActionPerformed(evt);
            }
        });

        jLabel178.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel178.setText("2pc. Siomai");

        javax.swing.GroupLayout jPanel51Layout = new javax.swing.GroupLayout(jPanel51);
        jPanel51.setLayout(jPanel51Layout);
        jPanel51Layout.setHorizontalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel51Layout.createSequentialGroup()
                        .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel176)
                            .addComponent(jLabel175)
                            .addComponent(jLabel174, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox35)
                            .addComponent(jLabel177)
                            .addComponent(jSpinner35, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage34, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel51Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel178)
                .addGap(80, 80, 80))
        );
        jPanel51Layout.setVerticalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel51Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel178)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage34, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel177, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel174))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel51Layout.createSequentialGroup()
                        .addComponent(jLabel176)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel51Layout.createSequentialGroup()
                        .addGroup(jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel175))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox35)
                        .addGap(231, 231, 231))))
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel49, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(43, 43, 43)
                .addComponent(jPanel51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(315, 315, 315))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel49, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel51, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel50, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(310, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Dimsum", jPanel10);

        jLabel179.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel179.setText("Price:");

        jLabel180.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel180.setText("Quantity:");

        jLabel181.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel181.setText("Purchase:");

        jLabel182.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel182.setText("₱159.00");

        jSpinner36.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner36.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox36ActionPerformed(evt);
            }
        });

        jLabel183.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel183.setText("Beef Tapa");

        javax.swing.GroupLayout jPanel52Layout = new javax.swing.GroupLayout(jPanel52);
        jPanel52.setLayout(jPanel52Layout);
        jPanel52Layout.setHorizontalGroup(
            jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel52Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel52Layout.createSequentialGroup()
                        .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel52Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner36, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel52Layout.createSequentialGroup()
                                .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel181)
                                    .addComponent(jLabel180)
                                    .addComponent(jLabel179, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel182)
                                    .addComponent(jCheckBox36))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel52Layout.createSequentialGroup()
                        .addComponent(jLabelimage35, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel52Layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addComponent(jLabel183)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel52Layout.setVerticalGroup(
            jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel52Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel183)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage35, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel182, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel179))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel52Layout.createSequentialGroup()
                        .addComponent(jLabel181)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel52Layout.createSequentialGroup()
                        .addGroup(jPanel52Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel180))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox36)
                        .addGap(231, 231, 231))))
        );

        jLabel184.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel184.setText("Price:");

        jLabel185.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel185.setText("Quantity:");

        jLabel186.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel186.setText("Purchase:");

        jLabel187.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel187.setText("₱180.00");

        jSpinner37.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner37.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox37ActionPerformed(evt);
            }
        });

        jLabel188.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel188.setText("Chinese Pork Longganisa ");

        javax.swing.GroupLayout jPanel53Layout = new javax.swing.GroupLayout(jPanel53);
        jPanel53.setLayout(jPanel53Layout);
        jPanel53Layout.setHorizontalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel53Layout.createSequentialGroup()
                        .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel186)
                            .addComponent(jLabel185)
                            .addComponent(jLabel184, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel187)
                            .addComponent(jCheckBox37)
                            .addComponent(jSpinner37, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage36, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel188)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel53Layout.setVerticalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel53Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel188)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage36, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel187, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel184))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel53Layout.createSequentialGroup()
                        .addComponent(jLabel186)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel53Layout.createSequentialGroup()
                        .addGroup(jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel185))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox37)
                        .addGap(231, 231, 231))))
        );

        jLabel189.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel189.setText("Price:");

        jLabel190.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel190.setText("Quantity:");

        jLabel191.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel191.setText("Purchase:");

        jLabel192.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel192.setText("₱180.00");

        jSpinner38.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner38.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox38ActionPerformed(evt);
            }
        });

        jLabel193.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel193.setText("King's Special");

        javax.swing.GroupLayout jPanel54Layout = new javax.swing.GroupLayout(jPanel54);
        jPanel54.setLayout(jPanel54Layout);
        jPanel54Layout.setHorizontalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel54Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel54Layout.createSequentialGroup()
                        .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel54Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jSpinner38, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel54Layout.createSequentialGroup()
                                .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel191)
                                    .addComponent(jLabel190)
                                    .addComponent(jLabel189, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel192)
                                    .addComponent(jCheckBox38))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(33, 33, 33))
                    .addGroup(jPanel54Layout.createSequentialGroup()
                        .addComponent(jLabelimage37, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel54Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel193)
                .addGap(61, 61, 61))
        );
        jPanel54Layout.setVerticalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel54Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel193)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage37, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel192, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel189))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel54Layout.createSequentialGroup()
                        .addComponent(jLabel191)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel54Layout.createSequentialGroup()
                        .addGroup(jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel190))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox38)
                        .addGap(231, 231, 231))))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel53, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel52, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(62, 62, 62)
                .addComponent(jPanel54, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(288, 288, 288))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel52, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel54, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel53, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(307, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Breakfast", jPanel11);

        jLabel194.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel194.setText("Price:");

        jLabel195.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel195.setText("Quantity:");

        jLabel196.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel196.setText("Purchase:");

        jLabel197.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel197.setText("₱64.00");

        jSpinner39.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner39.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox39ActionPerformed(evt);
            }
        });

        jLabel198.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel198.setText("Chicharap");

        javax.swing.GroupLayout jPanel55Layout = new javax.swing.GroupLayout(jPanel55);
        jPanel55.setLayout(jPanel55Layout);
        jPanel55Layout.setHorizontalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel55Layout.createSequentialGroup()
                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel55Layout.createSequentialGroup()
                                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel196)
                                    .addComponent(jLabel195)
                                    .addComponent(jLabel194, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel197)
                                    .addComponent(jCheckBox39)
                                    .addComponent(jSpinner39, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabelimage38, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel198)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel55Layout.setVerticalGroup(
            jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel55Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel198)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage38, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel197, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel194))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addComponent(jLabel196)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel55Layout.createSequentialGroup()
                        .addGroup(jPanel55Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel195))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox39)
                        .addGap(231, 231, 231))))
        );

        jLabel199.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel199.setText("Price:");

        jLabel200.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel200.setText("Quantity:");

        jLabel201.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel201.setText("Purchase:");

        jLabel202.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel202.setText("₱53.00");

        jSpinner40.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner40.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox40ActionPerformed(evt);
            }
        });

        jLabel203.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel203.setText("Buchi");

        javax.swing.GroupLayout jPanel56Layout = new javax.swing.GroupLayout(jPanel56);
        jPanel56.setLayout(jPanel56Layout);
        jPanel56Layout.setHorizontalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel56Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel56Layout.createSequentialGroup()
                        .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel201)
                            .addComponent(jLabel200)
                            .addComponent(jLabel199, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel202)
                            .addComponent(jCheckBox40)
                            .addComponent(jSpinner40, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage39, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel56Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel203)
                .addGap(88, 88, 88))
        );
        jPanel56Layout.setVerticalGroup(
            jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel56Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel203)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage39, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel202, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel199))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel56Layout.createSequentialGroup()
                        .addComponent(jLabel201)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel56Layout.createSequentialGroup()
                        .addGroup(jPanel56Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel200))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox40)
                        .addGap(231, 231, 231))))
        );

        jLabel204.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel204.setText("Price:");

        jLabel205.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel205.setText("Quantity:");

        jLabel206.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel206.setText("Purchase:");

        jLabel207.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel207.setText("₱32.00");

        jSpinner41.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner41.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox41ActionPerformed(evt);
            }
        });

        jLabel208.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel208.setText("Extra Plain Rice");

        javax.swing.GroupLayout jPanel57Layout = new javax.swing.GroupLayout(jPanel57);
        jPanel57.setLayout(jPanel57Layout);
        jPanel57Layout.setHorizontalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel57Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel57Layout.createSequentialGroup()
                        .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel206)
                            .addComponent(jLabel205)
                            .addComponent(jLabel204, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel207)
                            .addComponent(jCheckBox41)
                            .addComponent(jSpinner41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage40, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel57Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel208)
                .addGap(54, 54, 54))
        );
        jPanel57Layout.setVerticalGroup(
            jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel57Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel208)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage40, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel207, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel204))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel57Layout.createSequentialGroup()
                        .addComponent(jLabel206)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel57Layout.createSequentialGroup()
                        .addGroup(jPanel57Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel205))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox41)
                        .addGap(231, 231, 231))))
        );

        jLabel209.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel209.setText("Price:");

        jLabel210.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel210.setText("Quantity:");

        jLabel211.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel211.setText("Purchase:");

        jLabel212.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel212.setText("₱48.00");

        jSpinner42.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner42.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox42ActionPerformed(evt);
            }
        });

        jLabel213.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel213.setText("Extra Egg Fried Rice");

        javax.swing.GroupLayout jPanel58Layout = new javax.swing.GroupLayout(jPanel58);
        jPanel58.setLayout(jPanel58Layout);
        jPanel58Layout.setHorizontalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel58Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel58Layout.createSequentialGroup()
                        .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel211)
                            .addComponent(jLabel210)
                            .addComponent(jLabel209, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel212)
                            .addComponent(jCheckBox42)
                            .addComponent(jSpinner42, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage41, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel58Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel213)
                .addGap(34, 34, 34))
        );
        jPanel58Layout.setVerticalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel58Layout.createSequentialGroup()
                .addComponent(jLabel213)
                .addGap(13, 13, 13)
                .addComponent(jLabelimage41, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel212, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel209))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel58Layout.createSequentialGroup()
                        .addComponent(jLabel211)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel58Layout.createSequentialGroup()
                        .addGroup(jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel210))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox42)
                        .addGap(231, 231, 231))))
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel57, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel55, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel56, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel58, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(346, 346, 346))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel56, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel55, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel57, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel58, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(347, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Side Dishes", jPanel12);

        jLabel214.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel214.setText("Price:");

        jLabel215.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel215.setText("Quantity:");

        jLabel216.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel216.setText("Purchase:");

        jLabel217.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel217.setText("₱73.00");

        jSpinner43.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner43.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox43ActionPerformed(evt);
            }
        });

        jLabel218.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel218.setText("SuperSangkap Halo-Halo");

        javax.swing.GroupLayout jPanel59Layout = new javax.swing.GroupLayout(jPanel59);
        jPanel59.setLayout(jPanel59Layout);
        jPanel59Layout.setHorizontalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel59Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel218)
                    .addGroup(jPanel59Layout.createSequentialGroup()
                        .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel216)
                            .addComponent(jLabel215)
                            .addComponent(jLabel214, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel217)
                            .addComponent(jCheckBox43)
                            .addComponent(jSpinner43, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage42, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel59Layout.setVerticalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel59Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel218)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage42, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel217, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel214))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel59Layout.createSequentialGroup()
                        .addComponent(jLabel216)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel59Layout.createSequentialGroup()
                        .addGroup(jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel215))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox43)
                        .addGap(231, 231, 231))))
        );

        jLabel219.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel219.setText("Price:");

        jLabel220.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel220.setText("Quantity:");

        jLabel221.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel221.setText("Purchase:");

        jLabel222.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel222.setText("₱58.00");

        jSpinner44.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner44.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox44ActionPerformed(evt);
            }
        });

        jLabel223.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel223.setText("Iced Tea");

        javax.swing.GroupLayout jPanel60Layout = new javax.swing.GroupLayout(jPanel60);
        jPanel60.setLayout(jPanel60Layout);
        jPanel60Layout.setHorizontalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel60Layout.createSequentialGroup()
                .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel60Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel60Layout.createSequentialGroup()
                                .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel221)
                                    .addComponent(jLabel220)
                                    .addComponent(jLabel219, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel222)
                                    .addComponent(jCheckBox44)
                                    .addComponent(jSpinner44, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabelimage43, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel60Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel223)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel60Layout.setVerticalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel60Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel223)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage43, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel222, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel219))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel60Layout.createSequentialGroup()
                        .addComponent(jLabel221)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel60Layout.createSequentialGroup()
                        .addGroup(jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel220))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox44)
                        .addGap(231, 231, 231))))
        );

        jLabel224.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel224.setText("Price:");

        jLabel225.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel225.setText("Quantity:");

        jLabel226.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel226.setText("Purchase:");

        jLabel227.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel227.setText("₱53.00");

        jSpinner45.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner45.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox45ActionPerformed(evt);
            }
        });

        jLabel228.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel228.setText("Coke Zero");

        javax.swing.GroupLayout jPanel61Layout = new javax.swing.GroupLayout(jPanel61);
        jPanel61.setLayout(jPanel61Layout);
        jPanel61Layout.setHorizontalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel61Layout.createSequentialGroup()
                        .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel226)
                            .addComponent(jLabel225)
                            .addComponent(jLabel224, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel227)
                            .addComponent(jCheckBox45)
                            .addComponent(jSpinner45, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage44, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel61Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel228)
                .addGap(76, 76, 76))
        );
        jPanel61Layout.setVerticalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel228)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage44, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel227, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel224))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel61Layout.createSequentialGroup()
                        .addComponent(jLabel226)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel61Layout.createSequentialGroup()
                        .addGroup(jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner45, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel225))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox45)
                        .addGap(231, 231, 231))))
        );

        jLabel229.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel229.setText("Price:");

        jLabel230.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel230.setText("Quantity:");

        jLabel231.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel231.setText("Purchase:");

        jLabel232.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel232.setText("₱53.00");

        jSpinner46.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jSpinner46.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jCheckBox46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox46ActionPerformed(evt);
            }
        });

        jLabel233.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel233.setText("Sprite");

        javax.swing.GroupLayout jPanel62Layout = new javax.swing.GroupLayout(jPanel62);
        jPanel62.setLayout(jPanel62Layout);
        jPanel62Layout.setHorizontalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel62Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel62Layout.createSequentialGroup()
                        .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel231)
                            .addComponent(jLabel230)
                            .addComponent(jLabel229, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel232)
                            .addComponent(jCheckBox46)
                            .addComponent(jSpinner46, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabelimage45, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel62Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel233)
                .addGap(90, 90, 90))
        );
        jPanel62Layout.setVerticalGroup(
            jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel62Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel233)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelimage45, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel232, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel229))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel62Layout.createSequentialGroup()
                        .addComponent(jLabel231)
                        .addGap(226, 226, 226))
                    .addGroup(jPanel62Layout.createSequentialGroup()
                        .addGroup(jPanel62Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jSpinner46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel230))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox46)
                        .addGap(231, 231, 231))))
        );

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel59, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel60, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel62, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(340, 340, 340))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel59, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel60, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel61, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(320, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Dessert & Drinks", jPanel13);

        jPanel15.setBackground(new java.awt.Color(235, 235, 235));

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Alex Brush", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("CHOWKING");

        jTextTime.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jTextTime.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jTextDate.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jTextDate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(373, 373, 373)
                .addComponent(jTextTime, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextDate, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTextTime, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTextDate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addContainerGap())
        );

        jPanel17.setBackground(new java.awt.Color(204, 204, 204));

        jTextFielcash.setEditable(false);
        jTextFielcash.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jTextFielcash.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFielcash.setText("0.0");

        jTextFieldchange.setEditable(false);
        jTextFieldchange.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jTextFieldchange.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldchange.setText("0.0");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel2.setText("Total");

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel19.setText("Change");

        jLabelcash.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabelcash.setText("Cash");

        jTextFieldtotal1.setEditable(false);
        jTextFieldtotal1.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jTextFieldtotal1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldtotal1.setText("0.0");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PRODUCT ID", "PRODUCT NAME", "QUANTITY", "PRICE"
            }
        ));
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
        }

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jLabelcash))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jTextFielcash)
                            .addComponent(jTextFieldchange, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTextFieldtotal1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(57, 57, 57))
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 481, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldtotal1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelcash)
                    .addComponent(jTextFielcash, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jTextFieldchange, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );

        jPanel14.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btntotal.setBackground(new java.awt.Color(255, 51, 0));
        btntotal.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        btntotal.setForeground(new java.awt.Color(255, 255, 255));
        btntotal.setText("Pay");
        btntotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntotalActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 255, 0));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Receipt");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(102, 204, 0));
        btnDelete.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnexit.setBackground(new java.awt.Color(0, 204, 255));
        btnexit.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("Exit");
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });

        btnReset1.setBackground(new java.awt.Color(51, 51, 255));
        btnReset1.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        btnReset1.setForeground(new java.awt.Color(255, 255, 255));
        btnReset1.setText("Reset");
        btnReset1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReset1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btntotal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnReset1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(316, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnexit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btntotal, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnReset1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(377, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 913, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(92, 92, 92)
                        .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(69, 69, 69))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 961, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        // Exit System
        
        System.exit(0);
    }//GEN-LAST:event_btnexitActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
       DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        int RemoveItem = jTable1.getSelectedRow();
        if(RemoveItem >= 0 )
        {
        model.removeRow(RemoveItem);
        
        }
        ItemCost();
    }//GEN-LAST:event_btnDeleteActionPerformed

   
    
    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        int qty = Integer.parseInt(jSpinner1.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox1.isSelected()){
         x++;
            
String size [] = {"Holiday Chow Feast A with Drinks ₱422.00", "Holiday Chow Feast A without Drinks ₱306.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Holiday Chow Feast A with Drinks ₱422.00"){
           

               
            price = qty*422.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel5.getText(),
            jSpinner1.getValue(),
            df.format(price),
            });
            ItemCost();
            
           
           }
            if (selectedValue == "Holiday Chow Feast A without Drinks ₱306.00"){
           
            price = qty*306.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel5.getText(),
            jSpinner1.getValue(),
            df.format(price),
            });
           
           
           }
            
             
           }
            jSpinner1.setValue(0);
               jCheckBox1.setSelected(false);
        }
        else {
        jCheckBox1.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        int qty = Integer.parseInt(jSpinner2.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox2.isSelected()){
         x++;
           
            String size [] = {"Holiday Chow Feast B with Drinks ₱867.00", "Holiday Chow Feast B without Drinks ₱635.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Holiday Chow Feast B with Drinks ₱867.00"){
             
           price = qty*867.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel9.getText(),
            jSpinner2.getValue(),
            df.format(price),
            });
            
            duedate();
           
           }
            if (selectedValue == "Holiday Chow Feast B without Drinks ₱635.00"){
            
            price = qty*635.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel9.getText(),
            jSpinner2.getValue(),
            df.format(price),
            });
           
            duedate();
           
           }
            
             
           }
            jSpinner2.setValue(0);
               jCheckBox2.setSelected(false);
        
        }
        else {
        jCheckBox2.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
       int qty = Integer.parseInt(jSpinner3.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox3.isSelected()){
         x++;
            
            String size [] = {"Holiday Chow Feast D with Drinks  ₱973.00", "Holiday Chow Feast D without Drinks ₱741.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Holiday Chow Feast D with Drinks  ₱973.00"){
             
          price = qty*973.00;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel14.getText(),
            jSpinner3.getValue(),
            df.format(price),
            });
            
            duedate();
            
           }
            if (selectedValue == "Holiday Chow Feast D without Drinks ₱741.00"){
           
                
           price = qty*741.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel14.getText(),
            jSpinner3.getValue(),
            df.format(price),
            });
            
            duedate();
            
           }
            
             
           }
           jSpinner3.setValue(0);
               jCheckBox3.setSelected(false);
        }
        else {
        jCheckBox3.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void btntotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntotalActionPerformed
        // TODO add your handling code here:
       try { 
        if (total == 0.0){
        JOptionPane.showMessageDialog(this, "You haven't selected any item");
        
        }else{
      double total = Double.parseDouble(jTextFieldtotal1.getText());
                double pay = Double.parseDouble(jTextFielcash.getText());
         
            String money;
          money = JOptionPane.showInputDialog(this, "Enter Your Cash: ");
         
           
        cash = Double.parseDouble(money);
    
     
         
        
         if (total <= cash){
               change = cash-total;
   
       String dbal = String.format("%.2f", change);
     jTextFieldchange.setText(dbal);
             btntotal.setEnabled(false);
            jTextFieldtotal1.setText(String.valueOf(df.format(total)));
   jTextFieldchange.setText(String.valueOf(df.format(change)));
    jTextFielcash.setText(String.valueOf(df.format(cash)));

        
         
     JOptionPane.showMessageDialog(this, "Sales Completed!");
    
   
     bill();
    
    
          }
          else {
                    JOptionPane.showMessageDialog(this, "Insufficient Cash!");
                }
        }}catch(NumberFormatException e) {
            
       JOptionPane.showMessageDialog(this, "Invalid Please Input a Number! ");
       }
       
    }//GEN-LAST:event_btntotalActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
       int qty = Integer.parseInt(jSpinner4.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox4.isSelected()){
         x++;
            
             String size [] = {"Siopao + Milksha Bundle with Drinks ₱254.00", "Siopao + Milksha Bundle without Drinks ₱154.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Siopao + Milksha Bundle with Drinks ₱254.00"){
             
          price = qty*254;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel23.getText(),
            jSpinner4.getValue(),
            df.format(price),
            });
            
            duedate();
            
           }
           if (selectedValue == "Siopao + Milksha Bundle without Drinks ₱154.00"){
             
          price = qty*154;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel23.getText(),
            jSpinner4.getValue(),
            df.format(price),
            });
            
            duedate();
            
           }
           jSpinner4.setValue(0);
               jCheckBox4.setSelected(false);
        }
        }
        else {
        jCheckBox4.setSelected(false);
        }
        
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
       int qty = Integer.parseInt(jSpinner5.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox5.isSelected()){
         x++;
            
            String size [] = {"4pc Steamed Pork Siomai+Milksha Bundle with Drinks ₱270.00", "4pc Steamed Pork Siomai+Milksha Bundle without Drinks ₱170.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "4pc Steamed Pork Siomai+Milksha Bundle with Drinks ₱270.00"){
             
          price = qty*270;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel28.getText(),
            jSpinner5.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
           if (selectedValue == "4pc Steamed Pork Siomai+Milksha Bundle without Drinks ₱170.00"){
             
          price = qty*170;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel28.getText(),
            jSpinner5.getValue(),
            df.format(price),
            });
            
            duedate();
            
           }
           jSpinner5.setValue(0);
               jCheckBox5.setSelected(false);
        }
        }
        else {
        jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
       int qty = Integer.parseInt(jSpinner6.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox6.isSelected()){
         x++;
           
             String size [] = {"Pancit Canton + Milksha Bundle with Drinks ₱286.00", "Pancit Canton + Milksha Bundle without Drinks ₱186.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your meal", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Pancit Canton + Milksha Bundle with Drinks ₱286.00"){
             
          price = qty*286;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel33.getText(),
            jSpinner6.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
           if (selectedValue == "Pancit Canton + Milksha Bundle without Drinks ₱186.00"){
             
          price = qty*186;
            total += price;
            
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel33.getText(),
            jSpinner6.getValue(),
            df.format(price),
            });
        
            duedate();
            
           }
           jSpinner6.setValue(0);
               jCheckBox6.setSelected(false);
        }
        }
        else {
        jCheckBox6.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        int qty = Integer.parseInt(jSpinner7.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox7.isSelected()){
         x++;
            
            String size [] = {"Steamed Siomai Platter ₱302.00", "Fried Siomai Platter ₱302.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Steamed Siomai Platter ₱302.00"){
             jLabel38.setText("Steamed Siomai Platter");
           price = qty*302.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel38.getText(),
            jSpinner7.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Fried Siomai Platter ₱302.00"){
           jLabel38.setText("Fried Siomai Platter");
                
            price = qty*302.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel38.getText(),
            jSpinner7.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner7.setValue(0);
               jCheckBox7.setSelected(false);
             
           }
        }
        else {
        jCheckBox7.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox9ActionPerformed
       int qty = Integer.parseInt(jSpinner9.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox9.isSelected()){
         x++;
            
             String size [] = {"Fried Pork Siomai Starts at ₱101.00", "Steamed Pork Siomai Starts at ₱101.00", "Fried Beef Siomai Starts at ₱101.00", "Steamed Beef Siomai Starts at ₱101.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your topping", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Fried Pork Siomai Starts at ₱101.00"){
             
           price = qty*101.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel48.getText(),
            jSpinner9.getValue(),
           df.format(price),
            });
           
            duedate();
            
           }
            if (selectedValue == "Steamed Pork Siomai Starts at ₱101.00"){
           
                
           price = qty*101.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel48.getText(),
            jSpinner9.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
             if (selectedValue == "Fried Beef Siomai Starts at ₱101.00"){
             
            price = qty*101.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel48.getText(),
            jSpinner9.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Steamed Beef Siomai Starts at ₱101.00"){
           
                
            price = qty*101.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel48.getText(),
            jSpinner9.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            
           }
            jSpinner9.setValue(0);
               jCheckBox9.setSelected(false);
        }
        else {
        jCheckBox9.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox9ActionPerformed

    private void jCheckBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox10ActionPerformed
        int qty = Integer.parseInt(jSpinner10.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox10.isSelected()){
         x++;
          String size [] = {"Chinese-Style Fried Chicken Lauriat with Drinks ₱301.00", "Chinese-Style Fried Chicken Lauriat without Drinks ₱201.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chinese-Style Fried Chicken Lauriat with Drinks ₱301.00"){
            
           price = qty*301.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel53.getText(),
            jSpinner10.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chinese-Style Fried Chicken Lauriat without Drinks ₱201.00"){
           
                
            price = qty*201.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel53.getText(),
            jSpinner10.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner10.setValue(0);
               jCheckBox10.setSelected(false);
             
           }
        }
        else {
        jCheckBox10.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox10ActionPerformed

    private void jCheckBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox11ActionPerformed
       int qty = Integer.parseInt(jSpinner11.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox11.isSelected()){
         x++;
            
            String size [] = {"8pc. Chinese-Style Fried Chicken with Drinks ₱720.00", "8pc. Chinese-Style Fried Chicken without Drinks ₱620.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "8pc. Chinese-Style Fried Chicken with Drinks ₱720.00"){
            
           price = qty*720.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel58.getText(),
            jSpinner11.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "8pc. Chinese-Style Fried Chicken without Drinks ₱620.00"){
           
                
            price = qty*620.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel58.getText(),
            jSpinner11.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner11.setValue(0);
               jCheckBox11.setSelected(false);
             
           }
        }
        else {
        jCheckBox11.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox11ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
        int qty = Integer.parseInt(jSpinner12.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox12.isSelected()){
         x++;
            
            String size [] = {"Family Lauriat Set A (Good for 3) with Drinks ₱725.00", "Family Lauriat Set A (Good for 3) without Drinks ₱625.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Family Lauriat Set A (Good for 3) with Drinks ₱725.00"){
            
           price = qty*725.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel63.getText(),
            jSpinner12.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Family Lauriat Set A (Good for 3) without Drinks ₱625.00"){
           
                
            price = qty*625.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel63.getText(),
            jSpinner12.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner12.setValue(0);
               jCheckBox12.setSelected(false);
             
           }
        }
        else {
        jCheckBox12.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void jCheckBox13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox13ActionPerformed
        int qty = Integer.parseInt(jSpinner13.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox13.isSelected()){
         x++;
            
             String size [] = {"Family Lauriat Set B (Good for 4) with Drinks ₱1043.00", "Family Lauriat Set A (Good for 3) without Drinks ₱943.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Family Lauriat Set B (Good for 4) with Drinks ₱1043.00"){
            
           price = qty*1043.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel68.getText(),
            jSpinner13.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Family Lauriat Set A (Good for 3) without Drinks ₱943.00"){
           
                
            price = qty*943.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel68.getText(),
            jSpinner13.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner13.setValue(0);
               jCheckBox13.setSelected(false);
             
           }
        }
        else {
        jCheckBox13.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox13ActionPerformed

    private void jCheckBox14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox14ActionPerformed
      int qty = Integer.parseInt(jSpinner14.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox14.isSelected()){
         x++;
            String size [] = {"Sweet & Sour Pork-Chao Fan Family Bundle with Drinks ₱635.00", "Sweet & Sour Pork-Chao Fan Family Bundle without Drinks ₱535.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Pork-Chao Fan Family Bundle with Drinks ₱635.00"){
            
           price = qty*635.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel73.getText(),
            jSpinner14.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Pork-Chao Fan Family Bundle without Drinks ₱535.00"){
           
                
            price = qty*535.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel73.getText(),
            jSpinner14.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner14.setValue(0);
               jCheckBox14.setSelected(false);
             
           }
        }
        else {
        jCheckBox14.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox14ActionPerformed

    private void jCheckBox15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox15ActionPerformed
       int qty = Integer.parseInt(jSpinner15.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox15.isSelected()){
         x++;
            
             String size [] = {"Pork Chao Fan with Drinks ₱102.00", "Pork Chao Fan without Drinks ₱52.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Pork Chao Fan with Drinks ₱102.00"){
            
           price = qty*102.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel78.getText(),
            jSpinner15.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Pork Chao Fan without Drinks ₱52.00"){
           
                
            price = qty*52.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel78.getText(),
            jSpinner15.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner15.setValue(0);
               jCheckBox15.setSelected(false);
             
           }
        }
        else {
        jCheckBox15.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox15ActionPerformed

    private void jCheckBox17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox17ActionPerformed
        int qty = Integer.parseInt(jSpinner17.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox17.isSelected()){
         x++;
            
            String size [] = {"Fried Beef Siomai Starts at ₱138.00", "Fried Pork Siomai Starts at ₱138.00", "Lumpia Shanghai Starts at ₱138.00", "Steamed Beef Siomai Starts at ₱138.00", "Steamed Pork Siomai Starts at ₱138.00", "Steamed Chicken Siomai Starts at ₱138.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose your topping", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Fried Beef Siomai Starts at ₱138.00"){
             
            price = qty*138.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            
            duedate();
            
           }
            if (selectedValue == "Fried Pork Siomai Starts at ₱138.00"){
           
                
            price = qty*138.00;
            total += price;
           
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
             if (selectedValue == "Lumpia Shanghai Starts at ₱138.00"){
             
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            if (selectedValue == "Steamed Beef Siomai Starts at ₱138.00"){
           
                
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            if (selectedValue == "Steamed Pork Siomai Starts at ₱138.00"){
           
                
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            if (selectedValue == "Steamed Chicken Siomai Starts at ₱138.00"){
           
                
          price = qty*138.00;
            total += price;
            
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel88.getText(),
            jSpinner17.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            
           }
            jSpinner17.setValue(0);
               jCheckBox17.setSelected(false);
        }
        else {
        jCheckBox17.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox17ActionPerformed

    private void jCheckBox18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox18ActionPerformed
        int qty = Integer.parseInt(jSpinner18.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox18.isSelected()){
         x++;
            
             String size [] = {"Beef Chao Fan with Drinks ₱194.00", "Beef Chao Fan without Drinks ₱94.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Beef Chao Fan with Drinks ₱194.00"){
            
           price = qty*194.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel93.getText(),
            jSpinner18.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Beef Chao Fan without Drinks ₱94.00"){
           
                
            price = qty*94.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel93.getText(),
            jSpinner18.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner18.setValue(0);
               jCheckBox18.setSelected(false);
             
           }
        }
        else {
        jCheckBox18.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox18ActionPerformed

    private void jCheckBox19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox19ActionPerformed
      int qty = Integer.parseInt(jSpinner19.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox19.isSelected()){
         x++;
            
              String size [] = {"6pc. Chinese-Style Fried Chicken with Drinks ₱588.00", "6pc. Chinese-Style Fried Chicken without Drinks ₱488.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "6pc. Chinese-Style Fried Chicken with Drinks ₱588.00"){
            
           price = qty*588.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel98.getText(),
            jSpinner19.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "6pc. Chinese-Style Fried Chicken without Drinks ₱488.00"){
           
                
            price = qty*488.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel98.getText(),
            jSpinner19.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner19.setValue(0);
               jCheckBox19.setSelected(false);
             
           }
        }
        else {
        jCheckBox19.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox19ActionPerformed

    private void jCheckBox20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox20ActionPerformed
       int qty = Integer.parseInt(jSpinner20.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox20.isSelected()){
         x++;
            
             String size [] = {"Fried Chicken-Pancit Family Platter with Drinks ₱826.00", "Fried Chicken-Pancit Family Platter without Drinks ₱726.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Fried Chicken-Pancit Family Platter with Drinks ₱826.00"){
            
           price = qty*826.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel103.getText(),
            jSpinner20.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Fried Chicken-Pancit Family Platter without Drinks ₱726.00"){
           
                
            price = qty*726.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel103.getText(),
            jSpinner20.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner20.setValue(0);
               jCheckBox20.setSelected(false);
             
           }
        }
        else {
        jCheckBox20.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox20ActionPerformed

    private void jCheckBox21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox21ActionPerformed
        int qty = Integer.parseInt(jSpinner21.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox21.isSelected()){
         x++;
            
             String size [] = {"2pc. Chinese-Style Fried Chicken with Drinks ₱280.00", "2pc. Chinese-Style Fried Chicken without Drinks ₱180.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "2pc. Chinese-Style Fried Chicken with Drinks ₱280.00"){
            
           price = qty*280.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel108.getText(),
            jSpinner21.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "2pc. Chinese-Style Fried Chicken without Drinks ₱180.00"){
           
                
            price = qty*180.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel108.getText(),
            jSpinner21.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner21.setValue(0);
               jCheckBox21.setSelected(false);
             
           }
        }
        else {
        jCheckBox21.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox21ActionPerformed

    private void jCheckBox22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox22ActionPerformed
        int qty = Integer.parseInt(jSpinner22.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox22.isSelected()){
         x++;
            
                         String size [] = {"Beef Chao Fan w/ Fried Chicken with Drinks ₱286.00", "Beef Chao Fan w/ Fried Chicken without Drinks ₱186.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Beef Chao Fan w/ Fried Chicken with Drinks ₱286.00"){
            
           price = qty*286.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel113.getText(),
            jSpinner22.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Beef Chao Fan w/ Fried Chicken without Drinks ₱186.00"){
           
                
            price = qty*186.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel113.getText(),
            jSpinner22.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner22.setValue(0);
               jCheckBox22.setSelected(false);
             
           }
        }
        else {
        jCheckBox22.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox22ActionPerformed

    private void jCheckBox23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox23ActionPerformed
        int qty = Integer.parseInt(jSpinner23.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox23.isSelected()){
         x++;
            
              String size [] = {"Chick 'n Sauce with Drinks ₱254.00", "Chick 'n Sauce without Drinks ₱154.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chick 'n Sauce with Drinks ₱254.00"){
            
           price = qty*254.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel118.getText(),
            jSpinner23.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chick 'n Sauce without Drinks ₱154.00"){
           
                
            price = qty*154.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel118.getText(),
            jSpinner23.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner23.setValue(0);
               jCheckBox23.setSelected(false);
             
           }
        }
        else {
        jCheckBox23.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox23ActionPerformed

    private void jCheckBox24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox24ActionPerformed
        int qty = Integer.parseInt(jSpinner24.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox24.isSelected()){
         x++;
            
            String size [] = {"Sweet & Sour Chicken with Drinks ₱254.00", "Sweet & Sour Chicken without Drinks ₱154.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Chicken with Drinks ₱254.00"){
            
           price = qty*254.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel123.getText(),
            jSpinner24.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Chicken without Drinks ₱154.00"){
           
                
            price = qty*154.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel123.getText(),
            jSpinner24.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner24.setValue(0);
               jCheckBox24.setSelected(false);
             
           }
        }
        else {
        jCheckBox24.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox24ActionPerformed

    private void jCheckBox25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox25ActionPerformed
        int qty = Integer.parseInt(jSpinner25.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox25.isSelected()){
         x++;
            
             String size [] = {"Sweet & Sour Pork with Drinks ₱254.00", "Sweet & Sour Pork without Drinks ₱154.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Pork with Drinks ₱254.00"){
            
           price = qty*254.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel128.getText(),
            jSpinner25.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Pork without Drinks ₱154.00"){
           
                
            price = qty*154.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel128.getText(),
            jSpinner25.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner25.setValue(0);
               jCheckBox25.setSelected(false);
             
           }
        }
        else {
        jCheckBox25.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox25ActionPerformed

    private void jCheckBox26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox26ActionPerformed
       int qty = Integer.parseInt(jSpinner26.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox26.isSelected()){
         x++;
            
             String size [] = {"Sweet & Sour Fish with Drinks ₱259.00", "Sweet & Sour Fish without Drinks ₱159.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Fish with Drinks ₱259.00"){
            
           price = qty*259.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel133.getText(),
            jSpinner26.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Fish without Drinks ₱159.00"){
           
                
            price = qty*159.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel133.getText(),
            jSpinner26.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner26.setValue(0);
               jCheckBox26.setSelected(false);
             
           }
        }
        else {
        jCheckBox26.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox26ActionPerformed

    private void jCheckBox27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox27ActionPerformed
      int qty = Integer.parseInt(jSpinner27.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox27.isSelected()){
         x++;
            
                          String size [] = {"Chick 'n Sauce Lauriat with Drinks ₱317.00", "Chick 'n Sauce Lauriat without Drinks ₱217.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chick 'n Sauce Lauriat with Drinks ₱317.00"){
            
           price = qty*317.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel138.getText(),
            jSpinner27.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chick 'n Sauce Lauriat without Drinks ₱217.00"){
           
                
            price = qty*217.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel138.getText(),
            jSpinner27.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner27.setValue(0);
               jCheckBox27.setSelected(false);
             
           }
        }
        else {
        jCheckBox27.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox27ActionPerformed

    private void jCheckBox28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox28ActionPerformed
       int qty = Integer.parseInt(jSpinner28.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox28.isSelected()){
         x++;
            
             String size [] = {"Sweet & Sour Pork Lauriat with Drinks ₱317.00", "Sweet & Sour Pork Lauriat without Drinks ₱217.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Pork Lauriat with Drinks ₱317.00"){
            
           price = qty*317.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel143.getText(),
            jSpinner28.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Pork Lauriat without Drinks ₱217.00"){
           
                
            price = qty*217.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel143.getText(),
            jSpinner28.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner28.setValue(0);
               jCheckBox28.setSelected(false);
             
           }
        }
        else {
        jCheckBox28.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox28ActionPerformed

    private void jCheckBox29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox29ActionPerformed
       int qty = Integer.parseInt(jSpinner29.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox29.isSelected()){
         x++;
            
            String size [] = {"Sweet & Sour Fish Lauriat with Drinks ₱323.00", "Sweet & Sour Fish Lauriat without Drinks ₱223.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Sweet & Sour Fish Lauriat with Drinks ₱323.00"){
            
           price = qty*323.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel148.getText(),
            jSpinner29.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Sweet & Sour Fish Lauriat without Drinks ₱223.00"){
           
                
            price = qty*223.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel148.getText(),
            jSpinner29.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner29.setValue(0);
               jCheckBox29.setSelected(false);
             
           }
        }
        else {
        jCheckBox29.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox29ActionPerformed

    private void jCheckBox30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox30ActionPerformed
       int qty = Integer.parseInt(jSpinner30.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox30.isSelected()){
         x++;
            
             String size [] = {"Beef Mami with Drinks ₱280.00", "Beef Mami without Drinks ₱180.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Beef Mami with Drinks ₱280.00"){
            
           price = qty*280.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel153.getText(),
            jSpinner30.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Beef Mami without Drinks ₱180.00"){
           
                
            price = qty*180.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel153.getText(),
            jSpinner30.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner30.setValue(0);
               jCheckBox30.setSelected(false);
             
           }
        }
        else {
        jCheckBox30.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox30ActionPerformed

    private void jCheckBox31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox31ActionPerformed
      int qty = Integer.parseInt(jSpinner31.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox31.isSelected()){
         x++;
            
             String size [] = {"Beef Wonton Mami with Drinks ₱317.00", "Beef Wonton Mami without Drinks ₱217.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Beef Wonton Mami with Drinks ₱317.00"){
            
           price = qty*317.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel158.getText(),
            jSpinner31.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Beef Wonton Mami without Drinks ₱217.00"){
           
                
            price = qty*217.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel158.getText(),
            jSpinner31.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner31.setValue(0);
               jCheckBox31.setSelected(false);
             
           }
        }
        else {
        jCheckBox31.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox31ActionPerformed

    private void jCheckBox32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox32ActionPerformed
        int qty = Integer.parseInt(jSpinner32.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox32.isSelected()){
         x++;
            
            String size [] = {"Pancit Canton with Drinks ₱180.00", "Pancit Canton without Drinks ₱80.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Pancit Canton with Drinks ₱180.00"){
            
           price = qty*180.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel163.getText(),
            jSpinner32.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Pancit Canton without Drinks ₱80.00"){
           
                
            price = qty*80.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel163.getText(),
            jSpinner32.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner32.setValue(0);
               jCheckBox32.setSelected(false);
             
           }
        }
        else {
        jCheckBox32.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox32ActionPerformed

    private void jCheckBox33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox33ActionPerformed
        int qty = Integer.parseInt(jSpinner33.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox33.isSelected()){
         x++;
            
             String size [] = {"Chunky Asado Siopao with Drinks ₱148.00", "Chunky Asado Siopao without Drinks ₱48.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chunky Asado Siopao with Drinks ₱148.00"){
            
           price = qty*148.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel168.getText(),
            jSpinner33.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chunky Asado Siopao without Drinks ₱48.00"){
           
                
            price = qty*48.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel168.getText(),
            jSpinner33.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner33.setValue(0);
               jCheckBox33.setSelected(false);
             
           }
        }
        else {
        jCheckBox33.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox33ActionPerformed

    private void jCheckBox34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox34ActionPerformed
       int qty = Integer.parseInt(jSpinner34.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox34.isSelected()){
         x++;
            
           String size [] = {"Asado ₱143.00", "Bola Bola ₱191.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"PRODUCT SELECTION", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Asado ₱143.00"){
             
            price = qty*143.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel173.getText(),
            jSpinner34.getValue(),
           df.format(price),
            });
            duedate();
            
           }
            if (selectedValue == "Bola Bola ₱191.00"){
           
                
            price = qty*191.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel173.getText(),
            jSpinner34.getValue(),
           df.format(price),
            });
            duedate();
            }
           }
        
         jSpinner34.setValue(0);
               jCheckBox34.setSelected(false);
        }
        else {
        jCheckBox34.setSelected(false);
        
    }//GEN-LAST:event_jCheckBox34ActionPerformed
    }

    private void jCheckBox35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox35ActionPerformed
        int qty = Integer.parseInt(jSpinner35.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox35.isSelected()){
         x++;
           
         String size [] = {"2pc. Steamed Pork Siomai Ala Carte ₱42.00", "2pc. Fried Pork Siomai Ala Carte ₱42.00", "2pc. Steamed Beef Siomai Ala Carte ₱42.00", "2pc. Steamed Chicken Siomai Ala Carte ₱42.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"CHOOSE YOUR SIOMAI", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "2pc. Steamed Pork Siomai Ala Carte ₱42.00"){
             
            price = qty*42.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel178.getText(),
            jSpinner35.getValue(),
           df.format(price),
            });
            duedate();
            
           }
            if (selectedValue == "2pc. Fried Pork Siomai Ala Carte ₱42.00"){
           
                
            price = qty*42.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel178.getText(),
            jSpinner35.getValue(),
           df.format(price),
            });
            duedate();
            }
            if (selectedValue == "2pc. Steamed Beef Siomai Ala Carte ₱42.00"){
           
                
            price = qty*42.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel178.getText(),
            jSpinner35.getValue(),
           df.format(price),
            });
            duedate();
            }
            if (selectedValue == "2pc. Steamed Chicken Siomai Ala Carte ₱42.00"){
           
                
            price = qty*42.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel178.getText(),
            jSpinner35.getValue(),
           df.format(price),
            });
            duedate();
            }
           }
        
         jSpinner35.setValue(0);
               jCheckBox35.setSelected(false);
        }
        else {
        jCheckBox35.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox35ActionPerformed

    private void jCheckBox36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox36ActionPerformed
       int qty = Integer.parseInt(jSpinner36.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox36.isSelected()){
         x++;
           
              String size [] = {"Beef Tapa with Drinks ₱259.00", "Beef Tapa without Drinks ₱159.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Beef Tapa with Drinks ₱259.00"){
            
           price = qty*259.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel183.getText(),
            jSpinner36.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Beef Tapa without Drinks ₱159.00"){
           
                
            price = qty*159.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel183.getText(),
            jSpinner36.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner36.setValue(0);
               jCheckBox36.setSelected(false);
             
           }
        }
        else {
        jCheckBox36.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox36ActionPerformed

    private void jCheckBox37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox37ActionPerformed
         int qty = Integer.parseInt(jSpinner37.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox37.isSelected()){
         x++;
            
              String size [] = {"Chinese Pork Longganisa with Drinks ₱280.00", "Chinese Pork Longganisa without Drinks ₱180.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chinese Pork Longganisa with Drinks ₱280.00"){
            
           price = qty*280.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel188.getText(),
            jSpinner37.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chinese Pork Longganisa without Drinks ₱180.00"){
           
                
            price = qty*180.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel188.getText(),
            jSpinner37.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner37.setValue(0);
               jCheckBox37.setSelected(false);
             
           }
        }
        else {
        jCheckBox37.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox37ActionPerformed

    private void jCheckBox38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox38ActionPerformed
        int qty = Integer.parseInt(jSpinner38.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox38.isSelected()){
         x++;
            
             String size [] = {"King's Special with Drinks ₱280.00", "King's Special without Drinks ₱180.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "King's Special with Drinks ₱280.00"){
            
           price = qty*280.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel193.getText(),
            jSpinner38.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "King's Special without Drinks ₱180.00"){
           
                
            price = qty*180.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel193.getText(),
            jSpinner38.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner38.setValue(0);
               jCheckBox38.setSelected(false);
             
           }
        }
        else {
        jCheckBox38.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox38ActionPerformed

    private void jCheckBox39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox39ActionPerformed
        int qty = Integer.parseInt(jSpinner39.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox39.isSelected()){
         x++;
            
              String size [] = {"Chicharap with Drinks ₱164.00", "Chicharap without Drinks ₱64.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Chicharap with Drinks ₱164.00"){
            
           price = qty*164.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel198.getText(),
            jSpinner39.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Chicharap without Drinks ₱64.00"){
           
                
            price = qty*64.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel198.getText(),
            jSpinner39.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner39.setValue(0);
               jCheckBox39.setSelected(false);
             
           }
        }
        else {
        jCheckBox39.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox39ActionPerformed

    private void jCheckBox40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox40ActionPerformed
       int qty = Integer.parseInt(jSpinner40.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox40.isSelected()){
         x++;
            
              String size [] = {"Buchi with Drinks ₱153.00", "Buchi without Drinks ₱53.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Buchi with Drinks ₱153.00"){
            
           price = qty*153.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel203.getText(),
            jSpinner40.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Buchi without Drinks ₱53.00"){
           
                
            price = qty*53.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel203.getText(),
            jSpinner40.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner40.setValue(0);
               jCheckBox40.setSelected(false);
             
           }
        }
        else {
        jCheckBox40.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox40ActionPerformed

    private void jCheckBox41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox41ActionPerformed
       int qty = Integer.parseInt(jSpinner41.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox41.isSelected()){
         x++;
            
                          String size [] = {"Extra Plain Rice with Drinks ₱132.00", "Extra Plain Rice without Drinks ₱32.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Extra Plain Rice with Drinks ₱132.00"){
            
           price = qty*153.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel208.getText(),
            jSpinner41.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Extra Plain Rice without Drinks ₱32.00"){
           
                
            price = qty*53.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel208.getText(),
            jSpinner41.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner41.setValue(0);
               jCheckBox41.setSelected(false);
             
           }
        }
        else {
        jCheckBox41.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox41ActionPerformed

    private void jCheckBox42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox42ActionPerformed
        int qty = Integer.parseInt(jSpinner42.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox42.isSelected()){
         x++;
           
                                      String size [] = {"Extra Egg Fried Rice with Drinks ₱148.00", "Extra Egg Fried Rice without Drinks ₱48.00"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose variant", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Extra Egg Fried Rice with Drinks ₱148.00"){
            
           price = qty*148.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel213.getText(),
            jSpinner42.getValue(),
           df.format(price),
            });
          
            duedate();
            
           }
            if (selectedValue == "Extra Egg Fried Rice without Drinks ₱48.00"){
           
                
            price = qty*48.00;
            total += price;
              DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel213.getText(),
            jSpinner42.getValue(),
           df.format(price),
            });
            
            duedate();
            
           }
            jSpinner42.setValue(0);
               jCheckBox42.setSelected(false);
             
           }
        }
        else {
        jCheckBox42.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox42ActionPerformed

    private void jCheckBox43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox43ActionPerformed
        int qty = Integer.parseInt(jSpinner43.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox43.isSelected()){
         x++;
            
           String size [] = {"Regular", "Medium", "Large"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose Size", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Regular"){
           
            price = qty*73.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel218.getText(),
            jSpinner43.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            if (selectedValue == "Medium"){
           
            price = qty*94.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel218.getText(),
            jSpinner43.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            
             if (selectedValue == "Large"){
           
            price = qty*115.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel218.getText(),
            jSpinner43.getValue(),
           df.format(price),
            });
            duedate();
           
           }
           }
           jSpinner43.setValue(0);
               jCheckBox43.setSelected(false);
        }
        else {
        jCheckBox43.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox43ActionPerformed

    private void jCheckBox44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox44ActionPerformed
       int qty = Integer.parseInt(jSpinner44.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox44.isSelected()){
         x++;
            
           String size [] = {"Regular", "Medium", "Large"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose Size", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Regular"){
           
            price = qty*58.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel223.getText(),
            jSpinner44.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            if (selectedValue == "Medium"){
           
           price = qty*69.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel223.getText(),
            jSpinner44.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            
             if (selectedValue == "Large"){
           
            price = qty*80.00;
            total += price;
             DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel223.getText(),
            jSpinner44.getValue(),
           df.format(price),
            });
            duedate();
           
           }
           }
           jSpinner44.setValue(0);
               jCheckBox44.setSelected(false);
        }
        else {
        jCheckBox44.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox44ActionPerformed

    private void jCheckBox45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox45ActionPerformed
      int qty = Integer.parseInt(jSpinner45.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox45.isSelected()){
         x++;
            
            
            String size [] = {"Regular", "Medium", "Large"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose Size", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Regular"){
           
            price = qty*53.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel228.getText(),
            jSpinner45.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            if (selectedValue == "Medium"){
           
            price = qty*64.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel228.getText(),
            jSpinner45.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            
             if (selectedValue == "Large"){
           
            price = qty*75.00;
            total += price;
         DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel228.getText(),
            jSpinner45.getValue(),
           df.format(price),
            });
            duedate();
           
           }
           }
           jSpinner45.setValue(0);
               jCheckBox45.setSelected(false);
            
        }
        else {
        jCheckBox45.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox45ActionPerformed

    private void jCheckBox46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox46ActionPerformed
        
        int qty = Integer.parseInt(jSpinner46.getValue().toString());
        if(qtyIsZero(qty) && jCheckBox46.isSelected()){
         x++;
            
            String size [] = {"Regular", "Medium", "Large"};
            JComboBox cb = new JComboBox(size);
            
           int input;
           input = JOptionPane.showConfirmDialog(this,cb,"Choose Size", JOptionPane.DEFAULT_OPTION);
           if (input == JOptionPane.OK_OPTION){
           
           String selectedValue = cb.getSelectedItem().toString();
           
           if (selectedValue == "Regular"){
           
           price = qty*53.00;
            total += price;
            DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel233.getText(),
            jSpinner46.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            if (selectedValue == "Medium"){
           
            price = qty*64.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel233.getText(),
            jSpinner46.getValue(),
           df.format(price),
            });
            duedate();
           
           }
            
             if (selectedValue == "Large"){
           
          price = qty*75.00;
            total += price;
           DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();  
                model.addRow(new Object[]{
           
            x,        
            jLabel233.getText(),
            jSpinner46.getValue(),
           df.format(price),
            });
            duedate();
           
           }
           }
            jSpinner46.setValue(0);
               jCheckBox46.setSelected(false);
            
        }
        else {
        jCheckBox46.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox46ActionPerformed

    private void jPanel34HierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jPanel34HierarchyChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel34HierarchyChanged

    private void btnReset1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReset1ActionPerformed
     reset();
    }//GEN-LAST:event_btnReset1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    
     
     try 
     {
    jTextArea1.print();
     }
     catch(Exception e){
     
     e.printStackTrace();
     
     }
     reset();
    }//GEN-LAST:event_jButton3ActionPerformed

    public void bill(){
        String total = jTextFieldtotal1.getText();
        String pay = jTextFielcash.getText();
        String bal = jTextFieldchange.getText();
        
    DefaultTableModel model = new DefaultTableModel();

        model = (DefaultTableModel) jTable1.getModel();

        Date obj = new Date();
        String date = obj.toString();

        jTextArea1.setText(jTextArea1.getText() + "                                                        [C    H     O     W     K    I   N    G]        \n\n");
        jTextArea1.setText(jTextArea1.getText() + "\t\t " + "[" + date + "]" + "\n");
        jTextArea1.setText(jTextArea1.getText() + "***************************************************************************************************\n");

        jTextArea1.setText(jTextArea1.getText() + "Product Name" + "\t\t\t     " + "Qty" + "\t" + "Price\n");
        jTextArea1.setText(jTextArea1.getText() + "***************************************************************************************************\n");

        for (int i = 0; i < jTable1.getRowCount(); i++) {
            String pname =  jTable1.getValueAt(i, 1).toString();
            Integer qty = Integer.parseInt(jTable1.getValueAt(i,2).toString());
            String price =  jTable1.getValueAt(i, 3).toString();
            

            jTextArea1.setText(jTextArea1.getText() + pname + "\n");
             jTextArea1.setText(jTextArea1.getText() + "\t\t\t      " + qty + "\t"+ price  + "\n");
            jTextArea1.setText(jTextArea1.getText() + "----------------------------------------------------------------------------------------------------------------------\n");
        }

        jTextArea1.setText(jTextArea1.getText() + "\n");

        jTextArea1.setText(jTextArea1.getText() + "\t\t\t\t" + "     Total:         " + total + "\n");
        jTextArea1.setText(jTextArea1.getText() + "\t\t\t\t" + "     Pay:          " + pay + "\n");
        jTextArea1.setText(jTextArea1.getText() + "\t\t\t\t" + "     Balance:  " + bal + "\n");
        jTextArea1.setText(jTextArea1.getText() + "***************************************************************************************************\n");
        jTextArea1.setText(jTextArea1.getText() + "                                 T  H  A  N  K      Y  O  U      C  O  M  E     A  G  A  I  N  !        \n");
        jTextArea1.setText(jTextArea1.getText() + "***************************************************************************************************\n");
    }
    
    
    
    
    
    public void duedate(){
   
    jTextFieldtotal1.setText(String.valueOf(df.format(total)));
   
   jTextFieldchange.setText(String.valueOf(df.format(change)));
    }
   
    public void setTime(){
    new Thread(new Runnable() {
        @Override
        public void run() {
            while(true){
                try {  
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Chowkingtest.class.getName()).log(Level.SEVERE, null, ex);
                }
                Date date = new Date();
                SimpleDateFormat tf = new SimpleDateFormat("h:mm:ss aa");
                SimpleDateFormat df = new SimpleDateFormat("EEEE, dd-MM-yyyy");
                String time = tf.format(date);
                jTextTime.setText(time.split(" ")[0]+" "+time.split(" ")[1]);
                jTextDate.setText(df.format(date));
            }
        }
    }).start();
    
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Chowkingtest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Chowkingtest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Chowkingtest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Chowkingtest.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Chowkingtest().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnReset1;
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btntotal;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox14;
    private javax.swing.JCheckBox jCheckBox15;
    private javax.swing.JCheckBox jCheckBox17;
    private javax.swing.JCheckBox jCheckBox18;
    private javax.swing.JCheckBox jCheckBox19;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox20;
    private javax.swing.JCheckBox jCheckBox21;
    private javax.swing.JCheckBox jCheckBox22;
    private javax.swing.JCheckBox jCheckBox23;
    private javax.swing.JCheckBox jCheckBox24;
    private javax.swing.JCheckBox jCheckBox25;
    private javax.swing.JCheckBox jCheckBox26;
    private javax.swing.JCheckBox jCheckBox27;
    private javax.swing.JCheckBox jCheckBox28;
    private javax.swing.JCheckBox jCheckBox29;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox30;
    private javax.swing.JCheckBox jCheckBox31;
    private javax.swing.JCheckBox jCheckBox32;
    private javax.swing.JCheckBox jCheckBox33;
    private javax.swing.JCheckBox jCheckBox34;
    private javax.swing.JCheckBox jCheckBox35;
    private javax.swing.JCheckBox jCheckBox36;
    private javax.swing.JCheckBox jCheckBox37;
    private javax.swing.JCheckBox jCheckBox38;
    private javax.swing.JCheckBox jCheckBox39;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox40;
    private javax.swing.JCheckBox jCheckBox41;
    private javax.swing.JCheckBox jCheckBox42;
    private javax.swing.JCheckBox jCheckBox43;
    private javax.swing.JCheckBox jCheckBox44;
    private javax.swing.JCheckBox jCheckBox45;
    private javax.swing.JCheckBox jCheckBox46;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel135;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel139;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel146;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel148;
    private javax.swing.JLabel jLabel149;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel150;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel152;
    private javax.swing.JLabel jLabel153;
    private javax.swing.JLabel jLabel154;
    private javax.swing.JLabel jLabel155;
    private javax.swing.JLabel jLabel156;
    private javax.swing.JLabel jLabel157;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel159;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel160;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel162;
    private javax.swing.JLabel jLabel163;
    private javax.swing.JLabel jLabel164;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel183;
    private javax.swing.JLabel jLabel184;
    private javax.swing.JLabel jLabel185;
    private javax.swing.JLabel jLabel186;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel188;
    private javax.swing.JLabel jLabel189;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel190;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel193;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel195;
    private javax.swing.JLabel jLabel196;
    private javax.swing.JLabel jLabel197;
    private javax.swing.JLabel jLabel198;
    private javax.swing.JLabel jLabel199;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel200;
    private javax.swing.JLabel jLabel201;
    private javax.swing.JLabel jLabel202;
    private javax.swing.JLabel jLabel203;
    private javax.swing.JLabel jLabel204;
    private javax.swing.JLabel jLabel205;
    private javax.swing.JLabel jLabel206;
    private javax.swing.JLabel jLabel207;
    private javax.swing.JLabel jLabel208;
    private javax.swing.JLabel jLabel209;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel210;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JLabel jLabel216;
    private javax.swing.JLabel jLabel217;
    private javax.swing.JLabel jLabel218;
    private javax.swing.JLabel jLabel219;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel220;
    private javax.swing.JLabel jLabel221;
    private javax.swing.JLabel jLabel222;
    private javax.swing.JLabel jLabel223;
    private javax.swing.JLabel jLabel224;
    private javax.swing.JLabel jLabel225;
    private javax.swing.JLabel jLabel226;
    private javax.swing.JLabel jLabel227;
    private javax.swing.JLabel jLabel228;
    private javax.swing.JLabel jLabel229;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel230;
    private javax.swing.JLabel jLabel231;
    private javax.swing.JLabel jLabel232;
    private javax.swing.JLabel jLabel233;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JLabel jLabelcash;
    private javax.swing.JLabel jLabelimage;
    private javax.swing.JLabel jLabelimage1;
    private javax.swing.JLabel jLabelimage10;
    private javax.swing.JLabel jLabelimage11;
    private javax.swing.JLabel jLabelimage12;
    private javax.swing.JLabel jLabelimage13;
    private javax.swing.JLabel jLabelimage14;
    private javax.swing.JLabel jLabelimage16;
    private javax.swing.JLabel jLabelimage17;
    private javax.swing.JLabel jLabelimage18;
    private javax.swing.JLabel jLabelimage19;
    private javax.swing.JLabel jLabelimage2;
    private javax.swing.JLabel jLabelimage20;
    private javax.swing.JLabel jLabelimage21;
    private javax.swing.JLabel jLabelimage22;
    private javax.swing.JLabel jLabelimage23;
    private javax.swing.JLabel jLabelimage24;
    private javax.swing.JLabel jLabelimage25;
    private javax.swing.JLabel jLabelimage26;
    private javax.swing.JLabel jLabelimage27;
    private javax.swing.JLabel jLabelimage28;
    private javax.swing.JLabel jLabelimage29;
    private javax.swing.JLabel jLabelimage3;
    private javax.swing.JLabel jLabelimage30;
    private javax.swing.JLabel jLabelimage31;
    private javax.swing.JLabel jLabelimage32;
    private javax.swing.JLabel jLabelimage33;
    private javax.swing.JLabel jLabelimage34;
    private javax.swing.JLabel jLabelimage35;
    private javax.swing.JLabel jLabelimage36;
    private javax.swing.JLabel jLabelimage37;
    private javax.swing.JLabel jLabelimage38;
    private javax.swing.JLabel jLabelimage39;
    private javax.swing.JLabel jLabelimage4;
    private javax.swing.JLabel jLabelimage40;
    private javax.swing.JLabel jLabelimage41;
    private javax.swing.JLabel jLabelimage42;
    private javax.swing.JLabel jLabelimage43;
    private javax.swing.JLabel jLabelimage44;
    private javax.swing.JLabel jLabelimage45;
    private javax.swing.JLabel jLabelimage5;
    private javax.swing.JLabel jLabelimage6;
    private javax.swing.JLabel jLabelimage8;
    private javax.swing.JLabel jLabelimage9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner10;
    private javax.swing.JSpinner jSpinner11;
    private javax.swing.JSpinner jSpinner12;
    private javax.swing.JSpinner jSpinner13;
    private javax.swing.JSpinner jSpinner14;
    private javax.swing.JSpinner jSpinner15;
    private javax.swing.JSpinner jSpinner17;
    private javax.swing.JSpinner jSpinner18;
    private javax.swing.JSpinner jSpinner19;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner20;
    private javax.swing.JSpinner jSpinner21;
    private javax.swing.JSpinner jSpinner22;
    private javax.swing.JSpinner jSpinner23;
    private javax.swing.JSpinner jSpinner24;
    private javax.swing.JSpinner jSpinner25;
    private javax.swing.JSpinner jSpinner26;
    private javax.swing.JSpinner jSpinner27;
    private javax.swing.JSpinner jSpinner28;
    private javax.swing.JSpinner jSpinner29;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JSpinner jSpinner30;
    private javax.swing.JSpinner jSpinner31;
    private javax.swing.JSpinner jSpinner32;
    private javax.swing.JSpinner jSpinner33;
    private javax.swing.JSpinner jSpinner34;
    private javax.swing.JSpinner jSpinner35;
    private javax.swing.JSpinner jSpinner36;
    private javax.swing.JSpinner jSpinner37;
    private javax.swing.JSpinner jSpinner38;
    private javax.swing.JSpinner jSpinner39;
    private javax.swing.JSpinner jSpinner4;
    private javax.swing.JSpinner jSpinner40;
    private javax.swing.JSpinner jSpinner41;
    private javax.swing.JSpinner jSpinner42;
    private javax.swing.JSpinner jSpinner43;
    private javax.swing.JSpinner jSpinner44;
    private javax.swing.JSpinner jSpinner45;
    private javax.swing.JSpinner jSpinner46;
    private javax.swing.JSpinner jSpinner5;
    private javax.swing.JSpinner jSpinner6;
    private javax.swing.JSpinner jSpinner7;
    private javax.swing.JSpinner jSpinner9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel jTextDate;
    private javax.swing.JTextField jTextFielcash;
    private javax.swing.JTextField jTextFieldchange;
    private javax.swing.JTextField jTextFieldtotal1;
    private javax.swing.JLabel jTextTime;
    // End of variables declaration//GEN-END:variables
}
