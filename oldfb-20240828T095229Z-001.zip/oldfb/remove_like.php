<?php
session_start();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required field is set
    if (isset($_POST['post_id'])) {
        // Include functions and establish database connection
        require 'functions/functions.php';
        $conn = connect();

        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            echo "Error: User is not logged in.";
            exit(); // Stop script execution if the user is not logged in
        }

        // Sanitize input data
        $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
        $user_id = $_SESSION['user_id'];

        // Check if the user has liked the post
        $check_like_sql = "SELECT * FROM post_likes WHERE post_id = '$post_id' AND user_id = '$user_id'";
        $check_like_query = mysqli_query($conn, $check_like_sql);

        if (mysqli_num_rows($check_like_query) > 0) {
            // User has liked the post, so remove their like
            $remove_like_sql = "DELETE FROM post_likes WHERE post_id = '$post_id' AND user_id = '$user_id'";
            $remove_like_query = mysqli_query($conn, $remove_like_sql);

            if ($remove_like_query) {
                echo "Like removed successfully.";
            } else {
                echo "Error: Unable to remove like.";
            }
        } else {
            // User has not liked the post, so cannot remove their like
            echo "Error: User has not liked the post.";
        }
    } else {
        // Handle if required field is not set
        echo "Error: Required field is not set.";
    }
} else {
    // Handle if the request method is not POST
    echo "Error: Invalid request method.";
}
?>
