<?php

$token = $_GET["token"];

$mysqli = require __DIR__ . "/functions/functions.php";

$sql = "SELECT * FROM users
        WHERE verification_code = ?";
        
$stmt = $mysqli->prepare($sql);

$stmt->bind_param("s", $token);

$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();

if ($user === null){
    die("Token not found");
}

if (strtotime($user["verification_code_expires_at"]) <= time()){
    die("Token has expired");
}


if ($_POST["password"] !== $_POST["password_confirmation"]) {
    echo '<script>alert("Password does not match");</script>';
} else {

$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

$sql = "UPDATE users
        SET user_password = ?,
            verification_code = NULL,
            verification_code_expires_at = NULL,
            is_locked = 0
        WHERE user_id = ?";
        
$stmt = $mysqli->prepare($sql);

$stmt->bind_param("si", $password_hash, $user["user_id"]); // Assuming user_id is an integer
$stmt->execute();


echo '<script>alert("Password updated. You can now login."); window.location.href = "index.php";</script>';
}
?>
