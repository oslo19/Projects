<?php

if (!isset($_GET["token"])) {
    die("Token not found");
}

$token = $_GET["token"];

$mysqli = require __DIR__ . "/functions/functions.php";

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$sql = "SELECT * FROM users
        WHERE verification_code = ?";
        
$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    die("Error in preparing statement: " . $mysqli->error);
}

$stmt->bind_param("s", $token);

$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();

if ($user === null){
    die("Token not found");
}

if (strtotime($user["verification_code_expires_at"]) <= time()){
    die("Token has expired");
}

// Function to validate password strength
function validateStrongPassword($password) {
    // Password must be at least 8 characters long
    // Password must contain at least one uppercase letter
    // Password must contain at least one lowercase letter
    // Password must contain at least one number
    // Password must contain at least one special character
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $confirmPassword = $_POST['password_confirmation'];
    
    if ($password !== $confirmPassword) {
        die("Passwords do not match");
    }
    
    if (!validateStrongPassword($password)) {
        die("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
    }
    
    // Proceed with password reset
    // Update the user's password in the database
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="resources/css/main.css">
<style>
    /* Custom styles for reset-password.php */
    .container {
        margin: 40px auto;
        width: 400px;
    }
    .content {
        padding: 30px;
        background-color: white;
        box-shadow: 0 0 5px #4267b2;
    }
    .error-message {
        color: red;
        font-size: 14px;
        margin-top: 5px;
    }
</style>
</head>

<body>

    <h1>Reset Password</h1>
    <div class="container">
    <div class="content">
    <form method="post" action="process-reset-password.php?token=<?= htmlspecialchars($token) ?>" >
        <!-- Ensure the token is included in the form action -->
        
        <label for="password">New password</label>
        <input type="password" id="password" name="password">
        
        <label for="password_confirmation">Repeat password</label>
        <input type="password" id="password_confirmation" name="password_confirmation">
        
        <!-- Error message for password mismatch -->
        <div class="error-message" id="passwordMismatch" style="display: none;">Passwords do not match</div>
        
        <!-- Error message for weak password -->
        <div class="error-message" id="weakPassword" style="display: none;">Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.</div>
        
    <button type="submit" onclick="return validateForm()">Send</button>
    </form>
    </div>
    </div>
    
    <script>
        function validateForm() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("password_confirmation").value;
            var passwordMismatch = document.getElementById("passwordMismatch");
            var weakPassword = document.getElementById("weakPassword");
            
            if (password !== confirmPassword) {
                passwordMismatch.style.display = "block";
                weakPassword.style.display = "none";
                return false; // Prevent form submission
            } else {
                passwordMismatch.style.display = "none";
                if (password.length < 8 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/[0-9]/.test(password) || !/[@$!%*?&]/.test(password)) {
                    weakPassword.style.display = "block";
                    return false; // Prevent form submission
                } else {
                    weakPassword.style.display = "none";
                    return true; // Allow form submission
                }
            }
        }
    </script>
</body>
</html>
