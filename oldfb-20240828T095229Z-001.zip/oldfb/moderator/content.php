<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include logActivity function
function logActivity($conn, $userId, $activityType, $details) {
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, details) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $userId, $activityType, $details);
    $stmt->execute();
    $stmt->close();
}

// Delete Post
if (isset($_GET['delete_post_id'])) {
    $deletePostId = $_GET['delete_post_id'];
    $deletePostQuery = "DELETE FROM posts WHERE post_id = '$deletePostId'";
    
    if (mysqli_query($conn, $deletePostQuery)) {
        // Assuming the user_id of the admin performing the action is stored in a session variable
        session_start();
        $adminUserId = $_SESSION['admin_user_id'];
        logActivity($conn, $adminUserId, 'delete_post', "Post ID $deletePostId deleted");
        echo "Post deleted successfully.";
    } else {
        echo "Error deleting post: " . mysqli_error($conn);
    }
}

// Retrieve and Display Posts
$postQuery = "SELECT * FROM posts";
$postResult = mysqli_query($conn, $postQuery);
?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">POSTS</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Post ID</th>
                                    <th>Post Caption</th>
                                    <th>Post Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($postRow = mysqli_fetch_assoc($postResult)) {
                                    ?>
                                    <tr>
                                        <td><?php echo $postRow['post_id']; ?></td>
                                        <td><?php echo $postRow['post_caption']; ?></td>
                                        <td><?php echo $postRow['post_time']; ?></td>
                                        <td>
                                            <a href="?delete_post_id=<?php echo $postRow['post_id']; ?>" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
