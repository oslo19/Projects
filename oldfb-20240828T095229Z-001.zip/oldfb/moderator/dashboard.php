<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Count the number of posts
$postCountQuery = "SELECT COUNT(*) AS postCount FROM posts";
$postCountResult = mysqli_query($conn, $postCountQuery);
if (!$postCountResult) {
    die("Query failed: " . mysqli_error($conn));
}
$postCountRow = mysqli_fetch_assoc($postCountResult);
$postCount = $postCountRow['postCount'];

// Count the number of users
$userCountQuery = "SELECT COUNT(*) AS userCount FROM users";
$userCountResult = mysqli_query($conn, $userCountQuery);
if (!$userCountResult) {
    die("Query failed: " . mysqli_error($conn));
}
$userCountRow = mysqli_fetch_assoc($userCountResult);
$userCount = $userCountRow['userCount'];

// Count the number of groups
$groupCountQuery = "SELECT COUNT(*) AS groupCount FROM groups";
$groupCountResult = mysqli_query($conn, $groupCountQuery);
if (!$groupCountResult) {
    die("Query failed: " . mysqli_error($conn));
}
$groupCountRow = mysqli_fetch_assoc($groupCountResult);
$groupCount = $groupCountRow['groupCount'];

// Retrieve recent activities
$recentActivityQuery = "
    SELECT 
        'post' AS type, p.post_caption AS content, p.post_time AS time, CONCAT(u.user_firstname, ' ', u.user_lastname) AS user_name 
    FROM posts p
    JOIN users u ON p.post_by = u.user_id
    UNION ALL 
    SELECT 
        'ban' AS type, CONCAT('User ', u.user_firstname, ' ', u.user_lastname, ' banned until ', ban_end_date) AS content, ban_end_date AS time, CONCAT(u.user_firstname, ' ', u.user_lastname) AS user_name 
    FROM users u 
    WHERE ban_end_date IS NOT NULL 
    UNION ALL
    SELECT 
        'comment' AS type, 
        CONCAT(cu.user_firstname, ' ', cu.user_lastname, ' commented \"', c.comment_text, '\" on post ', c.post_id, ' by ', pu.user_firstname, ' ', pu.user_lastname) AS content, 
        c.comment_time AS time, 
        CONCAT(cu.user_firstname, ' ', cu.user_lastname) AS user_name 
    FROM comments c
    JOIN users cu ON c.commenter_id = cu.user_id
    JOIN posts p ON c.post_id = p.post_id
    JOIN users pu ON p.post_by = pu.user_id
    UNION ALL
    SELECT 
        'like' AS type, 
        CONCAT(lu.user_firstname, ' ', lu.user_lastname, ' liked post ', l.post_id, ' by ', pu.user_firstname, ' ', pu.user_lastname) AS content, 
        l.like_time AS time, 
        CONCAT(lu.user_firstname, ' ', lu.user_lastname) AS user_name 
    FROM post_likes l
    JOIN users lu ON l.user_id = lu.user_id
    JOIN posts p ON l.post_id = p.post_id
    JOIN users pu ON p.post_by = pu.user_id
    ORDER BY time DESC 
    LIMIT 10";
$recentActivityResult = mysqli_query($conn, $recentActivityQuery);
if (!$recentActivityResult) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">DASHBOARD </h4>
                        <p>Total Posts: <?php echo $postCount; ?></p>
                        <p>Total Users: <?php echo $userCount; ?></p>
                        <p>Total Groups: <?php echo $groupCount; ?></p>
                        
                        <h4 class="box-title mt-4">Recent Activities</h4>
                        <ul>
                            <?php
                            while ($activity = mysqli_fetch_assoc($recentActivityResult)) {
                                echo "<li>{$activity['time']}: {$activity['content']} ({$activity['type']})</li>";
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
