<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include logActivity function
function logActivity($conn, $userId, $activityType, $details) {
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, details) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $userId, $activityType, $details);
    $stmt->execute();
    $stmt->close();
}

// Ban User
if (isset($_GET['action']) && isset($_GET['user_id'])) {
    $userId = $_GET['user_id'];

    if ($_GET['action'] === 'ban' && isset($_POST['ban_days'])) {
        $banDays = $_POST['ban_days'];

        // Calculate the ban end date
        $banEndDate = date('Y-m-d H:i:s', strtotime("+$banDays days"));

        $banQuery = "UPDATE users SET ban_end_date = '$banEndDate' WHERE user_id = $userId";
        if (mysqli_query($conn, $banQuery)) {
            logActivity($conn, $userId, 'ban', "User banned for $banDays days");
            echo "User banned successfully.";
        } else {
            echo "Error banning user: " . mysqli_error($conn);
        }
    } elseif ($_GET['action'] === 'unban') {
        // Unban User
        $unbanQuery = "UPDATE users SET ban_end_date = NULL WHERE user_id = $userId";
        if (mysqli_query($conn, $unbanQuery)) {
            logActivity($conn, $userId, 'unban', "User unbanned");
            echo "User unbanned successfully.";
        } else {
            echo "Error unbanning user: " . mysqli_error($conn);
        }
    }
}

// Retrieve and Display Users
$userQuery = "SELECT * FROM users";
$userResult = mysqli_query($conn, $userQuery);
?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">USERS</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($userRow = mysqli_fetch_assoc($userResult)) {
                                    $isBanned = !is_null($userRow['ban_end_date']);
                                    ?>
                                    <tr>
                                        <td><?php echo $userRow['user_id']; ?></td>
                                        <td><?php echo $userRow['user_firstname']; ?></td>
                                        <td><?php echo $userRow['user_lastname']; ?></td>
                                        <td><?php echo $userRow['user_email']; ?></td>
                                        <td>
                                            <?php if ($isBanned) { ?>
                                                <form method="post" action="?action=unban&user_id=<?php echo $userRow['user_id']; ?>">
                                                    <button type="submit">Unban</button>
                                                </form>
                                            <?php } else { ?>
                                                <form method="post" action="?action=ban&user_id=<?php echo $userRow['user_id']; ?>">
                                                    <input type="number" name="ban_days" placeholder="Enter ban days" required>
                                                    <button type="submit">Ban</button>
                                                </form>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
