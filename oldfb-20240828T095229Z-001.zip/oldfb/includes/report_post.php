<?php
session_start();
require_once '../functions/functions.php';  // Adjusted path

$response = array('success' => false, 'message' => '');

if (isset($_POST['post_id']) && isset($_POST['report_reason'])) {
    $conn = connect();  // Ensure the database connection is established
    $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
    $report_reason = mysqli_real_escape_string($conn, $_POST['report_reason']);
    $reported_by = $_SESSION['user_id'];

    $sql = "INSERT INTO reports (post_id, reported_by, report_reason) VALUES ('$post_id', '$reported_by', '$report_reason')";
    
    if (mysqli_query($conn, $sql)) {
        $response['success'] = true;
        $response['message'] = 'Post reported successfully.';
    } else {
        $response['message'] = 'Failed to report post.';
    }
} else {
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');  // Ensure JSON response
echo json_encode($response);
?>
