<?php
require_once '../functions/functions.php';
session_start();

if (!isset($_SESSION['user_id']) || !isset($_GET['group_id']) || !isset($_GET['user_id'])) {
    echo "Error: Missing required parameters.";
    exit();
}

$admin_id = $_SESSION['user_id'];
$group_id = intval($_GET['group_id']);
$user_id = intval($_GET['user_id']);

$conn = connect();

// Check if the current user is the admin of the group
$sql = "SELECT admin_id FROM groups WHERE group_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo "Error: " . $conn->error;
    exit();
}
$stmt->bind_param('i', $group_id);
$stmt->execute();
$query = $stmt->get_result();
$row = $query->fetch_assoc();
if ($row['admin_id'] != $admin_id) {
    echo "Error: You are not authorized to kick members.";
    exit();
}

// Remove the user from the group
$sql = "DELETE FROM group_members WHERE group_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo "Error: " . $conn->error;
    exit();
}
$stmt->bind_param('ii', $group_id, $user_id);
if ($stmt->execute()) {
    echo "Success: User has been kicked.";
} else {
    echo "Error: " . $stmt->error;
}
?>
