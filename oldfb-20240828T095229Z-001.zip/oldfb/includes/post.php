<?php

echo '<div class="post" id="post-' . $row['post_id'] . '">';
echo '<div class="post-header">';
if($row['post_public'] == 'Y') {
    echo '<p class="public">';
    echo 'Public';
}else {
    echo '<p class="public">';
    echo 'Private';
}
echo '<br>';
echo '<span class="postedtime">' . $row['post_time'] . '</span>';
echo '</p>';
echo '<div class="options-menu">';
echo '<button class="options-btn">⋮</button>';
echo '<div class="dropdown-content">';
echo '<a href="#" onclick="reportPost(' . $row['post_id'] . ')">Report</a>';
if ($row['user_id'] == $_SESSION['user_id']) {
    echo '<a href="#" onclick="deletePost(' . $row['post_id'] . ')">Delete Post</a>';
}
echo '</div>';
echo '</div>';
echo '</div>';
echo '<div>';
include 'profile_picture.php';
echo '<a class="profilelink" href="profile.php?id=' . $row['user_id'] .'">' . $row['user_firstname'] . ' ' . $row['user_lastname'] . '</a>';
echo'</div>';
echo '<br>';
echo '<p class="caption">' . $row['post_caption'] . '</p>';
echo '<center>';
$target = glob("data/images/posts/" . $row['post_id'] . ".*");
if($target) {
    echo '<img src="' . $target[0] . '" style="max-width:580px">';
    echo '<br><br>';
}
echo '</center>';

// Add like section
echo '<div">';
echo '<button class="like-btn" data-post-id="' . $row['post_id'] . '"';
// Check if the logged-in user has already liked the post
$check_like_sql = "SELECT * FROM post_likes WHERE post_id = '{$row['post_id']}' AND user_id = '{$_SESSION['user_id']}'";
$check_like_query = mysqli_query($conn, $check_like_sql);
if (mysqli_num_rows($check_like_query) > 0) {
    echo ' disabled'; // Disable the like button if the user has already liked the post
}
echo '>Like</button>';
// Fetch and display users who liked the post
$liked_users_sql = "SELECT users.user_firstname, users.user_lastname, post_likes.user_id FROM post_likes 
                    JOIN users ON post_likes.user_id = users.user_id
                    WHERE post_likes.post_id = {$row['post_id']}";
$liked_users_query = mysqli_query($conn, $liked_users_sql);
echo '<div class="liked-users">';
$liked_by_user = false;
while ($liked_user = mysqli_fetch_assoc($liked_users_query)) {
    if ($liked_user['user_id'] == $_SESSION['user_id']) {
        $liked_by_user = true;
    } else {
        echo $liked_user['user_firstname'] . ' ' . $liked_user['user_lastname'] . ', ';
    }
}
if ($liked_by_user) {
    echo 'YOU, '; // Display "YOU" if the logged-in user liked the post
}
echo '</div>';

// Add comment section
echo '<div class="comment-section">';
echo '<form method="post" action="add_comment.php">';
echo '<input type="hidden" name="post_id" value="' . $row['post_id'] . '">';
echo '<textarea name="comment" placeholder="Write a comment..."></textarea>';
echo '<input type="submit" value="Comment">';
echo '</form>';

// Fetch comments with commenter's name
$comments_sql = "SELECT comments.*, users.user_firstname, users.user_lastname FROM comments JOIN users ON comments.commenter_id = users.user_id WHERE post_id = {$row['post_id']} ORDER BY comment_time DESC";
$comments_query = mysqli_query($conn, $comments_sql);

if(mysqli_num_rows($comments_query) > 0) {
    while($comment_row = mysqli_fetch_assoc($comments_query)) {
        echo '<div class="comment">';
        echo '<strong>'.$comment_row['user_firstname'].' '.$comment_row['user_lastname'].'</strong>: '.$comment_row['comment_text'];
        echo '</div>';
    }
} else {
    echo 'No comments yet.';
}
echo '</div>'; // End of comment section

echo '</div>';
?>

<script>
  
    function reportPost(postId) {
        alert('Post ' + postId + ' reported.');
        // Implement report post functionality here
    }

    function deletePost(postId) {
        if (confirm('Are you sure you want to delete this post?')) {
            // Implement delete post functionality here
            window.location.href = 'includes/delete_post.php?id=' + postId;
        }
    }
</script>

<style>
.post-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.options-menu {
    position: relative;
    display: inline-block;
}
.options-btn {
    background: none;
    border: none;
    font-size: 18px;
    cursor: pointer;
}
.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}
.dropdown-content a:hover {
    background-color: #f1f1f1;
}
.show {
    display: block;
}
</style>
