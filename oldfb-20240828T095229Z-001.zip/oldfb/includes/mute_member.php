<?php
require_once '../functions/functions.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !isset($_GET['group_id']) || !isset($_GET['user_id']) || !isset($_GET['days'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required parameters.']);
    exit();
}

$admin_id = $_SESSION['user_id'];
$group_id = intval($_GET['group_id']);
$user_id = intval($_GET['user_id']);
$days = intval($_GET['days']);

$conn = connect();

if (!$conn) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    exit();
}

// Check if the current user is the admin of the group
$sql = "SELECT admin_id FROM groups WHERE group_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo json_encode(['status' => 'error', 'message' => $conn->error]);
    exit();
}
$stmt->bind_param('i', $group_id);
$stmt->execute();
$query = $stmt->get_result();
$row = $query->fetch_assoc();
if ($row['admin_id'] != $admin_id) {
    echo json_encode(['status' => 'error', 'message' => 'You are not authorized to mute/unmute members.']);
    exit();
}

// Check current mute status
$sql = "SELECT muted FROM group_members WHERE group_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo json_encode(['status' => 'error', 'message' => $conn->error]);
    exit();
}
$stmt->bind_param('ii', $group_id, $user_id);
$stmt->execute();
$query = $stmt->get_result();
$row = $query->fetch_assoc();
if (!$row) {
    echo json_encode(['status' => 'error', 'message' => 'User not found in group.']);
    exit();
}

$new_muted_status = $row['muted'] ? 0 : 1;
$mute_until = $new_muted_status ? date('Y-m-d H:i:s', strtotime("+$days days")) : NULL;

// Update the muted status
$sql = "UPDATE group_members SET muted = ?, mute_until = ? WHERE group_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo json_encode(['status' => 'error', 'message' => $conn->error]);
    exit();
}
$stmt->bind_param('isii', $new_muted_status, $mute_until, $group_id, $user_id);
if ($stmt->execute()) {
    $action = $new_muted_status ? 'muted' : 'unmuted';
    echo json_encode(['status' => 'success', 'action' => $action]);
} else {
    echo json_encode(['status' => 'error', 'message' => $stmt->error]);
}
?>
