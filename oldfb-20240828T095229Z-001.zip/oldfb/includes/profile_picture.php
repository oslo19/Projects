<?php
if (isset($row['user_id'])) {
    $user_id = $row['user_id'];
    $user_gender = isset($row['user_gender']) ? $row['user_gender'] : 'default';

    $target = glob("data/images/profiles/" . $user_id . ".*");
    if ($target) {
        echo '<img src="' . htmlspecialchars($target[0]) . '" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">'; 
    } else {
        if ($user_gender === 'M') {
            echo '<img src="data/images/profiles/M.jpg" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">';
        } else if ($user_gender === 'F') {
            echo '<img src="data/images/profiles/F.jpg" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">';
        } else {
            echo '<img src="data/images/profiles/default.jpg" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">';
        }
    }
} else {
    echo '<img src="data/images/profiles/default.jpg" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">';
}
?>
