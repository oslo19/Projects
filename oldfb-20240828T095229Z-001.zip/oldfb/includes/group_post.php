<?php
echo '<div class="post">';
if (isset($row['post_public']) && $row['post_public'] == 'Y') {
    echo '<p class="public">Public</p>';
} else {
    echo '<p class="public">Private</p>';
}
echo '<br>';
echo '<span class="postedtime">' . (isset($row['post_time']) ? htmlspecialchars($row['post_time']) : '') . '</span>';
echo '<div>';
if (isset($row['user_id'])) {
    include 'profile_picture.php'; // Make sure $row is accessible in profile_picture.php
} else {
    echo '<img src="data/images/profiles/default.jpg" width="' . htmlspecialchars($width) . '" height="' . htmlspecialchars($height) . '">';
}
echo '<a class="profilelink" href="profile.php?id=' . (isset($row['post_by']) ? htmlspecialchars($row['post_by']) : '') . '">' . (isset($row['user_firstname']) ? htmlspecialchars($row['user_firstname']) : '') . ' ' . (isset($row['user_lastname']) ? htmlspecialchars($row['user_lastname']) : '') . '</a>';
echo '</div>';
echo '<br>';
echo '<p class="caption">' . (isset($row['post_caption']) ? htmlspecialchars($row['post_caption']) : '') . '</p>';
echo '<center>';
if (isset($row['group_post_id'])) {
    $target = glob("data/images/posts/" . $row['group_post_id'] . ".*");
    if ($target) {
        echo '<img src="' . htmlspecialchars($target[0]) . '" style="max-width:580px">';
        echo '<br><br>';
    }
}
echo '</center>';
echo '<div class="comment-section">';
echo '<form method="post" action="add_group_comment.php">';
echo '<input type="hidden" name="group_post_id" value="' . (isset($row['group_post_id']) ? htmlspecialchars($row['group_post_id']) : '') . '">';
echo '<input type="hidden" name="group_id" value="' . htmlspecialchars($group_id) . '">';
echo '<input type="hidden" name="group_name" value="' . htmlspecialchars($group_name) . '">';
echo '<textarea name="comment" placeholder="Write a comment..."></textarea>';
echo '<input type="submit" value="Comment">';
echo '</form>';

$comments_sql = "SELECT group_comments.*, users.user_firstname, users.user_lastname 
                 FROM group_comments 
                 JOIN users ON group_comments.commenter_id = users.user_id 
                 WHERE group_comments.group_post_id = " . (isset($row['group_post_id']) ? intval($row['group_post_id']) : 0) . " 
                 ORDER BY group_comments.comment_time DESC";
$comments_query = mysqli_query($conn, $comments_sql);
if ($comments_query) {
    if (mysqli_num_rows($comments_query) > 0) {
        while ($comment_row = mysqli_fetch_assoc($comments_query)) {
            echo '<div class="comment">';
            echo '<strong>' . htmlspecialchars($comment_row['user_firstname']) . ' ' . htmlspecialchars($comment_row['user_lastname']) . '</strong>: ' . htmlspecialchars($comment_row['comment_text']);
            echo '</div>';
        }
    } else {
        echo 'No comments yet.';
    }
} else {
    echo 'Error fetching comments: ' . mysqli_error($conn);
}
echo '</div>';
echo '</div>';
?>
