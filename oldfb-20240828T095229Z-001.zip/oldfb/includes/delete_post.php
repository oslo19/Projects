<?php
ini_set('log_errors', 1);
ini_set('error_log', '../logs/php-error.log'); // Ensure the path is correct and writable
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
require_once '../functions/functions.php';  // Adjust the path if necessary

$response = array('success' => false, 'message' => '');

if (isset($_POST['post_id'])) {
    $conn = connect();  // Ensure the database connection is established

    if (!$conn) {
        $response['message'] = 'Database connection failed: ' . mysqli_connect_error();
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }

    $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
    $user_id = $_SESSION['user_id'];

    // Check if the post belongs to the logged-in user
    $sql = "SELECT * FROM posts WHERE post_id = '$post_id' AND post_by = '$user_id'";
    $query = mysqli_query($conn, $sql);

    if (!$query) {
        $response['message'] = 'Error in SQL query: ' . mysqli_error($conn);
        header('Content-Type: application/json');
        echo json_encode($response);
        exit();
    }

    if (mysqli_num_rows($query) > 0) {
        // Start a transaction
        mysqli_begin_transaction($conn);

        try {
            // Delete related post likes
            $delete_likes_sql = "DELETE FROM post_likes WHERE post_id = '$post_id'";
            if (!mysqli_query($conn, $delete_likes_sql)) {
                throw new Exception('Failed to delete related post likes: ' . mysqli_error($conn));
            }

            // Delete related comments
            $delete_comments_sql = "DELETE FROM comments WHERE post_id = '$post_id'";
            if (!mysqli_query($conn, $delete_comments_sql)) {
                throw new Exception('Failed to delete related comments: ' . mysqli_error($conn));
            }

            // Delete related reports
            $delete_reports_sql = "DELETE FROM reports WHERE post_id = '$post_id'";
            if (!mysqli_query($conn, $delete_reports_sql)) {
                throw new Exception('Failed to delete related reports: ' . mysqli_error($conn));
            }

            // Delete the post
            $delete_post_sql = "DELETE FROM posts WHERE post_id = '$post_id'";
            if (!mysqli_query($conn, $delete_post_sql)) {
                throw new Exception('Failed to delete post: ' . mysqli_error($conn));
            }

            // Commit transaction
            mysqli_commit($conn);

            $response['success'] = true;
            $response['message'] = 'Post deleted successfully.';
        } catch (Exception $e) {
            // Rollback transaction on failure
            mysqli_rollback($conn);
            $response['message'] = $e->getMessage();
        }
    } else {
        $response['message'] = 'You are not authorized to delete this post.';
    }

    mysqli_close($conn);
} else {
    $response['message'] = 'Invalid request.';
}

header('Content-Type: application/json');
echo json_encode($response);
?>
