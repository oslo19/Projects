<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include logActivity function
function logActivity($conn, $userId, $activityType, $details) {
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, details) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $userId, $activityType, $details);
    $stmt->execute();
    $stmt->close();
}

// Define abusive content keywords
$abusiveKeywords = ['abuse', 'hate', 'violence', 'offensive', 'yawa', 'pisti', 'tangina', 'putangina', 'gago', 'tanga', 'bobo', 'kayat', 'iyot', 'lulu', 'potang ina'];

// Function to detect abusive content
function detectAbusiveContent($content, $keywords) {
    foreach ($keywords as $keyword) {
        if (strpos($content, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

// Function to count user's abusive posts
function countUserAbusivePosts($conn, $userId, $keywords) {
    $query = "SELECT post_id, post_caption FROM posts WHERE post_by = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $abusivePosts = [];
    while ($row = $result->fetch_assoc()) {
        if (detectAbusiveContent($row['post_caption'], $keywords)) {
            $abusivePosts[] = $row['post_id'];
        }
    }
    $stmt->close();

    return $abusivePosts;
}

// Function to ban user with progressive duration
function banUser($conn, $userId, $abusiveCount) {
    $banHours = 1 + floor($abusiveCount / 3) * 2;
    $banEndDate = date('Y-m-d H:i:s', strtotime("+$banHours hours"));

    $query = "UPDATE users SET ban_end_date = ? WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $banEndDate, $userId);
    $stmt->execute();
    $stmt->close();

    logActivity($conn, $userId, 'ban', "User banned for $banHours hours due to abusive content");
}

// Handle user ban and unban
if (isset($_POST['action']) && isset($_POST['user_id'])) {
    $userId = $_POST['user_id'];
    
    if ($_POST['action'] === 'ban') {
        // Ban user
        $banDays = $_POST['ban_days'];
        $banEndDate = date('Y-m-d H:i:s', strtotime("+$banDays days"));
        
        $query = "UPDATE users SET ban_end_date = ? WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("si", $banEndDate, $userId);
        if ($stmt->execute()) {
            logActivity($conn, $userId, 'ban', "User ID $userId banned until $banEndDate");
            echo "User banned successfully until $banEndDate.";
        } else {
            echo "Error banning user: " . $stmt->error;
        }
        $stmt->close();
    } elseif ($_POST['action'] === 'unban') {
        // Unban user
        $query = "UPDATE users SET ban_end_date = NULL WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $userId);
        if ($stmt->execute()) {
            logActivity($conn, $userId, 'unban', "User ID $userId unbanned");
            echo "User unbanned successfully.";
        } else {
            echo "Error unbanning user: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle user deletion
if (isset($_POST['action']) && $_POST['action'] === 'delete_user' && isset($_POST['user_id'])) {
    $userId = $_POST['user_id'];

    $deleteUserQuery = "DELETE FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($deleteUserQuery);
    $stmt->bind_param("i", $userId);
    if ($stmt->execute()) {
        logActivity($conn, $userId, 'delete_user', "User ID $userId deleted");
        echo "User deleted successfully.";
    } else {
        echo "Error deleting user: " . $stmt->error;
    }
    $stmt->close();
}

// Handle user update
if (isset($_POST['action']) && $_POST['action'] === 'edit_user' && isset($_POST['user_id'])) {
    $userId = $_POST['user_id'];
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];

    $updateUserQuery = "UPDATE users SET user_firstname = ?, user_lastname = ?, user_email = ? WHERE user_id = ?";
    $stmt = $conn->prepare($updateUserQuery);
    $stmt->bind_param("sssi", $firstName, $lastName, $email, $userId);
    if ($stmt->execute()) {
        logActivity($conn, $userId, 'edit_user', "User ID $userId updated");
        echo "User updated successfully.";
    } else {
        echo "Error updating user: " . $stmt->error;
    }
    $stmt->close();
}

// Retrieve and Display Users
$userQuery = "SELECT * FROM users";
$userResult = mysqli_query($conn, $userQuery);
?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">MANAGE USERS</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($userRow = mysqli_fetch_assoc($userResult)) {
                                    $isBanned = !is_null($userRow['ban_end_date']);
                                    ?>
                                    <tr>
                                        <td><?php echo $userRow['user_id']; ?></td>
                                        <td><?php echo $userRow['user_firstname']; ?></td>
                                        <td><?php echo $userRow['user_lastname']; ?></td>
                                        <td><?php echo $userRow['user_email']; ?></td>
                                        <td>
                                            <form method="post" action="">
                                                <input type="hidden" name="user_id" value="<?php echo $userRow['user_id']; ?>">
                                                <button type="submit" name="action" value="delete_user">Delete</button>
                                            </form>
                                            <?php if ($isBanned) { ?>
                                                <form method="post" action="">
                                                    <input type="hidden" name="user_id" value="<?php echo $userRow['user_id']; ?>">
                                                    <button type="submit" name="action" value="unban">Unban</button>
                                                </form>
                                            <?php } else { ?>
                                                <form method="post" action="">
                                                    <input type="number" name="ban_days" placeholder="Enter ban days" required>
                                                    <input type="hidden" name="user_id" value="<?php echo $userRow['user_id']; ?>">
                                                    <button type="submit" name="action" value="ban">Ban</button>
                                                </form>
                                            <?php } ?>
                                            <button onclick="editUser(<?php echo $userRow['user_id']; ?>, '<?php echo $userRow['user_firstname']; ?>', '<?php echo $userRow['user_lastname']; ?>', '<?php echo $userRow['user_email']; ?>')">Edit</button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" style="display:none;">
    <form method="post" action="">
        <input type="hidden" name="user_id" id="editUserId">
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" id="editFirstName" required>
        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" id="editLastName" required>
        <label for="email">Email:</label>
        <input type="email" name="email" id="editEmail" required>
        <button type="submit" name="action" value="edit_user">Save Changes</button>
    </form>
</div>

<script>
function editUser(userId, firstName, lastName, email) {
    document.getElementById('editUserId').value = userId;
    document.getElementById('editFirstName').value = firstName;
    document.getElementById('editLastName').value = lastName;
    document.getElementById('editEmail').value = email;
    document.getElementById('editUserModal').style.display = 'block';
}
</script>

<?php
require('footer.inc.php');
?>
