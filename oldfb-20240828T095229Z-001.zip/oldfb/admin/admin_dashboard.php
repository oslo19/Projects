<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Count the number of posts
$postCountQuery = "SELECT COUNT(*) AS postCount FROM posts";
$postCountResult = mysqli_query($conn, $postCountQuery);
$postCountRow = mysqli_fetch_assoc($postCountResult);
$postCount = $postCountRow['postCount'];

// Count the number of users
$userCountQuery = "SELECT COUNT(*) AS userCount FROM users";
$userCountResult = mysqli_query($conn, $userCountQuery);
$userCountRow = mysqli_fetch_assoc($userCountResult);
$userCount = $userCountRow['userCount'];

// Count the number of flagged posts
$flaggedCountQuery = "SELECT COUNT(*) AS flaggedCount FROM flagged_content";
$flaggedCountResult = mysqli_query($conn, $flaggedCountQuery);
$flaggedCountRow = mysqli_fetch_assoc($flaggedCountResult);
$flaggedCount = $flaggedCountRow['flaggedCount'];

// Retrieve recent activities
$recentActivityQuery = "
    SELECT 
        'post' AS type, p.post_caption AS content, p.post_time AS time, CONCAT(u.user_firstname, ' ', u.user_lastname) AS user_name 
    FROM posts p
    JOIN users u ON p.post_by = u.user_id
    UNION ALL 
    SELECT 
        'ban' AS type, CONCAT('User ', u.user_firstname, ' ', u.user_lastname, ' banned until ', ban_end_date) AS content, ban_end_date AS time, CONCAT(u.user_firstname, ' ', u.user_lastname) AS user_name 
    FROM users u 
    WHERE ban_end_date IS NOT NULL 
    UNION ALL
    SELECT 
        'comment' AS type, 
        CONCAT(cu.user_firstname, ' ', cu.user_lastname, ' commented \"', c.comment_text, '\" on post ', c.post_id, ' by ', pu.user_firstname, ' ', pu.user_lastname) AS content, 
        c.comment_time AS time, 
        CONCAT(cu.user_firstname, ' ', cu.user_lastname) AS user_name 
    FROM comments c
    JOIN users cu ON c.commenter_id = cu.user_id
    JOIN posts p ON c.post_id = p.post_id
    JOIN users pu ON p.post_by = pu.user_id
    UNION ALL
    SELECT 
        'like' AS type, 
        CONCAT(lu.user_firstname, ' ', lu.user_lastname, ' liked post ', l.post_id, ' by ', pu.user_firstname, ' ', pu.user_lastname) AS content, 
        l.like_time AS time, 
        CONCAT(lu.user_firstname, ' ', lu.user_lastname) AS user_name 
    FROM post_likes l
    JOIN users lu ON l.user_id = lu.user_id
    JOIN posts p ON l.post_id = p.post_id
    JOIN users pu ON p.post_by = pu.user_id
    UNION ALL
    SELECT 
        'report' AS type, 
        CONCAT(ru.user_firstname, ' ', ru.user_lastname, ' reported post ', r.post_id, ' by ', pu.user_firstname, ' ', pu.user_lastname, ' for ', r.report_reason) AS content, 
        r.report_time AS time, 
        CONCAT(ru.user_firstname, ' ', ru.user_lastname) AS user_name 
    FROM reports r
    JOIN users ru ON r.reported_by = ru.user_id
    JOIN posts p ON r.post_id = p.post_id
    JOIN users pu ON p.post_by = pu.user_id
    UNION ALL
    SELECT 
        'delete' AS type, 
        CONCAT(du.user_firstname, ' ', du.user_lastname, ' deleted post ', d.post_id) AS content, 
        d.delete_time AS time, 
        CONCAT(du.user_firstname, ' ', du.user_lastname) AS user_name 
    FROM post_deletes d
    JOIN users du ON d.deleted_by = du.user_id
    ORDER BY time DESC 
    LIMIT 10";
$recentActivityResult = mysqli_query($conn, $recentActivityQuery);

// Retrieve activity logs from activity_logs
$activityLogsQuery = "
    SELECT al.*, CONCAT(u.user_firstname, ' ', u.user_lastname) AS user_name 
    FROM activity_logs al
    JOIN users u ON al.user_id = u.user_id
    ORDER BY al.activity_time DESC
    LIMIT 10";
$activityLogsResult = mysqli_query($conn, $activityLogsQuery);

// Fetch all usernames to replace user_id in details
$usernamesQuery = "SELECT user_id, CONCAT(user_firstname, ' ', user_lastname) AS user_name FROM users";
$usernamesResult = mysqli_query($conn, $usernamesQuery);
$usernames = [];
while ($row = mysqli_fetch_assoc($usernamesResult)) {
    $usernames[$row['user_id']] = $row['user_name'];
}

// Replace user_id in details with username
function replaceUserIdsWithUsernames($details, $usernames) {
    return preg_replace_callback('/\b\d+\b/', function ($matches) use ($usernames) {
        return $usernames[$matches[0]] ?? $matches[0];
    }, $details);
}

?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">ADMIN DASHBOARD</h4>
                        <p>Total Posts: <?php echo $postCount; ?></p>
                        <p>Total Users: <?php echo $userCount; ?></p>
                        <p>Total Flagged Posts: <?php echo $flaggedCount; ?></p>
                        
                        <h4 class="box-title mt-4">Recent Activities</h4>
                        <ul>
                            <?php
                            while ($activity = mysqli_fetch_assoc($recentActivityResult)) {
                                echo "<li>{$activity['time']}: {$activity['content']} ({$activity['type']})</li>";
                            }
                            ?>
                        </ul>

                        <h4 class="box-title mt-4">Activity Logs</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Log ID</th>
                                    <th>User</th>
                                    <th>Activity Type</th>
                                    <th>Activity Time</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($log = mysqli_fetch_assoc($activityLogsResult)) {
                                    $detailsWithUsernames = replaceUserIdsWithUsernames($log['details'], $usernames);
                                    echo "<tr>
                                        <td>{$log['log_id']}</td>
                                        <td>{$log['user_name']}</td>
                                        <td>{$log['activity_type']}</td>
                                        <td>{$log['activity_time']}</td>
                                        <td>{$detailsWithUsernames}</td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
