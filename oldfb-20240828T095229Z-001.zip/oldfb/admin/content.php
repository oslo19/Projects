<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Delete Post
if (isset($_GET['delete_post_id'])) {
    $deletePostId = $_GET['delete_post_id'];
    $deletePostQuery = "DELETE FROM posts WHERE post_id = '$deletePostId'";
    if (mysqli_query($conn, $deletePostQuery)) {
        echo "Post deleted successfully.";
    } else {
        echo "Error deleting post: " . mysqli_error($conn);
    }
}

// Retrieve and Display Posts with User Names
$postQuery = "SELECT posts.post_id, posts.post_caption, posts.post_time, posts.post_public, posts.post_by, users.user_firstname, users.user_lastname FROM posts LEFT JOIN users ON posts.post_by = users.user_id";
$postResult = mysqli_query($conn, $postQuery);
?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">USER POSTS</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Post ID</th>
                                    <th>User Name</th>
                                    <th>Content</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php
while ($postRow = mysqli_fetch_assoc($postResult)) {
    ?>
    <tr>
        <td><?php echo isset($postRow['post_id']) ? $postRow['post_id'] : ''; ?></td>
        <td><?php echo isset($postRow['user_firstname']) ? $postRow['user_firstname'] . ' ' . $postRow['user_lastname'] : ''; ?></td>
        <td><?php echo isset($postRow['post_caption']) ? $postRow['post_caption'] : ''; ?></td>
        <td>
            <a href="?delete_post_id=<?php echo isset($postRow['post_id']) ? $postRow['post_id'] : ''; ?>" onclick="return confirm('Are you sure you want to delete this post?')">Delete</a>
        </td>
    </tr>
    <?php
}
?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
