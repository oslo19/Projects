<?php
require('top.inc.php');

// Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "socialnetwork");

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Include logActivity function
function logActivity($conn, $userId, $activityType, $details) {
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, activity_type, details) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $userId, $activityType, $details);
    $stmt->execute();
    $stmt->close();
}

// Define abusive content keywords
$abusiveKeywords = ['abuse', 'hate', 'violence', 'offensive','yawa','pisti','tangina','putangina','gago','tanga','bobo','kayat','iyot','lulu','potang ina'];

// Function to detect abusive content
function detectAbusiveContent($content, $keywords, $conn, $postId) {
    $result = array('abusive' => false, 'userId' => null);
    foreach ($keywords as $keyword) {
        if (strpos($content, $keyword) !== false) {
            $updateQuery = "UPDATE posts SET is_abusive = 1 WHERE post_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("i", $postId);
            $stmt->execute();
            $stmt->close();
            $userId = getUserIdFromPostId($conn, $postId);
            $result['abusive'] = true;
            $result['userId'] = $userId;
            return $result;
        }
    }
    return $result;
}

// Function to get user ID from post ID
function getUserIdFromPostId($conn, $postId) {
    $query = "SELECT post_by FROM posts WHERE post_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $postId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['post_by'];
}

// Function to delete abusive posts of a user
function deleteUserAbusivePosts($conn, $userId) {
    $deleteQuery = "DELETE FROM posts WHERE post_by = ? AND is_abusive = 1";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();
}

// Retrieve and Display Posts
$postQuery = "SELECT * FROM posts";
$postResult = mysqli_query($conn, $postQuery);

// Array to store counts of abusive posts for each user
$userAbusiveCount = array();

?>

<div class="content pb-0">
    <div class="orders">
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="box-title">MANAGE POSTS</h4>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Post ID</th>
                                    <th>Post Caption</th>
                                    <th>Post Time</th>
                                    <th>User ID</th>
                                    <th>User Nickname</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                while ($postRow = mysqli_fetch_assoc($postResult)) {
                                    $abusiveResult = detectAbusiveContent($postRow['post_caption'], $abusiveKeywords, $conn, $postRow['post_id']);
                                    $userId = $abusiveResult['userId'];
                                    $isAbusive = $abusiveResult['abusive'];

                                    if ($isAbusive) {
                                        if (!isset($userAbusiveCount[$userId])) {
                                            $userAbusiveCount[$userId] = 1;
                                        } else {
                                            $userAbusiveCount[$userId]++;
                                        }

                                        if ($userAbusiveCount[$userId] >= 3) {
                                            $banEndDate = date('Y-m-d H:i:s', strtotime('+1 day'));
                                            $banQuery = "UPDATE users SET ban_end_date = ? WHERE user_id = ?";
                                            $stmt = $conn->prepare($banQuery);
                                            $stmt->bind_param("si", $banEndDate, $userId);
                                            $stmt->execute();
                                            $stmt->close();

                                            deleteUserAbusivePosts($conn, $userId);
                                        }
                                    }

                                    $userQuery = "SELECT user_nickname FROM users WHERE user_id = ?";
                                    $stmt = $conn->prepare($userQuery);
                                    $stmt->bind_param("i", $postRow['post_by']);
                                    $stmt->execute();
                                    $userResult = $stmt->get_result();
                                    $userRow = $userResult->fetch_assoc();

                                    ?>
                                    <tr style="color: <?php echo $isAbusive ? 'red' : 'black'; ?>">
                                        <td><?php echo $postRow['post_id']; ?></td>
                                        <td><?php echo $postRow['post_caption']; ?></td>
                                        <td><?php echo $postRow['post_time']; ?></td>
                                        <td><?php echo $postRow['post_by']; ?></td>
                                        <td><?php echo $userRow['user_nickname']; ?></td>
                                        <td>
                                            <form method="post" action="">
                                                <input type="hidden" name="post_id" value="<?php echo $postRow['post_id']; ?>">
                                                <button type="submit" name="action" value="delete" onclick="return confirm('Are you sure you want to delete this post?');">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('footer.inc.php');
?>
