<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required fields are set
    if (isset($_POST['post_id'], $_POST['comment'])) {
        // Include functions and establish database connection
        require 'functions/functions.php';
        $conn = connect();

        // Check if the user is logged in
        session_start();
        if (!isset($_SESSION['user_id'])) {
            echo "Error: User is not logged in.";
            exit(); // Stop script execution if the user is not logged in
        }

        // Sanitize input data
        $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        $commenter_id = $_SESSION['user_id']; // Assuming user ID is stored in the session

        // Check if the commenter ID exists in the users table
        $check_user_sql = "SELECT COUNT(*) FROM users WHERE user_id = '$commenter_id'";
        $check_user_query = mysqli_query($conn, $check_user_sql);
        $user_exists = mysqli_fetch_row($check_user_query)[0];
        if ($user_exists == 0) {
            echo "Error: Commenter ID does not exist in the users table.";
            exit(); // Stop script execution if the commenter ID does not exist
        }

        // Insert the comment into the database
        $sql = "INSERT INTO comments (post_id, commenter_id, comment_text, comment_time) 
                VALUES ('$post_id', '$commenter_id', '$comment', NOW())";
        $query = mysqli_query($conn, $sql);

        // Check if the comment was successfully inserted
        if ($query) {
            // Redirect back to the page where the comment was posted
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit();
        } else {
            // Handle the error if the comment insertion fails
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // Handle if required fields are not set
        echo "Error: Required fields are not set.";
    }
} else {
    // Handle if the form is not submitted
    echo "Error: Form is not submitted.";
}
?>
