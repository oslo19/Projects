<?php
session_start();
require 'functions/functions.php'; // Ensure the correct path to the functions file

// Check if the required POST parameters are set
if (!isset($_POST['group_id']) || !isset($_POST['user_id'])) {
    echo 'Error: Missing required parameters.';
    exit();
}

$groupId = intval($_POST['group_id']);
$userId = intval($_POST['user_id']);

// Establish Database Connection
$conn = connect(); // Ensure the connect() function is defined in 'functions.php'

// Insert the user as a member of the group
$query = "INSERT INTO group_members (group_id, user_id) VALUES ('$groupId', '$userId')";
if (mysqli_query($conn, $query)) {
    echo 'success';
} else {
    echo 'error: ' . mysqli_error($conn);
}
?>
