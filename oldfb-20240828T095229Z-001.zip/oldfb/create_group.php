<?php 
require 'functions/functions.php';
session_start();
// Check whether user is logged on or not
if (!isset($_SESSION['user_id'])) {
    header("location:index.php");
    exit();
}
$temp = $_SESSION['user_id'];
session_destroy();
session_start();
$_SESSION['user_id'] = $temp;
ob_start(); 
// Establish Database Connection
$conn = connect();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Network</title>
    <link rel="stylesheet" type="text/css" href="resources/css/main.css">
    <style>
    .frame a{
        text-decoration: none;
        color: #4267b2;
    }
    .frame a:hover{
        text-decoration: underline;
    }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/navbar.php'; ?>
        <br>
        <div class="createpost">
            <form method="post" action="" onsubmit="return validateGroup()" enctype="multipart/form-data">
                <h2>Create Group</h2>
                <hr>
                Group Name <span class="required" style="display:none;"> *Group name is required.</span><br>
                <input type="text" name="group_name">
                <div class="createpostbuttons">
                    <input type="submit" value="Create Group" name="create_group">
                </div>
            </form>
        </div>
        <h1>Groups</h1>
        <?php
            echo '<center>'; 
            $sql = "SELECT * FROM groups WHERE admin_id = {$_SESSION['user_id']}";
            $query = mysqli_query($conn, $sql);
            if($query){
                while($row = mysqli_fetch_assoc($query)){
                    echo '<div class="frame">';
                    echo '<center>';
                    echo '<h3>' . $row['group_name'] . '</h3>';
                    echo '</center>';
                    echo '</div>';
                }
            }
            echo '</center>';
        ?>
    </div>
   <script src="resources/js/jquery.js"></script>
<script>
    // Form Validation
    function validateGroup(){
        var required = document.getElementsByClassName("required");
        var groupName = document.getElementsByName("group_name")[0].value;
        required[0].style.display = "none";
        if(groupName == ""){
            required[0].style.display = "initial";
            return false;
        }
        return true;
    }
</script>
</body>
</html>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_group'])) { // Form is Posted
    // Assign Variables
    $groupName = $_POST['group_name'];
    $adminId = $_SESSION['user_id'];
    // Apply Insertion Query
    $sql = "INSERT INTO groups (group_name, admin_id, created_at)
            VALUES ('$groupName', '$adminId', NOW())";
    $query = mysqli_query($conn, $sql);
    // Action on Successful Query
    if($query){
        // Get the ID of the newly created group
        $groupId = mysqli_insert_id($conn);
        // Automatically add the admin as a member of the group
        $sql = "INSERT INTO group_members (group_id, user_id) VALUES ('$groupId', '$adminId')";
        mysqli_query($conn, $sql);

        header("location: groups.php");
        exit; // Ensure no further output is sent
    }
}
?>
