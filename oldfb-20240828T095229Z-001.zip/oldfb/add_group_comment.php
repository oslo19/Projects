<?php
session_start();
require 'functions/functions.php';

$conn = connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment']) && isset($_POST['group_post_id']) && isset($_POST['group_id']) && isset($_POST['group_name'])) {
    $group_post_id = intval($_POST['group_post_id']);
    $commenter_id = $_SESSION['user_id'];
    $comment_text = mysqli_real_escape_string($conn, $_POST['comment']);
    $group_id = intval($_POST['group_id']);
    $group_name = mysqli_real_escape_string($conn, $_POST['group_name']);

    // Debugging output
    echo "Debugging Info:<br>";
    echo "Group Post ID: $group_post_id<br>";
    echo "Group ID: $group_id<br>";
    echo "Group Name: $group_name<br>";
    echo "Commenter ID: $commenter_id<br>";
    echo "Comment Text: $comment_text<br>";

    if ($group_post_id === 0) {
        echo "Error: group_post_id is not valid.";
        exit();
    }

    // Check if the group_post_id exists
    $check_sql = "SELECT group_post_id FROM group_posts WHERE group_post_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param('i', $group_post_id);
    $check_stmt->execute();
    $check_stmt->store_result();
    if ($check_stmt->num_rows === 0) {
        echo "Error: Invalid group_post_id";
        exit();
    }

    $sql = "INSERT INTO group_comments (group_post_id, commenter_id, comment_text) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iis', $group_post_id, $commenter_id, $comment_text);
    $query = $stmt->execute();

    if ($query) {
        // Redirect back to the group page
        header("Location: group-home.php?id=$group_id&name=" . urlencode($group_name));
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    header("Location: group-home.php?id=" . intval($_POST['group_id']) . "&name=" . urlencode($_POST['group_name']));
    exit();
}
?>
