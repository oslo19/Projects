<?php

session_start(); // Start the session to store verification code

$email = $_POST["email"];

$mysqli = require __DIR__ . "/functions/functions.php";

$sql = "SELECT * FROM users WHERE user_email = ?";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    // Email not found, redirect back to forgot password page with error
    header("Location: forgot-password.php?error=email_not_found");
    exit;
}

// Email exists, proceed with sending the verification code
$verification_code = substr(md5(uniqid(rand(), true)), 0, 6); // Generate a 6-character verification code
$expiry = date("Y-m-d H:i:s", time() + 60 * 30); // 30 minutes expiry time

// Update verification code and expiry time in the database
$sql_update = "UPDATE users
               SET verification_code = ?,
                   verification_code_expires_at = ?
               WHERE user_email = ?";
$stmt_update = $mysqli->prepare($sql_update);
$stmt_update->bind_param("sss", $verification_code, $expiry, $email);
$stmt_update->execute();

if ($stmt_update->affected_rows) {
    // Store verification code in session
    $_SESSION['verification_code'] = $verification_code;
    
    // Include mailer.php
    require __DIR__ . "/mailer.php";
    
    // Send email
    try {
        $mail->setFrom("choy123@gmail.com", "CHOYINS");
        $mail->addAddress($email);
        $mail->Subject = "Password Reset Verification Code";
        $mail->Body = "Your verification code is: $verification_code";
        
        $mail->send();
        echo "<script>alert('Verification code sent successfully! Please check your inbox.');</script>";
        
        // Redirect to reset-password.php with the token in the URL
        header("Location: verify-code.php?token=$verification_code");
        exit; // Ensure that the script stops execution after redirecting
    } catch (Exception $e) {
        echo "<script>alert('Failed to send verification code. Please try again later.');</script>";
    }
} else {
    echo "<script>alert('Failed to update verification code for the user.');</script>";
}

?>
