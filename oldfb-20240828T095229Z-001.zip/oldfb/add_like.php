<?php
session_start();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required fields are set
    if (isset($_POST['post_id'], $_POST['liked'])) {
        // Include functions and establish database connection
        require 'functions/functions.php';
        $conn = connect();

        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            echo "Error: User is not logged in.";
            exit(); // Stop script execution if the user is not logged in
        }

        // Sanitize input data
        $post_id = mysqli_real_escape_string($conn, $_POST['post_id']);
        $user_id = $_SESSION['user_id'];

        // Check if the user has already liked the post
        $check_like_sql = "SELECT * FROM post_likes WHERE post_id = '$post_id' AND user_id = '$user_id'";
        $check_like_query = mysqli_query($conn, $check_like_sql);

        if (mysqli_num_rows($check_like_query) > 0) {
            // User has already liked the post
            echo "Error: User has already liked the post.";
        } else {
            // User wants to add their like
            $add_like_sql = "INSERT INTO post_likes (post_id, user_id, like_time) VALUES ('$post_id', '$user_id', NOW())";
            $add_like_query = mysqli_query($conn, $add_like_sql);

            if ($add_like_query) {
                echo "Like added successfully.";
            } else {
                echo "Error: Unable to add like.";
            }
        }
    } else {
        // Handle if required fields are not set
        echo "Error: Required fields are not set.";
    }
} else {
    // Handle if the request method is not POST
    echo "Error: Invalid request method.";
}
?>
