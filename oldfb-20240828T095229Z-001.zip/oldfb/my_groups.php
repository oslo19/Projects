<?php 
require 'functions/functions.php';
session_start();
// Check whether user is logged on or not
if (!isset($_SESSION['user_id'])) {
    header("location:index.php");
    exit(); // Ensure no further execution
}
$temp = $_SESSION['user_id'];
session_destroy();
session_start();
$_SESSION['user_id'] = $temp;
ob_start(); 
// Establish Database Connection
$conn = connect();

// Fetch the groups the user has joined
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM group_members WHERE user_id = $user_id";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Network - My Groups</title>
    <link rel="stylesheet" type="text/css" href="resources/css/main.css">
</head>
<body>
    <div class="container">
        <?php include 'includes/navbar.php'; ?>
		
        <br>
        <h1>My Groups</h1>
        <div class="groups-list">
            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $group_id = $row['group_id'];
                    $group_name = ""; // Fetch group name from the database based on group_id
                    // Output group as a clickable link
                    echo "<div><a href='groups.php?group_id=$group_id'>$group_name</a></div>";
                }
            } else {
                echo "You haven't joined any groups yet.";
            }
            ?>
        </div>
    </div>
</body>
</html>
