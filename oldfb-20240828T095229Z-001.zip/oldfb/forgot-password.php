<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="resources/css/main.css">
<style>
    /* Custom styles for forgot-password.php */
    .container {
        margin: 40px auto;
        width: 400px;
    }
    .content {
        padding: 30px;
        background-color: white;
        box-shadow: 0 0 5px #4267b2;
    }
    .error-message {
        color: red;
        margin-top: 5px;
    }
</style>
</head>
<body>
    <h1>Forgot Password</h1>
    <div class="container">
    <div class="content">
        <form method="post" action="send-password-reset.php">
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
            <?php if (isset($_GET['error']) && $_GET['error'] === 'email_not_found') { ?>
                <div class="error-message">Email does not exist. Please enter a valid email address.</div>
            <?php } ?>
            <button>Send</button>
        </form>
    </div>
    </div>
</body>
</html>
