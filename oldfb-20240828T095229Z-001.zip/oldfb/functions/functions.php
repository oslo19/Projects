
<?php
function connect() {
    static $conn;
    if ($conn === NULL) {
        $conn = new mysqli('localhost', 'root', '', 'socialnetwork');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    }
    return $conn;
}
?>
