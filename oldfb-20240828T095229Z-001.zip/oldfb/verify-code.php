<?php
session_start(); // Start the session to store verification code

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the submitted verification code
    $submitted_code = $_POST["verification_code"];
    
    // Check if the submitted code matches the one stored in the session
    if (isset($_SESSION['verification_code']) && $_SESSION['verification_code'] === $submitted_code) {
        // Redirect to reset password page with token
        $token = $_POST['token']; // Retrieve token from form submission
        header("Location: reset-password.php?token=$token");
        exit; // Ensure that the script stops execution after redirecting
    } else {
        // Verification code is incorrect
        echo "<script>alert('Incorrect verification code. Please try again.');</script>";
    }
}

// This block of code will execute if the form is not yet submitted or if the verification code is incorrect
?>

<!DOCTYPE html>
<html>
<head>
<title>Verify Code</title>
<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="resources/css/main.css">
<style>
    /* Custom styles for forgot-password.php */
    .container {
        margin: 40px auto;
        width: 400px;
    }
    .content {
        padding: 30px;
        background-color: white;
        box-shadow: 0 0 5px #4267b2;
    }
</style>
</head>
<body>

    <h1>Verify Code</h1>
	<div class="container">
    <div class="content">
    <p>Please input the verification code sent to your email:</p>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>"> 
        <div>
				<label for="verification_code">Verification Code:</label>
			<input type="text" id="verification_code" name="verification_code" required>

		</div>

        <button type="submit">Submit</button>
    </form>
	
	</div>
    </div>
</div>
</body>
</html>
