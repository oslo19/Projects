<?php
ob_start();
require_once 'functions/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("location:index.php");
    exit();
}
$conn = connect();
if (!isset($_GET['id'])) {
    // Redirect or show an error message if the group ID is not provided
    header("location: groups.php");
    exit();
}

$group_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Check if the user is banned from the group
$sql_ban_check = "SELECT banned FROM group_members WHERE group_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql_ban_check);
if ($stmt === false) {
    echo "Error: " . $conn->error;
    exit();
}
$stmt->bind_param('ii', $group_id, $user_id);
$stmt->execute();
$query_ban_check = $stmt->get_result();
$row_ban_check = $query_ban_check->fetch_assoc();
$is_banned = $row_ban_check ? $row_ban_check['banned'] : null;

if ($is_banned) {
    echo '<p>You are banned from this group.</p>';
    exit();
}
$group_id = isset($_GET['id']) ? intval($_GET['id']) : null;
$group_name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : "Group Name";

if (!$group_id) {
    echo "Error: Invalid group ID";
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM group_members WHERE group_id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    echo "Error: " . $conn->error;
    exit();
}
$stmt->bind_param('ii', $group_id, $user_id);
$stmt->execute();
$query = $stmt->get_result();
$is_member = $query->num_rows > 0;

$sql_admin = "SELECT admin_id FROM groups WHERE group_id = ?";
$stmt = $conn->prepare($sql_admin);
if ($stmt === false) {
    echo "Error: " . $conn->error;
    exit();
}
$stmt->bind_param('i', $group_id);
$stmt->execute();
$query_admin = $stmt->get_result();
$row_admin = $query_admin->fetch_assoc();
if ($row_admin === null) {
    echo "Error: Group not found.";
    exit();
}
$admin_id = $row_admin['admin_id'];
$is_admin = $admin_id == $user_id;
if ($is_admin) {
    $is_member = true;
}

if ($is_member) {
    $sql_admin_details = "SELECT user_firstname, user_lastname FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql_admin_details);
    if ($stmt === false) {
        echo "Error: " . $conn->error;
        exit();
    }
    $stmt->bind_param('i', $admin_id);
    $stmt->execute();
    $query_admin_details = $stmt->get_result();
    $admin_details = $query_admin_details->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Network</title>
    <link rel="stylesheet" type="text/css" href="resources/css/main.css">
    <style>
    .post {
        margin-right: 605px;
        float: right;
        margin-bottom: 18px;
    }
    .profile {
        margin-left: 5px;
        background-color: white;
        box-shadow: 0 0 5px #4267b2;
        width: 220px;
        padding: 20px;
    }
    input[type="file"] {
        display: none;
    }
    label.upload {
        cursor: pointer;
        color: white;
        background-color: #4267b2;
        padding: 8px 12px;
        display: inline-block;
        max-width: 80px;
        overflow: auto;
    }
    label.upload:hover {
        background-color: #23385f;
    }
    .changeprofile {
        color: #23385f;
        font-family: Fontin SmallCaps;
    }
    .join-group-container {
        text-align: center;
        margin: 20px 0;
    }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>
    <h1><?php echo $group_name; ?></h1>
    <br>
    <?php if (!$is_member): ?>
        <div class="join-group-container">
            <p>JOIN GROUP TO MAKE A POST AND SEE GROUP NEWS FEED</p>
            <button onclick="joinGroup()">Join Group</button>
        </div>
    <?php else: ?>
        <div class="createpost">
            <form method="post" action="" onsubmit="return validatePost()" enctype="multipart/form-data">
                <h2>Make Post</h2>
                <hr>
                <span style="float:right; color:black">
                    <input type="checkbox" id="public" name="public">
                    <label for="public">Public</label>
                </span>
                Caption <span class="required" style="display:none;"> *You can't leave the Caption empty.</span><br>
                <textarea rows="6" name="caption"></textarea>
                <center><img src="" id="preview" style="max-width:580px; display:none;"></center>
                <div class="createpostbuttons">
                    <label class="upload">
                        <img src="images/photo.png">
                        <input type="file" name="fileUpload" id="imagefile" onchange="previewImage(event)">
                    </label>
                    <input type="submit" value="Post" name="post">
                </div>
            </form>
        </div>
        <h1>Group News Feed</h1>
        <?php 
       
        
       
            // Check if user is muted
            $sql_mute_check = "SELECT muted, mute_until FROM group_members WHERE group_id = ? AND user_id = ?";
            $stmt = $conn->prepare($sql_mute_check);
            if ($stmt === false) {
                echo "Error: " . $conn->error;
                exit();
            }
            $stmt->bind_param('ii', $group_id, $user_id);
            $stmt->execute();
            $query_mute_check = $stmt->get_result();
            $row_mute_check = $query_mute_check->fetch_assoc();
            $is_muted = $row_mute_check ? $row_mute_check['muted'] : null;
            $mute_until = $row_mute_check ? $row_mute_check['mute_until'] : null;

            if ($is_muted) {
                $current_time = date('Y-m-d H:i:s');
                if ($current_time < $mute_until) {
                    echo '<p>You are muted until ' . $mute_until . '</p>';
                } else {
                    // Unmute user if the mute time has passed
                    $sql_unmute = "UPDATE group_members SET muted = 0, mute_until = NULL WHERE group_id = ? AND user_id = ?";
                    $stmt = $conn->prepare($sql_unmute);
                    if ($stmt === false) {
                        echo "Error: " . $conn->error;
                        exit();
                    }
                    $stmt->bind_param('ii', $group_id, $user_id);
                    $stmt->execute();
                }
            }

            $sql = "SELECT group_posts.*, users.user_id, users.user_firstname, users.user_lastname, users.user_gender FROM group_posts
                    JOIN users ON group_posts.post_by = users.user_id
                    WHERE group_posts.group_id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                echo "Error: " . $conn->error;
                exit();
            }
            $stmt->bind_param('i', $group_id);
            $stmt->execute();
            $query = $stmt->get_result();
            if ($query->num_rows == 0) {
                echo '<div class="post">There are no posts yet to show.</div>';
            } else {
                $width = '40px'; 
                $height = '40px';
                while ($row = $query->fetch_assoc()) {
                    include 'includes/group_post.php';
                    echo '<br>';
                }
            }
      
        ?>
        <br>
        <div class="profile">
            <center class="changeprofile">Admin</center>
            <br>
            <center>
                <?php echo htmlspecialchars($admin_details['user_firstname']) . ' ' . htmlspecialchars($admin_details['user_lastname']); ?>
            </center>
            <br>
            <center class="changeprofile">Members</center>
            <br>
            <?php
            $sql_members = "SELECT users.user_id, users.user_firstname, users.user_lastname, group_members.muted, group_members.banned FROM group_members 
                            JOIN users ON group_members.user_id = users.user_id 
                            WHERE group_members.group_id = ?";
            $stmt = $conn->prepare($sql_members);
            if ($stmt === false) {
                echo "Error: " . $conn->error;
                exit();
            }
            $stmt->bind_param('i', $group_id);
            $stmt->execute();
            $query_members = $stmt->get_result();
            if ($query_members->num_rows == 0) {
                echo '<center>No members in this group yet.</center>';
            } else {
                echo '<ul>';
                while ($row_member = $query_members->fetch_assoc()) {
                    echo '<li>' . htmlspecialchars($row_member['user_firstname']) . ' ' . htmlspecialchars($row_member['user_lastname']);
                    if ($is_admin) {
                        echo ' - ';
                        if ($row_member['banned']) {
                            echo '<button data-user-id="' . $row_member['user_id'] . '" data-action="unban" onclick="banMember(' . $row_member['user_id'] . ')">Unban</button>';
                        } else {
                            echo '<button data-user-id="' . $row_member['user_id'] . '" data-action="ban" onclick="banMember(' . $row_member['user_id'] . ')">Ban</button>';
                        }
                        if ($row_member['muted']) {
                            echo '<button data-user-id="' . $row_member['user_id'] . '" data-action="unmute" onclick="muteMember(' . $row_member['user_id'] . ')">Unmute</button>';
                        } else {
                            echo '<button data-user-id="' . $row_member['user_id'] . '" data-action="mute" onclick="muteMember(' . $row_member['user_id'] . ')">Mute</button>';
                        }
                        echo '<button onclick="kickMember(' . $row_member['user_id'] . ')">Kick</button>';
                    }
                    echo '</li>';
                }
                echo '</ul>';
            }
            ?>
        </div>
    <?php endif; ?>

   
    <script src="resources/js/jquery.js"></script>
<script>
    function joinGroup() {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "join_group.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                location.reload();
            }
        };
        xhr.send("group_id=<?php echo $group_id; ?>&user_id=<?php echo $user_id; ?>");
    }

    function previewImage(event) {
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById('preview');
            output.src = reader.result;
            output.style.display = 'block';
        };
        reader.readAsDataURL(event.target.files[0]);
    }

    function validatePost() {
        var caption = document.getElementsByName("caption")[0].value;
        var required = document.querySelector(".required");
        required.style.display = "none";
        if (caption.trim() === "") {
            required.style.display = "initial";
            return false;
        }
        return true;
    }

    function banMember(userId) {
        if (confirm("Are you sure you want to ban/unban this member?")) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/oldfb/includes/ban_member.php?group_id=<?php echo $group_id; ?>&user_id=" + userId, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        var button = document.querySelector('button[data-user-id="' + userId + '"][data-action="ban"]');
                        button.innerText = (response.action === 'banned') ? 'Unban' : 'Ban';
                        button.setAttribute('data-action', (response.action === 'banned') ? 'unban' : 'ban');
                        alert(response.action.charAt(0).toUpperCase() + response.action.slice(1) + " successfully.");
                    } else {
                        alert(response.message);
                    }
                }
            };
            xhr.send();
        }
    }

    function muteMember(userId) {
        var days = prompt("For how many days do you want to mute this member?", "1");
        if (days != null) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/oldfb/includes/mute_member.php?group_id=<?php echo $group_id; ?>&user_id=" + userId + "&days=" + days, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        var button = document.querySelector('button[data-user-id="' + userId + '"][data-action="mute"]');
                        button.innerText = (response.action === 'muted') ? 'Unmute' : 'Mute';
                        button.setAttribute('data-action', (response.action === 'muted') ? 'unmute' : 'mute');
                        alert(response.action.charAt(0).toUpperCase() + response.action.slice(1) + " successfully.");
                    } else {
                        alert(response.message);
                    }
                }
            };
            xhr.send();
        }
    }

    function unbanMember(userId) {
        banMember(userId);
    }

    function unmuteMember(userId) {
        muteMember(userId);
    }

    function kickMember(userId) {
        if (confirm("Are you sure you want to kick this member?")) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/oldfb/includes/kick_member.php?group_id=<?php echo $group_id; ?>&user_id=" + userId, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    alert(xhr.responseText);
                    location.reload();
                }
            };
            xhr.send();
        }
    }
</script>



    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post'])) {
        $caption = $_POST['caption'];
        $public = isset($_POST['public']) ? "Y" : "N";
        $poster = $_SESSION['user_id'];
        $sql = "INSERT INTO group_posts (post_caption, post_public, post_time, post_by, group_id)
                VALUES (?, ?, NOW(), ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo "Error: " . $conn->error;
            exit();
        }
        $stmt->bind_param('ssii', $caption, $public, $poster, $group_id);
        $query = $stmt->execute();
        if ($query) {
            if (!empty($_FILES['fileUpload']['name'])) {
                $last_id = $stmt->insert_id;
                include 'functions/upload.php';
            }
            header("location: group-home.php?id=$group_id&name=" . urlencode($group_name));
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
    ?>
    <?php ob_end_flush(); ?>
</body>
</html>
