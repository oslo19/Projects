<?php
require 'functions/functions.php';
session_start();

// Check whether user is logged on or not
if (!isset($_SESSION['user_id'])) {
    header("location:index.php");
    exit();
}

$temp = $_SESSION['user_id'];
session_destroy();
session_start();
$_SESSION['user_id'] = $temp;
ob_start(); 

// Establish Database Connection
$conn = connect();

// Function to check if the user is banned
function checkBanStatus($conn, $userId) {
    $query = "SELECT ban_end_date FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row && $row['ban_end_date']) {
        $currentDate = date('Y-m-d H:i:s');
        if ($currentDate < $row['ban_end_date']) {
            echo "<script>alert('Your account is banned until " . $row['ban_end_date'] . " due to abusive behavior.');</script>";
            echo "<script>window.location.href = 'logout.php';</script>";
            exit();
        }
    }
}

// Check if the logged-in user is banned
checkBanStatus($conn, $_SESSION['user_id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Network</title>
    <link rel="stylesheet" type="text/css" href="resources/css/main.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> <!-- Added jQuery here -->
    <style>
        .options-menu {
            position: relative;
            display: inline-block;
        }

        .options-btn {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 18px;
            padding: 5px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .show {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include 'includes/navbar.php'; ?>
		
        <br>
        <div class="createpost">
            <form method="post" action="" onsubmit="return validatePost()" enctype="multipart/form-data">
                <h2>Make Post</h2>
                <hr>
                <span style="float:right; color:black">
                <input type="checkbox" id="public" name="public">
                <label for="public">Public</label>
                </span>
                Caption <span class="required" style="display:none;"> *You can't Leave the Caption Empty.</span><br>
                <textarea rows="6" name="caption"></textarea>
                <center><img src="" id="preview" style="max-width:580px; display:none;"></center>
                <div class="createpostbuttons">
                    <label>
                        <img src="images/photo.png">
                        <input type="file" name="fileUpload" id="imagefile">
                    </label>
                    <input type="submit" value="Post" name="post">
                </div>
            </form>
        </div>
        <h1>News Feed</h1>
        <?php 
        // Public Posts Union Friends' Private Posts
        $sql = "SELECT posts.post_caption, posts.post_time, posts.post_public, users.user_firstname,
                        users.user_lastname, users.user_id, users.user_gender, posts.post_id
                FROM posts
                JOIN users
                ON posts.post_by = users.user_id
                WHERE posts.post_public = 'Y' OR users.user_id = {$_SESSION['user_id']}
                UNION
                SELECT posts.post_caption, posts.post_time, posts.post_public, users.user_firstname,
                        users.user_lastname, users.user_id, users.user_gender, posts.post_id
                FROM posts
                JOIN users
                ON posts.post_by = users.user_id
                JOIN (
                    SELECT friendship.user1_id AS user_id
                    FROM friendship
                    WHERE friendship.user2_id = {$_SESSION['user_id']} AND friendship.friendship_status = 1
                    UNION
                    SELECT friendship.user2_id AS user_id
                    FROM friendship
                    WHERE friendship.user1_id = {$_SESSION['user_id']} AND friendship.friendship_status = 1
                ) userfriends
                ON userfriends.user_id = posts.post_by
                WHERE posts.post_public = 'N'
                ORDER BY post_time DESC";
        $query = mysqli_query($conn, $sql);
        if(!$query){
            echo mysqli_error($conn);
        }
        if(mysqli_num_rows($query) == 0){
            echo '<div class="post">';
            echo 'There are no posts yet to show.';
            echo '</div>';
        }
        else{
            $width = '40px'; // Profile Image Dimensions
            $height = '40px';
            while($row = mysqli_fetch_assoc($query)){
                include 'includes/post.php';
                echo '<br>';
            }
        }
        ?>
        <br><br><br>
    </div>
   <script src="resources/js/jquery.js"></script>
   
<script>
    // Invoke preview when an image file is choosen.
    $(document).ready(function(){
        $('#imagefile').change(function(){
            preview(this);
        });
    });
    // Preview function
    function preview(input){
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (event){
                $('#preview').attr('src', event.target.result);
                $('#preview').css('display', 'initial');
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    // Form Validation
    function validatePost(){
        var required = document.getElementsByClassName("required");
        var caption = document.getElementsByTagName("textarea")[0].value;
        required[0].style.display = "none";
        if(caption == ""){
            required[0].style.display = "initial";
            return false;
        }
        return true;
    }

    $(document).ready(function(){
        $('.like-btn').click(function(){
            // Disable the like button to prevent multiple clicks
            $(this).prop('disabled', true);

            var post_id = $(this).data('post-id');
            var liked = $(this).hasClass('liked');
            
            $.ajax({
                url: 'add_like.php',
                method: 'POST',
                data: { post_id: post_id, liked: liked },
                success: function(response){
                    // Update like count and button appearance based on server response
                    // Example: Reload the post section to reflect the updated like status
                },
                error: function(xhr, status, error){
                    // Handle error
                    console.error(error);
                }
            });
        });

        // Options button click handler
        $('.options-btn').click(function() {
            const dropdown = $(this).next('.dropdown-content');
            dropdown.toggleClass('show');
        });

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.options-btn')) {
                $('.dropdown-content').removeClass('show');
            }
        };
    });

    function hidePost(postId) {
        alert('Post ' + postId + ' hidden.');
        // Implement hide post functionality here
    }

    function reportPost(postId) {
        var reportReason = prompt("Please enter the reason for reporting this post:");
        if (reportReason != null) {
            $.ajax({
                url: 'includes/report_post.php',
                method: 'POST',
                data: { post_id: postId, report_reason: reportReason },
                success: function(response) {
                    alert(response.message);
                    if (response.success) {
                        // Optionally, hide the reported post
                        $('#post-' + postId).hide();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }
    }

    function deletePost(postId) {
    if (confirm('Are you sure you want to delete this post?')) {
        fetch('http://localhost/oldfb/includes/delete_post.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                post_id: postId
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.getElementById('post-' + postId).remove();
            } else {
                alert(data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}



</script>

</body>
</html>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') { // Form is Posted
    // Assign Variables
    $caption = $_POST['caption'];
    if(isset($_POST['public'])) {
        $public = "Y";
    } else {
        $public = "N";
    }
    $poster = $_SESSION['user_id'];
    // Apply Insertion Query
    $sql = "INSERT INTO posts (post_caption, post_public, post_time, post_by)
            VALUES ('$caption', '$public', NOW(), $poster)";
    $query = mysqli_query($conn, $sql);
    // Action on Successful Query
    if($query){
        // Upload Post Image If a file was choosen
        if (!empty($_FILES['fileUpload']['name'])) {
            // Retrieve Post ID
            $last_id = mysqli_insert_id($conn);
            include 'functions/upload.php';
        }
        header("location: home.php");
    }
}
?>
