<?php 
require 'functions/functions.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header("location:index.php");
    exit();
}
$conn = connect();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Network</title>
    <link rel="stylesheet" type="text/css" href="resources/css/main.css">
    <style>
    .frame a {
        text-decoration: none;
        color: #4267b2;
    }
    .frame a:hover {
        text-decoration: underline;
    }
    </style>
</head>
<body>
    <div class="container">
    <?php include 'includes/navbar.php'; ?>
        <h1>Groups</h1>
        <a href="create_group.php">Create Group</a>
        <center>
        <?php
        $sql = "SELECT * FROM groups";
        $query = mysqli_query($conn, $sql);
        if ($query) {
            if (mysqli_num_rows($query) == 0) {
                echo '<div class="post">';
                echo 'There are no groups yet. Would you like to create one?';
                echo '<a href="create_group.php">Create Group</a>';
                echo '</div>';
            } else {
                while ($row = mysqli_fetch_assoc($query)) {
                    echo '<div class="frame">';
                    echo '<center>';
                    echo '<h3><a href="group-home.php?id=' . $row['group_id'] . '&name=' . urlencode($row['group_name']) . '">' . $row['group_name'] . '</a></h3>';
                    echo '</center>';
                    echo '</div>';
                }
            }
        }
        ?>
        </center>
    </div>
</body>
</html>
