-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2024 at 12:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity_type` varchar(50) NOT NULL,
  `activity_time` datetime NOT NULL DEFAULT current_timestamp(),
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `commenter_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `post_id`, `commenter_id`, `comment_text`, `comment_time`) VALUES
(1, 10, 14, 'gwapo ko\r\n', '2024-04-24 11:21:59'),
(2, 10, 14, 'yawa', '2024-04-24 11:25:40'),
(3, 10, 11, 'yawa', '2024-04-24 11:33:23'),
(4, 10, 11, 'eric gwapo\r\n', '2024-04-24 11:54:49'),
(5, 15, 11, 'asdasd', '2024-04-24 12:39:56'),
(6, 15, 11, '', '2024-04-29 03:40:37'),
(7, 14, 11, 'ey', '2024-04-29 04:14:04'),
(8, 14, 11, 'ey', '2024-04-29 04:15:25'),
(9, 16, 11, 'yawa', '2024-06-05 10:07:37'),
(10, 16, 11, 'ahahaha', '2024-06-05 10:07:40');

-- --------------------------------------------------------

--
-- Table structure for table `flagged_content`
--

CREATE TABLE `flagged_content` (
  `flag_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `flagged_by` int(11) NOT NULL,
  `flag_reason` varchar(255) NOT NULL,
  `flag_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `friendship`
--

CREATE TABLE `friendship` (
  `user1_id` int(11) NOT NULL,
  `user2_id` int(11) NOT NULL,
  `friendship_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `friendship`
--

INSERT INTO `friendship` (`user1_id`, `user2_id`, `friendship_status`) VALUES
(2, 1, 1),
(2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`group_id`, `group_name`, `admin_id`, `created_at`) VALUES
(6, 'PACHOCHOYA', 11, '2024-06-02 19:48:28');

-- --------------------------------------------------------

--
-- Table structure for table `group_comments`
--

CREATE TABLE `group_comments` (
  `comment_id` int(11) NOT NULL,
  `group_post_id` int(11) NOT NULL,
  `commenter_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_comments`
--

INSERT INTO `group_comments` (`comment_id`, `group_post_id`, `commenter_id`, `comment_text`, `comment_time`) VALUES
(10, 10, 16, 'aw', '2024-06-03 04:18:06'),
(11, 11, 11, 'ye', '2024-06-03 04:30:13');

-- --------------------------------------------------------

--
-- Table structure for table `group_members`
--

CREATE TABLE `group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `banned` tinyint(1) DEFAULT 0,
  `muted` tinyint(1) DEFAULT 0,
  `mute_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_members`
--

INSERT INTO `group_members` (`group_id`, `user_id`, `banned`, `muted`, `mute_until`) VALUES
(6, 16, 0, 1, '2024-06-06 10:04:24');

-- --------------------------------------------------------

--
-- Table structure for table `group_posts`
--

CREATE TABLE `group_posts` (
  `group_post_id` int(11) NOT NULL,
  `post_caption` text DEFAULT NULL,
  `post_time` datetime DEFAULT NULL,
  `post_public` tinyint(1) DEFAULT NULL,
  `post_by` int(11) DEFAULT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `group_posts`
--

INSERT INTO `group_posts` (`group_post_id`, `post_caption`, `post_time`, `post_public`, `post_by`, `group_id`) VALUES
(10, 'hey', '2024-06-03 04:01:38', 0, 11, 6),
(11, 'jade', '2024-06-03 04:29:44', 0, 16, 6),
(12, 'eric', '2024-06-03 04:30:43', 0, 11, 6),
(13, 'aw', '2024-06-05 16:04:38', 0, 16, 6),
(14, 'yawa', '2024-06-05 16:08:32', 0, 11, 6);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `post_caption` text NOT NULL,
  `post_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `post_public` char(1) NOT NULL,
  `post_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_caption`, `post_time`, `post_public`, `post_by`) VALUES
(1, 'okaaay', '2024-04-02 19:14:42', 'N', 1),
(2, 'genard zozobrado has changed his profile picture.', '2024-04-02 19:15:16', 'N', 1),
(3, 'choy gwapo\r\n', '2024-04-04 17:15:38', 'Y', 1),
(4, 'genard zozobrado has changed his profile picture.', '2024-04-05 11:08:35', 'N', 1),
(5, 'genard zozobrado has changed his profile picture.', '2024-04-05 11:30:47', 'N', 1),
(6, 'genard zozobrado has changed his profile picture.', '2024-04-05 11:41:14', 'N', 1),
(7, 'yawa', '2024-04-05 11:58:14', 'N', 10),
(8, 'Mark Estopa has changed his profile picture.', '2024-04-05 11:58:38', 'N', 10),
(10, 'Gwapo Jade', '2024-04-05 12:27:08', 'Y', 12),
(14, 'potang ina', '2024-04-24 12:29:59', 'N', 11),
(15, 'eric gwapo', '2024-04-24 12:38:18', 'Y', 16),
(16, 'Boke gwapo', '2024-05-05 11:01:19', 'N', 11);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `like_id` int(11) NOT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `like_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`like_id`, `post_id`, `user_id`, `like_time`) VALUES
(15, 10, 11, '2024-04-24 12:20:53'),
(16, 10, 16, '2024-04-24 12:22:51'),
(17, 3, 11, '2024-04-24 12:26:48'),
(18, 15, 11, '2024-04-24 12:40:00'),
(19, 14, 11, '2024-04-29 04:12:37'),
(20, 16, 11, '2024-06-05 10:07:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_firstname` varchar(20) NOT NULL,
  `user_lastname` varchar(20) NOT NULL,
  `user_nickname` varchar(20) DEFAULT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_gender` char(1) NOT NULL,
  `user_birthdate` date NOT NULL,
  `user_status` char(1) DEFAULT NULL,
  `user_about` text DEFAULT NULL,
  `user_hometown` varchar(255) DEFAULT NULL,
  `is_locked` int(1) NOT NULL,
  `verification_code` varchar(64) DEFAULT NULL,
  `verification_code_expires_at` datetime DEFAULT NULL,
  `ban_end_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_firstname`, `user_lastname`, `user_nickname`, `user_password`, `user_email`, `user_gender`, `user_birthdate`, `user_status`, `user_about`, `user_hometown`, `is_locked`, `verification_code`, `verification_code_expires_at`, `ban_end_date`) VALUES
(1, 'genard', 'zozobrado', 'boke', '$2y$10$fZC3Ak1QhGpB9frz2nxN9uXzeS400Vr26RTAaxa5lMDEbidDlE0FG', 'zozobradogenard@gmail.com', 'M', '1998-02-05', 'S', 'BOBOB AKO', 'Tungkop Minglanilla Cebu', 0, NULL, NULL, NULL),
(2, 'Reymart', 'Gerondalan', 'Choy', '6470c7b35031e435aa3074768cc24eba', 'choy1234@gmail.com', 'M', '1996-04-19', 'S', 'part choy gwapo', 'Tungkil Minglanilla Cebu', 0, '674f22', '2024-04-05 12:59:37', NULL),
(10, 'Mark', 'Estopa', 'markie', 'lWMU&QfWqG8j', 'estopamark98@gmail.com', 'M', '1996-01-01', 'S', 'asdas', 'Tuyan Suba', 0, NULL, NULL, NULL),
(11, 'Jade', 'Harvy', 'jidang', '$2y$10$YZZ7IyU7mLBLmGWtoUVh4.D5nOC.NxiwZKSKye554PbJ7ukt9Xqly', 'jadeharvy08@gmail.com', 'M', '1996-01-01', 'S', 'asdas', 'Carcar', 0, NULL, NULL, NULL),
(12, 'Jhon lloyd', 'Paran', 'farun', '$2y$10$G.LWp02wYC8ch3fh.8VP3OfEIxVbWGOLxs9wRcm9IEp4PvlaS5QZC', 'paran123@gmail.com', 'M', '1996-01-01', 'S', 'asdadsa', 'Naga', 0, NULL, NULL, NULL),
(14, 'admin', 'admin', 'admin', '$2y$10$9oEICtNDbI24cTIaG2lkyOCB2pjzey9JBuHmXOhimAxAY6RmGDwfC', 'admin123@gmail.com', 'M', '1996-01-01', 'S', 'admin', 'admin village', 0, NULL, NULL, NULL),
(15, 'kiano', 'del pilar', 'kians', '$2y$10$hntGtO/L6M.KBmnPamypVuGpsbGuhWK.LaSxjGATo96mXZJc6h29K', 'kiano123@gmail.com', 'M', '1996-01-01', 'S', 'okaay', 'Tungkil Minglanilla Cebu', 0, NULL, NULL, NULL),
(16, 'eric', 'bacalso', 'dakogoten', '$2y$10$KUr/mUrstJXRxxJNpHpbjeA0va2B//wrxpLYd82DdHsp6tx5Tdk72', 'eric123@gmail.com', 'M', '1996-01-01', 'S', 'eric gwapo', 'lanas', 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_phone`
--

CREATE TABLE `user_phone` (
  `user_id` int(11) DEFAULT NULL,
  `user_phone` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_phone`
--

INSERT INTO `user_phone` (`user_id`, `user_phone`) VALUES
(1, 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `commenter_id` (`commenter_id`);

--
-- Indexes for table `flagged_content`
--
ALTER TABLE `flagged_content`
  ADD PRIMARY KEY (`flag_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `flagged_by` (`flagged_by`);

--
-- Indexes for table `friendship`
--
ALTER TABLE `friendship`
  ADD KEY `user1_id` (`user1_id`),
  ADD KEY `user2_id` (`user2_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `group_comments`
--
ALTER TABLE `group_comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD UNIQUE KEY `group_post_id` (`group_post_id`);

--
-- Indexes for table `group_members`
--
ALTER TABLE `group_members`
  ADD PRIMARY KEY (`group_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `group_posts`
--
ALTER TABLE `group_posts`
  ADD PRIMARY KEY (`group_post_id`),
  ADD KEY `post_by` (`post_by`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `post_by` (`post_by`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`like_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `verification_code` (`verification_code`);

--
-- Indexes for table `user_phone`
--
ALTER TABLE `user_phone`
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `flagged_content`
--
ALTER TABLE `flagged_content`
  MODIFY `flag_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `group_comments`
--
ALTER TABLE `group_comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `group_posts`
--
ALTER TABLE `group_posts`
  MODIFY `group_post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`commenter_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `flagged_content`
--
ALTER TABLE `flagged_content`
  ADD CONSTRAINT `flagged_content_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `flagged_content_ibfk_2` FOREIGN KEY (`flagged_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `friendship`
--
ALTER TABLE `friendship`
  ADD CONSTRAINT `friendship_ibfk_1` FOREIGN KEY (`user1_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `friendship_ibfk_2` FOREIGN KEY (`user2_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `group_comments`
--
ALTER TABLE `group_comments`
  ADD CONSTRAINT `fk_group_post` FOREIGN KEY (`group_post_id`) REFERENCES `group_posts` (`group_post_id`);

--
-- Constraints for table `group_members`
--
ALTER TABLE `group_members`
  ADD CONSTRAINT `group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `group_posts`
--
ALTER TABLE `group_posts`
  ADD CONSTRAINT `group_posts_ibfk_2` FOREIGN KEY (`post_by`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `group_posts_ibfk_3` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`post_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`),
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `user_phone`
--
ALTER TABLE `user_phone`
  ADD CONSTRAINT `user_phone_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
